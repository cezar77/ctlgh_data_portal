from django import template

register = template.Library()

@register.filter(name='replace_char_with_whitespace')
def replace_char_with_whitespace(value, arg):
    return value.replace(arg, ' ')
