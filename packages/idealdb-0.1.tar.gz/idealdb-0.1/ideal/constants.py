POSITION = (
 ('Husband / Wife', 'Husband / Wife'),
 ('GrandParent', 'GrandParent'),
 ('Son/Daughter', 'Son/Daughter'),
 ('ND', 'ND'),
 ('Other', 'Other')
)

HOUSING_TYPE = (
 ('None', 'None'),
 ('Yard', 'Yard'),
 ('Kraal', 'Kraal'),
 ('Stall - Shed', 'Stall - Shed'),
 ('ND', 'ND'),
 ('Other', 'Other')
)

HUMP_F = (
    (1, 'Absent'),
    (2, 'Small'),
    (3, 'Medium'),
    (4, 'Large'),
    (-888, 'ND')
)

HUMP_ORN = (
    (1, 'Erect'),
    (2, 'Bent sideways'),
    (-888, 'ND'),
    (-999, 'NA')
)

HUMP_LOC = (
    (1, 'Thoracic'),
    (2, 'Cervico-thoracic'),
    (-888, 'ND'),
    (-999, 'NA')
)

FACE = (
    (1, 'Flat'),
    (2, 'Concave'),
    (3, 'Convex'),
    (-888, 'ND')
)

BACK_PF = (
    (1, 'Hollow'),
    (2, 'Straight'),
    (-888, 'ND')
)

RUMP_PF = (
    (1, 'Flat'),
    (2, 'Sloping'),
    (3, 'Roofy'),
    (-888, 'ND')
)

HORN_F = (
    (1, 'Absent'),
    (2, 'Present'),
    (-888, 'ND')
)

HORN_SHAPE = (
    (1, 'Straight'),
    (2, 'Curved'),
    (3, 'Lyre-shaped'),
    (4, 'Spiral'),
    (-888, 'ND'),
    (-999, 'NA')
)

HORN_ORNT = (
    (1, 'Upward'),
    (2, 'Forward'),
    (3, 'Backward'),
    (4, 'Lateral'),
    (5, 'Downward'),
    (-888, 'ND'),
    (-999, 'NA')
)

SPAC_HORN = (
    (1, 'Narrow'),
    (2, 'Wide'),
    (-888, 'ND'),
    (-999, 'NA')
)

LNTH_HRN = (
    (1, 'Short'),
    (2, 'Medium'),
    (3, 'Long'),
    (-888, 'ND'),
    (-999, 'NA')
)

EAR_SZ = (
    (1, 'Small'),
    (2, 'Large'),
    (-888, 'ND'),
)

EAR_SHP = (
    (1, 'Rounded'),
    (2, 'Straight-edged'),
    (-888, 'ND')
)

EAR_ORNT = (
    (1, 'Erect'),
    (2, 'Lateral'),
    (3, 'Dropping'),
    (-888, 'ND')
)

TAIL_LN = (
    (1, 'Short'),
    (2, 'Medium'),
    (3, 'Long'),
    (-888, 'ND')
)

TAIL_TH = (
    (1, 'Narrow'),
    (2, 'Medium'),
    (3, 'Wide'),
    (-888, 'ND')
)

UDD_SZ = (
    (1, 'Small'),
    (2, 'Medium'),
    (3, 'Large'),
    (-888, 'ND')
)

UDD_TEAT = (
    (1, 'Rudimentary'),
    (2, 'Medium'),
    (3, 'Large'),
    (-888, 'ND')
)

LESION_SCORES = {
    'first_digit': (
        'Right',
        'Left',
        'Bilateral',
        'ND'
    ),
    'second_digit': (
        'Focal',
        'Multi-focal',
        'Diffuse',
        'Mix of Focal / Multifocal',
        'Mix of Focal / Diffuse',
        'Mix of Multifocal / Diffuse',
        'ND',
        'NA'
    )
}
SUBJ_DAM = (
    ('1', 'Apparently Well'),
    ('2', 'Wounded'),
    ('3', 'Sick'),
    ('4', 'Dying'),
    ('-888', 'ND')
)

CS_DAM = (
    (1, 'L- [1]'),
    (1.5, 'L-/L [1.5]'),
    (2, 'L [2]'),
    (2.5, 'L/L+ [2.5]'),
    (3, 'L+ [3]'),
    (3.5, 'L+/M- [3.5]'),
    (4, 'M- [4]'),
    (4.5, 'M-/M [4.5]'),
    (5, 'M [5]'),
    (5.5, 'M/M+ [5.5]'),
    (6, 'M+ [6]'),
    (6.5, 'M+/F- [6.5]'),
    (7, 'F- [7]'),
    (7.5, 'F-/F [7.5]'),
    (8, 'F [8]'),
    (8.5, 'F/F+ [8.5]'),
    (9, 'F+ [9]'),
    (-888, 'ND')
)

LOSSFOLLOWD = (
    ('0', 'No'),
    ('1', 'Yes'),
    ('-888', 'ND')
)

COLOURS_CHART = {
    '1': ('#000000',),
    '2': ('#FFFFFF',),
    '3': ('#FFEFDF',),
    '4': ('#FFFFE5',),
    '5': ('#D9CDAB',),
    '6': ('#C7A987', '#CE945A',),
    '7': ('#BDA769', '#DECE84',),
    '8': ('#996633',),
    '9': ('#922D00',),
    '10': ('#6E2E00',),
    '11': ('#563C20',),
    '12': ('#58382E',),
    '13': ('#BE5F00',),
    '14': ('#C64200',),
    '15': ('#EC3800',),
    '16': ('#C02C0E',),
    '17': ('#9E8682',),
    '18': ('#98716C',),
    '19': ('#F2F2F2',),
    '20': ('#E3E4E9',),
    '21': ('#CECECE',),
    '22': ('#808080',),
    '23': ('#585858',),
    '24': ('#A953FF',),
    '25': ('#E5FFFF',),
    '26': ('#C4D1E2',),
    '27': ('#C7CDE9',),
    '28': ('#A2CBD8',),
    '29': ('#F5EBFF',),
    '30': ('#FDEBEE',),
    '31': ('#E4B9B8',),
    '32': ('#C5A3B1',),
    '33': ('#FBBA9D',),
    '34': ('#FFDBA7',),
    '35': ('#FFC56F', '#CE9C00',),
    '36': ('#F89400',),
}

PM_DONE = (
    ('1', 'Yes'),
    ('ND','ND'),
)

MULTIPLE_SELECT_HELP = 'Hold CTRL or &#8984; to select multiple entries.'

