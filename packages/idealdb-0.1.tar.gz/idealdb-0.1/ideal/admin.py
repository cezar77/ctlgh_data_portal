from django.contrib import admin

from .models import Sampleinfo


class SampleinfoAdmin(admin.ModelAdmin):
    list_display = ('id', 'calfid', 'damid', 'visitid', 'sampleid',
        'storelabel')
    search_fields = ('calfid', 'damid', 'visitid', 'sampleid', 'storelabel')
    list_filter = ('tank',)
    fields = ('calfid', 'damid', 'visitid', 'sampleid', 'storelabel',
        'visittype', 'sampletype', 'storetype', 'tank', 'sector', 'boxnum',
        'boxposition', 'samplepos', 'comments')
    readonly_fields = ('calfid', 'damid', 'visitid', 'sampleid', 'storelabel',
        'visittype', 'sampletype', 'storetype', 'tank', 'sector', 'boxnum',
        'boxposition', 'samplepos')


admin.site.register(Sampleinfo, SampleinfoAdmin)
