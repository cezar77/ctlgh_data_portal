import os

from django.contrib import admin
from django.conf.urls import url
from django.urls import reverse
from django.template.response import TemplateResponse

from .apps import IdealConfig
from .models import Sampleinfo

APP_DIR = os.path.dirname(os.path.abspath(__file__))


class Node:
    """
    Helper object to represent directories and files.
    """
    def __init__(self, name, path=''):
        self.name = name
        self.path = path
        self.children = []

    def __str__(self):
        return self.name

    def __hash__(self):
        return hash(self.name)

    def __eq__(self, other):
        return self.name == other.name

    def __ne__(self, other):
        return not(self == other)

    def __lt__(self, other):
        return self.name < other.name

    def __le__(self, other):
        return self.name <= other.name

    def __gt__(self, other):
        return self.name > other.name

    def __ge__(self, other):
        return self.name >= other.name

    def add_child(self, child):
        self.children.append(child)


class IDEALAdmin(admin.AdminSite):
    site_header = 'IDEAL'
    site_title = 'IDEAL admin'
    index_title = 'Welcome to the IDEAL admin'
    index_template = 'ideal/admin/index.html'
    app_index_template = 'ideal/admin/app_index.html'
    login_template = 'ideal/admin/login.html'

    def _build_app_dict(self, request, label=None):
        gallery = {
            'name': 'Gallery',
            'admin_url': reverse('ideal:gallery-list'),
            'object_name': 'Gallery',
            'perms': {'delete': False, 'add': False, 'change': False},
            'add_url': ''
        }
        app_dict = super(IDEALAdmin, self)._build_app_dict(request, label)
        if label:
            app_dict['models'].append(gallery)
        else:
            app = app_dict.get(IdealConfig.name, None)
            if app:
                app['models'].append(gallery)
        return app_dict

    def get_urls(self):
        urls = super(IDEALAdmin, self).get_urls()
        urlpatterns = [
            url(
                r'^gallery/$',
                self.admin_view(self.gallery_list),
                name='gallery-list'
            ),
            url(
                r'^gallery/(?P<directory>[\w-]+)/$',
                self.admin_view(self.gallery_detail),
                name='gallery-detail'
            ),
        ]
        return urlpatterns + urls

    def gallery_list(self, request):
        context = dict(self.each_context(request))
        root = 'static/ideal/pictures/'
        context['directories'] = [directory for directory in self.get_directories(root)]
        return TemplateResponse(request, 'ideal/gallery_list.html', context)

    def gallery_detail(self, request, directory):
        context = dict(self.each_context(request))
        root = 'static/ideal/pictures/{}'.format(directory)
        context['directory_tree'] = self.get_directory_tree(root).children
        context['directory'] = directory
        return TemplateResponse(request, 'ideal/gallery_detail.html', context)

    def get_directories(self, root):
        return os.listdir(os.path.join(APP_DIR, root))

    def get_directory_tree(self, root):
        name = root.split(os.sep)[-1]
        directory = Node(name)
        for item in os.listdir(os.path.join(APP_DIR, root)):
            path = os.path.join(root, item)
            if os.path.isdir(os.path.join(APP_DIR, path)):
                directory.children.append(self.get_directory_tree(path))
            else:
                directory.children.append(Node(item, path))
        directory.children.sort()
        return directory


class SampleinfoAdmin(admin.ModelAdmin):
    list_display = ('id', 'calfid', 'damid', 'visitid', 'sampleid',
        'storelabel')
    search_fields = ('calfid', 'damid', 'visitid', 'sampleid', 'storelabel')
    list_filter = ('tank',)
    fields = ('calfid', 'damid', 'visitid', 'sampleid', 'storelabel',
        'visittype', 'sampletype', 'storetype', 'tank', 'sector', 'boxnum',
        'boxposition', 'samplepos', 'comments')
    readonly_fields = ('calfid', 'damid', 'visitid', 'sampleid', 'storelabel',
        'visittype', 'sampletype', 'storetype', 'tank', 'sector', 'boxnum',
        'boxposition', 'samplepos')

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


ideal_admin = IDEALAdmin(name='ideal')
ideal_admin.register(Sampleinfo, SampleinfoAdmin)
