import re
from functools import reduce

from django.db.models import Q
from django import forms

import django_filters as filters

from .models import (
    Farminfo,
    Daminfo,
    Calfinfo,
    Testinfo,
    Clinicalinfo,
    Postmorteminfo,
    Sampleinfo,
)
from .helper.models import (
    HelpertableTest,
    HelpertablePathogen,
    HelpertableLesioncat,
    HelpertableLesiontype
)
from . import constants


def get_sublocations():
    queryset = Farminfo.objects.all()
    sublocations = queryset.values_list(
        'sublocation_id', 'sublocation'
    ).distinct()
    output = ()
    for sublocation in sublocations:
        output += ((
            sublocation[0],
            '{} ({})'.format(sublocation[1], sublocation[0])
        ),)
    return output


def get_calf_disorders():
    disorders = []
    qs = Calfinfo.objects.all()
    for o in qs:
        if o.cprobcat:
            options = o.cprobcat.split(';')
            for option in options:
                if option.strip() not in disorders:
                    disorders.append(option.strip())
    disorders.remove('Blank (add)')
    disorders.sort()
    return [(i, i) for i in disorders]


def get_calf_lesion_types():
    disorders = []
    qs = Calfinfo.objects.all()
    for o in qs:
        if o.clestype:
            options = o.clestype.split(';')
            for option in options:
                if option.strip() not in disorders:
                    disorders.append(option.strip())
    disorders.sort()
    return [(i, i) for i in disorders]


def get_herd_disorders():
    disorders = []
    qs = Calfinfo.objects.all()
    for o in qs:
        if o.hprobcat:
            options = o.hprobcat.split(';')
            for option in options:
                if option.strip() not in disorders:
                    disorders.append(option.strip())
    disorders.remove('ND')
    disorders.sort()
    return [(i, i) for i in disorders]


def get_herd_lesion_types():
    disorders = []
    qs = Calfinfo.objects.all()
    for o in qs:
        if o.hlestype:
            options = o.hlestype.split(';')
            for option in options:
                if option.strip() not in disorders:
                    disorders.append(option.strip())
    disorders.remove('ND')
    disorders.sort()
    return [(i, i) for i in disorders]


class TextareaCSVWidget(filters.widgets.BaseCSVWidget, forms.Textarea):
    def render(self, name, value, attrs=None):
        if not self._isiterable(value):
            value = [value]

        if len(value) <= 1:
            value = value[0] if value else ''
            return super(TextareaCSVWidget, self).render(name, value, attrs)

        value = ','.join(value)
        return super(TextareaCSVWidget, self).render(name, value, attrs)


class CharInFilter(filters.BaseInFilter, filters.CharFilter):
    pass


class FarminfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    farmer_ids = CharInFilter(
        name='farmer_id',
        label='Farmer ID is in',
        widget=TextareaCSVWidget()
    )
    dam_ids = CharInFilter(
        name='dam_id',
        label='Dam ID is in',
        widget=TextareaCSVWidget()
    )
    calf_id = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    farmer_id = filters.CharFilter(
        label='Farmer ID contains',
        lookup_expr='icontains'
    )
    dam_id = filters.CharFilter(
        label='Dam ID contains',
        lookup_expr='icontains'
    )
    calf_sex = filters.ChoiceFilter(
        label='Calf sex',
        empty_label='-- Choose calf sex --',
        choices=(('F', 'Female'), ('M', 'Male'))
    )
    calf_date_of_birth = filters.DateFromToRangeFilter(
        label='Calf date of birth',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Births occured between Oct 2007 and Sept 2009'
    )
    sublocation_id = filters.MultipleChoiceFilter(
        label='Sublocation where household is located',
        choices=get_sublocations,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    farmer_sex = filters.ChoiceFilter(
        label='Farmer sex',
        empty_label='-- Choose farmer sex --',
        choices=(('F', 'Female'), ('M', 'Male'))
    )
    farmer_age = filters.RangeFilter(
        label='Age of the farmer in years',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 16,
                'max': 128,
            }
        ),
        help_text='Farmers age ranges between 20 and 85, it is unknown for some individuals'
    )
    education = filters.MultipleChoiceFilter(
        label='Highest level of education of the farmer',
        choices=Farminfo.objects.all().values_list(
                                         'education',
                                         'education'
                                       ).distinct(),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    training = filters.ChoiceFilter(
        label='Does the farmer have any technical training?',
        empty_label='-- Choose technical training status --',
        choices=Farminfo.objects.all().values_list(
                                         'training',
                                         'training'
                                       ).distinct()
    )
    position = filters.MultipleChoiceFilter(
        label='Position of farmer in the household',
        choices=constants.POSITION,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    occupation = filters.ChoiceFilter(
        label='Is the main occupation of the farmer listed as a farmer on not?',
        empty_label='-- Choose occupation --',
        choices=Farminfo.objects.all().values_list(
                                         'occupation',
                                         'occupation'
                                       ).distinct()
    )
    dam_age = filters.RangeFilter(
        label='Age of dam (years) as estimated by farmer',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 0.5,
                'min': 0,
            }
        ),
        help_text='Dam age ranges between 1 and 15, it is unknown for some individuals'
    )
    dam_calvings = filters.RangeFilter(
        label=('Number of calvings undergone by dam including the calving of '
               'recruited calf'),
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 0,
            }
        ),
        help_text='Number of calvings range between 1 and 9, it is unknown for some individuals'
    )
    bull_origin = filters.MultipleChoiceFilter(
        label='Origin of bull that fathered the calf',
        choices=Farminfo.objects.all().values_list(
                                         'bull_origin',
                                         'bull_origin'
                                       ).distinct().order_by(
                                         'bull_origin'
                                       ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    bull_type = filters.MultipleChoiceFilter(
        label=('Type of bull that fathered the calf (i.e. indigenous, exotic '
               'or cross)'),
        choices=Farminfo.objects.all().values_list(
                                         'bull_type',
                                         'bull_type'
                                       ).distinct().order_by(
                                         'bull_type'
                                       ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    milked_prior_calving = filters.BooleanFilter(
        label='Whether the dam was milked on the week before calving'
    )
    milked_post_calving = filters.BooleanFilter(
        label='Whether the dam was milked on the week after calving'
    )
    milked_prior_colostrum = filters.BooleanFilter(
        label=('After calving, whether the dam was milked prior to the calf '
               'suckling colostrum')
    )
    calf_suckled = filters.BooleanFilter(
        label=('Whether the calf suckled directly from dam within 24 hours of '
               'birth')
    )
    housing_dry = filters.MultipleChoiceFilter(
        label= 'Type of housing provided to cattle during the dry season',
        choices=constants.HOUSING_TYPE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    housing_wet = filters.MultipleChoiceFilter(
        label= 'Type of housing provided to cattle during the wet season',
        choices=constants.HOUSING_TYPE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    number_of_cattle = filters.RangeFilter(
        label='Total number of cattle on the farm at the time of recruitment',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 0,
                'style': 'width:40%;'
            }
        ),
        help_text='Number of cattle ranges between 1 and 131, it is unknown for some individuals'
    )

    class Meta:
        model = Farminfo
        exclude = (
            'sublocation', 'longitude', 'latitude', 'altitude',
            'selling_point', 'market', 'cattle_kept_w_chicken',
            'dam_born_in_household', 'dam_time_at_farm', 'milked_prior_time',
            'milked_prior_frequency', 'milked_post_frequency',
            'milked_prior_colostrum', 'calf_suckled_alternative',
            'navel_desinfected', 'land_ownership', 'total_acres_used',
            'total_acres_leased', 'crops', 'diseases', 'housing_calves',
            'roof_dry', 'roof_wet', 'wall_dry', 'wall_wet', 'floor_dry',
            'floor_wet', 'nutritional_supplements', 'vaccine',
            'veterinary_support', 'watered_dry', 'watered_wet',
            'water_distance_dry', 'water_distance_wet',
            'watering_frequency_dry', 'watering_frequency_wet',
            'water_quality_dry', 'water_quality_wet', 'grazed_with_adults',
            'number_of_chicken', 'number_of_dogs', 'number_of_sheep',
            'number_of_goats', 'number_of_pigs',
            'disease_cat', 'disease_type', 'treatment_cat', 'treatment_type',
            'ectoparasites_method', 'ectoparasites_cat', 'ectoparasites_type',
            'ectoparasites_freqdry', 'ectoparasites_freqwet',
            'endoparasites_method', 'endoparasites_cat', 'endoparasites_type',
            'endoparasites_freqdry', 'endoparasites_freqwet',
            'trypanosoma_method', 'trypanosoma_cat', 'trypanosoma_type',
            'trypanosoma_freqdry', 'trypanosoma_freqwet', 'vaccine_type',
            'vaccine_freq', 'vet_assit'
        )
        fields = (
            'calf_ids',  'dam_ids', 'farmer_ids', 'calf_id', 'dam_id',
            'farmer_id'
        )


class DaminfoFilter(filters.FilterSet):
    dam_ids = CharInFilter(
        name='dam_id',
        label='Dam ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visitid',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    dam_id = filters.CharFilter(
        label='Dam ID contains',
        lookup_expr='icontains'
    )
    visitid = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    breed = filters.ChoiceFilter(
        label='Breed of the dam',
        empty_label='-- Select a breed --',
        choices=Daminfo.objects.values_list('breed', 'breed').distinct()
    )
    local_name = filters.MultipleChoiceFilter(
        label='Local name for the breed of the dam',
        choices=Daminfo.objects.exclude(
          local_name=None
        ).values_list(
            'local_name', 'local_name').distinct().order_by('local_name'),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    visitdate = filters.DateFromToRangeFilter(
        label='Date of visit',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Visits occured between Oct 2007 and Sept 2010'
    )
    visit_type = filters.MultipleChoiceFilter(
        label='Visit type  (i.e. recruitment, 5-weekly, final)',
        choices=Daminfo.objects.values_list(
            'visit_type', 'visit_type').distinct(),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    lossfollowd = filters.ChoiceFilter(
        label='Whether or not dam is available for visit',
        empty_label='-- Choose dam availability at visit --',
        choices=(('0', 'No'), ('1', 'Yes'))
    )
    reasonsloss = filters.ChoiceFilter(
        label='Reason for dam lost to follow-up before the final visit',
        empty_label='-- Choose reason for dam loss to follow-up --',
        choices=Daminfo.objects.all().values_list(
            'reasonsloss', 'reasonsloss'
        ).distinct()
    )
    girthdam = filters.RangeFilter(
        label='Girth of dam (cm)',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 100,
                'max': 250,
            }
        ),
        help_text='Girth ranges from 110cam to 228cm, it is unknown for some visits'
    )
    subjdam = filters.MultipleChoiceFilter(
        label='Subjective assessment of the health of the dam at the visit',
        choices=constants.SUBJ_DAM,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    csdam = filters.MultipleChoiceFilter(
        label='Condition score of the dam',
        choices=constants.CS_DAM,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    uareadam = filters.ChoiceFilter(
        label=('Whether the ventral surface around the udder appears normal '
               'during examination'),
        empty_label='-- Choose udder area status --',
        choices=Daminfo.objects.filter(uareadam__isnull=False).values_list(
            'uareadam', 'uareadam').distinct()
    )
    lnudderdam = filters.ChoiceFilter(
        label=('Whether the udder lymph nodes appears normal during '
               'examination'),
        empty_label='-- Choose lymph node status --',
        choices=Daminfo.objects.filter(lnudderdam__isnull=False).values_list(
            'lnudderdam', 'lnudderdam'
        ).distinct()
    )
    mastitis = filters.ChoiceFilter(
        name='cmtlfq',
        label='California mastitis test result',
        empty_label='-- Choose California mastitis test result --',
        choices=(
            ('0', 'Negative'),
            ('1', 'Mild'),
            ('2', 'Moderate'),
            ('3', 'Heavy, almost solid')
        ),
        method='filter_mastitis'
    )

    class Meta:
        model = Daminfo
        # fill in all fields that should be excluded from searching
        exclude = ('calf_ids','calf_id',
            'pattern', 'hair', 'bodyht_f', 'bodyln_f', 'bodyln_f',
            'dewlap_size', 'hump_f', 'hump_orn', 'hump_loc', 'face',
            'back_pf', 'rump_pf', 'horn_f', 'horn_shape', 'horn_ornt',
            'spac_hrn', 'lnth_hrn', 'nvl_sz', 'ear_sz', 'ear_shp', 'ear_ornt',
            'tail_ln', 'tail_th', 'udd_sz', 'udd_teat', 'hwd','sthd', 'bld',
            'front_udder_lesion_dam', 'back_udder_lesion_dam',
            'front_teat_lesion_dam', 'back_teat_lesion_dam',
            'front_content_lesion_dam', 'back_content_lesion_dam', 'leslndam',
            'polelndam', 'lesvadam', 'body_colour_predominant',
            'body_colour_second', 'body_colour_third', 'body_colour_fourth',
            'body_colour_fifth', 'head_colour_predominant',
            'head_colour_second', 'head_colour_third', 'head_colour_fourth',
            'ear_colour_predominant', 'ear_colour_second', 'ear_colour_third',
            'tail_colour_predominant', 'tail_colour_second',
            'tail_colour_third', 'hoof_colour_predominant',
            'hoof_colour_second', 'hoof_colour_third',
            'muzzle_colour_predominant', 'muzzle_colour_second',
            'cmtlfq', 'cmtrfq', 'cmtlhq', 'cmtrhq','lastvisitwithdata',
            'datelastvisitwithdata', 'typeloss'
        )
        fields = (
             'dam_ids', 'visit_ids',  'dam_id',
            'visitid', 'breed', 'local_name', 'visitdate', 'visit_type',
            'lossfollowd',  'reasonsloss', 'girthdam', 'subjdam', 'csdam',
            'uareadam', 'lnudderdam', 'mastitis'
        )

    def filter_mastitis(self, queryset, name, value):
        queryset = queryset.filter(
            Q(cmtlfq__contains=value) | Q(cmtrfq__contains=value) |
            Q(cmtlhq__contains=value) | Q(cmtrhq__contains=value)
        )
        return queryset


class CalfinfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visitid',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    calf_id = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    visitid = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    visitdate = filters.DateFromToRangeFilter(
        label='Date of visit',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Visits occured between Oct 2007 and Sept 2010'
    )
    visit_type = filters.MultipleChoiceFilter(
        label='Visit type  (i.e. recruitment, 5-weekly, final)',
        choices=Calfinfo.objects.values_list(
            'visit_type', 'visit_type').distinct(),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    ce = filters.ChoiceFilter(
        label=('Whether the calf presents with a clinical episode at the time '
               'of the current visit'),
        empty_label='-- Choose a clinical visit type --',
        choices=Calfinfo.objects.filter(ce__isnull=False).values_list(
              'ce', 'ce').distinct().order_by('-ce')
    )
    ceever = filters.ChoiceFilter(
        label=('Did the calf ever experience a clinical episode during '
               'its enrolment in the IDEAL project?'),
        empty_label='-- Choose a clinical episode status --',
        choices=Calfinfo.objects.filter(ceever__isnull=False).values_list(
              'ceever', 'ceever').distinct().order_by('-ceever')
    )
    deadalive = filters.MultipleChoiceFilter(
        label=('Did the calf survive until the end of the study period at '
               '51 weeks of age?'),
        choices=Calfinfo.objects.filter(deadalive__isnull=False).values_list(
              'deadalive', 'deadalive').distinct().order_by('-deadalive'),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    reasonsloss = filters.MultipleChoiceFilter(
        label='Reason for calf lost to follow-up before the final visit',
        choices=Calfinfo.objects.filter(reasonsloss__isnull=False).values_list(
            'reasonsloss', 'reasonsloss').distinct(),
    help_text=constants.MULTIPLE_SELECT_HELP
    )
    postmortemdone = filters.ChoiceFilter(
        label='Post-mortem done or not',
        empty_label='-- Choose whether or not a post-mortem was done --',
        choices=Calfinfo.objects.filter(postmortemdone__isnull=False).values_list(
            'postmortemdone', 'postmortemdone').distinct()
    )
    cadob = filters.DateFromToRangeFilter(
        label='Calf date of birth',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        )
    )
    calfsex = filters.ChoiceFilter(
        label='Calf sex',
        empty_label='-- Choose calf sex --',
        choices=(('F', 'Female'), ('M', 'Male'))
    )
    rappend = filters.MultipleChoiceFilter(
        label='Level of infestation with adult Rhipicephalus appendiculatus',
        choices=sorted(
            Calfinfo.objects.values_list('rappend', 'rappend').exclude(
                     rappend__isnull=True
                ).distinct().order_by('rappend'),
            key=lambda x: 1 if re.match(r'[A-Z]{2}', x[0]) else 0
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    ammbly = filters.MultipleChoiceFilter(
        label='Level of infestation with adult Amblyomma spp.',
        choices=sorted(
            Calfinfo.objects.values_list('ammbly', 'ammbly').exclude(
                ammbly__isnull=True).distinct().order_by('ammbly'),
            key=lambda x: 1 if re.match(r'[A-Z]{2}', x[0]) else 0
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    booph = filters.MultipleChoiceFilter(
        label='Level of infestation with adult Boophilus spp.',
        choices=sorted(
            Calfinfo.objects.values_list('booph', 'booph').exclude(
                booph__isnull=True).distinct().order_by('booph'),
            key=lambda x: 1 if re.match(r'[A-Z]{2}', x[0]) else 0
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    hyalomm = filters.MultipleChoiceFilter(
        label='Level of infestation with adult Hyalomma spp.',
        choices=sorted(
            Calfinfo.objects.values_list('hyalomm', 'hyalomm').exclude(
                hyalomm__isnull=True).distinct().order_by('hyalomm'),
            key=lambda x: 1 if re.match(r'[A-Z]{2}', x[0]) else 0
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    other_tick_louse = filters.MultipleChoiceFilter(
        label='Level of infestation with other tick species',
        choices=sorted(
            Calfinfo.objects.values_list(
                'other_tick_louse', 'other_tick_louse'
            ).exclude(other_tick_louse__isnull=True).distinct().order_by(
                'other_tick_louse'),
            key=lambda x: 1 if re.match(r'[A-Z]{2}', x[0]) else 0
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    lice = filters.MultipleChoiceFilter(
        label='Level of infestation with lice',
        choices=sorted(
            Calfinfo.objects.values_list('lice', 'lice').exclude(
                lice__isnull=True).distinct().order_by('lice'),
            key=lambda x: 1 if re.match(r'[A-Z]{2}', x[0]) else 0
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    fleas = filters.MultipleChoiceFilter(
        label='Level of infestation with fleas',
        choices=sorted(
            Calfinfo.objects.values_list('fleas', 'fleas').exclude(
                fleas__isnull=True).distinct().order_by('fleas'),
            key=lambda x: 1 if re.match(r'[A-Z]{2}', x[0]) else 0
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    girth = filters.RangeFilter(
        label='Girth of calf (cm)',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 20,
                'max': 150,
            }
        ),
        help_text='Girth ranges from 25cm to 125cm, it is unknown for some visits'
    )
    weight = filters.RangeFilter(
        label='Weight of calf (kg)',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 5,
                'max': 150,
            }
        ),
        help_text='Weight ranges from 8kg to 145kg, it is unknown for some visits'
    )
    suckling = filters.ChoiceFilter(
        label=('Whether the calf is still suckling milk from the dam at the'
                 'current visit'),
        empty_label='-- Select a suckling status --',
        choices=Calfinfo.objects.all().values_list(
            'suckling', 'suckling').distinct()
    )
    suckling = filters.ChoiceFilter(
        label=('Whether the calf is still suckling milk from the dam at the'
                 'current visit'),
        empty_label='-- Select a suckling status --',
        choices=Calfinfo.objects.filter(suckling__isnull=False).values_list(
            'suckling', 'suckling').distinct()
    )
    grazing = filters.ChoiceFilter(
        label=('Whether the calf has started to go out grazing with adults'
                 'at the time of the current visit'),
        empty_label='-- Select a grazing status --',
        choices=Calfinfo.objects.filter(grazing__isnull=False).values_list(
            'grazing', 'grazing').distinct().order_by('-grazing')
    )
    rt = filters.RangeFilter(
        label='Rectal temperature at the time of the current visit',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 30,
                'min': 1,
                'max': 45,
            }
        ),
        help_text='Rectal temperature ranges from 33°C to 42°C, it is unknown for some visits'
    )
    f_consist = filters.MultipleChoiceFilter(
        label='The consistency of the faeces at the the current visit',
        choices=sorted(
            Calfinfo.objects.values_list('f_consist', 'f_consist').exclude(
                f_consist__isnull=True).distinct().order_by('-f_consist'),
            key=lambda x: 1 if re.match(r'[A-Z]{2}', x[0]) else 0
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    hprobcat = filters.MultipleChoiceFilter(
        label=('All herd health disorders observed during the inspection at '
                 'rest and from the time of the last inter-visit history till '
                 'present'),
        choices=get_herd_disorders,
        method='filter_disorders',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    hlestype = filters.MultipleChoiceFilter(
        label=('All herd health disorders observed during the inspection at '
                 'rest and from the time of the last inter-visit history till '
                 'present'),
        choices=get_herd_lesion_types,
        method='filter_disorders',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    bites = filters.ChoiceFilter(
        name='cynb',
        label=('History of animal bites for all cattle in the herd from the '
               'time of the last inter-visit history till present '),
        empty_label='-- Choose animal bite status --',
        choices=(
            ('Yes', 'Yes'),
            ('No', 'No'),
            ('ND', 'ND'),
        ),
        method='filter_bites'
    )
    vtcalfyn = filters.ChoiceFilter(
        label=('Whether the calf has benefited from any sort of veterinary '
                 'intervention since the time of the last inter-visit history '
                 'till present'),
        empty_label='-- Select veterinary intervention (calf) --',
        choices=Calfinfo.objects.filter(vtcalfyn__isnull=False).values_list(
            'vtcalfyn', 'vtcalfyn').distinct().order_by('-vtcalfyn')
    )
    vtdamyn = filters.ChoiceFilter(
        label=('Whether the dam has benefited from any sort of veterinary '
                 'intervention since the time of the last inter-visit history '
                 'till present'),
        empty_label='-- Select veterinary intervention (dam) --',
        choices=Calfinfo.objects.filter(vtdamyn__isnull=False).values_list(
            'vtdamyn', 'vtdamyn').distinct().order_by('-vtdamyn')
    )
    vtherdyn = filters.ChoiceFilter(
        label=('Whether other cattle in the herd has benefited from any '
                 'sort of veterinary intervention since the time of the last '
                 'inter-visit history till present'),
        empty_label='-- Select veterinary intervention (herd) --',
        choices=Calfinfo.objects.filter(vtherdyn__isnull=False).values_list(
            'vtherdyn', 'vtherdyn').distinct().order_by('-vtherdyn')
    )

    class Meta:
        model = Calfinfo
        exclude = ('dam_ids', 'dam_id',
            'lossfollow','typeloss', 'hrsscm', 'hlsscm', 'hrpccm', 'hlpccm', 'famacha_l',
            'famacha_r', 'elasticity','diaorseverity', 'diaorkind',
            'diaorodour', 'observedby', 'damaffected', 'percentherd','cynb',
            'dynb', 'hynb', 'vetinter_calf_cattto', 'vetinter_calf_typetto',
            'vetinter_calf_typeapplic', 'vetinter_dam_cattto',
            'vetinter_dam_typetto', 'vetinter_dam_typeapplic',
            'vetinter_herd_cattto', 'vetinter_herd_typetto',
            'vetinter_herd_typeapplic', 'vetinter_herd_nherdtto',
            'currentnumbercattle', 'totalentries', 'totaldeaths',
            'totalexits', 'animalcatdead', 'numdeadanicat', 'whydead',
            'calfdonev','breed', 'local_name', 'pattern', 'body_colours',
            'head_colours', 'ear_colours', 'tail_colours', 'hoof_colours',
            'muzzle_colours', 'hair', 'hair_typ', 'dewlap_size', 'hump_size',
            'hump_orientation', 'hump_location', 'face', 'back_profile',
            'rump_profile', 'horn_presence', 'horn_shape', 'horn_orientation',
            'horn_spacing', 'horn_length', 'naval_flap_size', 'ear_size',
            'ear_shape','ear_orientation', 'tail_length', 'tail_thickness',
            'udder_size', 'teats_size', 'testis', 'perpuce', 'hwc', 'sthc',
            'blc', 'body_colour_predominant', 'body_colour_second',
            'body_colour_third', 'body_colour_fourth', 'body_colour_fifth',
            'head_colour_predominant', 'head_colour_second',
            'head_colour_third', 'head_colour_fourth', 'head_colour_fifth',
            'ear_colour_predominant', 'ear_colour_second', 'ear_colour_third',
            'tail_colour_predominant', 'tail_colour_second',
            'tail_colour_third', 'hoof_colour_predominant',
            'hoof_colour_second', 'hoof_colour_third',
            'muzzle_colour_predominant', 'muzzle_colour_second',
            'lastvisitwithdata', 'datelastvisitwithdata','reasonspmnotdone',
            'dam_ids', 'dam_id'
        )
        fields = (
            'calf_ids',  'visit_ids', 'calf_id',
            'visitid', 'visitdate', 'visit_type','ce', 'ceever', 'deadalive',
            'reasonsloss', 'postmortemdone', 'cadob', 'calfsex', 'girth',
            'weight', 'rappend', 'ammbly', 'booph', 'hyalomm',
            'other_tick_louse', 'lice', 'fleas', 'suckling', 'grazing', 'rt',
            'f_consist', 'hprobcat', 'hlestype', 'bites', 'vtcalfyn',
            'vtdamyn', 'vtherdyn'
        )

    def filter_bites(self, queryset, name, value):
        queryset = queryset.filter(
            Q(cynb=value) | Q(dynb=value) | Q(hynb=value)
        )
        return queryset

    def filter_disorders(self, queryset, name, value):
        query = reduce(
            lambda q1, q2: q1 | q2,
            (Q(**{name+'__contains': v}) for v in value), Q()
        )
        print(query)
        queryset = queryset.filter(query)
        return queryset


class TestinfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    dam_ids = CharInFilter(
        name='calf_id',
        label='Dam ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visit_id',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    result_ids = CharInFilter(
        name='result_id',
        label='Result ID is in',
        widget=TextareaCSVWidget()
    )
    calf_id = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    dam_id = filters.CharFilter(
        label='Dam ID contains',
        lookup_expr='icontains'
    )
    visit_id = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    result_id = filters.CharFilter(
        label='Result ID contains',
        lookup_expr='icontains'
    )
    visitdate = filters.DateFromToRangeFilter(
        label='Date of visit',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Visits occured between Oct 2007 and Sept 2010'
    )
    samplecode = filters.MultipleChoiceFilter(
        label='Sample code contains',
        choices=sorted(
            Testinfo.objects.exclude(
                samplecode__isnull=True
            ).values_list(
                'samplecode', 'samplecode'
            ).distinct()
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    test = filters.MultipleChoiceFilter(
        label='Test',
        choices=HelpertableTest.objects.all().values_list('id', 'name'),
        method='filter_tests',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    possiblepathogen = filters.MultipleChoiceFilter(
        label='Pathological agent',
        choices=HelpertablePathogen.objects.all().values_list(
            'pathogen', 'pathogen'
        ).distinct().order_by('pathogen'),
        method='filter_results',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    resultstatus = filters.MultipleChoiceFilter(
        label=('Status of the diagnostic test result'),
        choices=sorted(
            Testinfo.objects.exclude(resultstatus__isnull=True).values_list(
                'resultstatus', 'resultstatus'
            ).distinct()
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    resultnum = filters.NumericRangeFilter(
        label='Quantitiative result number is between',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 0.1
            }
        )
    )
    lifestage = filters.MultipleChoiceFilter(
        label='Life stage',
        choices=sorted(
            Testinfo.objects.filter(lifestage__isnull=False).values_list(
                'lifestage', 'lifestage').distinct()
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )

    class Meta:
        model = Testinfo
        exclude = ('samplegrouping',)
        fields = (
            'calf_ids','dam_ids','visit_ids', 'result_ids',)
        #'calf_id', 'visit_id',
        #    'result_id', 'rsid', 'test', 'result', 'samplecode',
        #    'samplegrouping', 'lifestage', 'pathogennumber', 'resultnum'
        #)

    def filter_tests(self, queryset, name, value):
        test = HelpertableTest.objects.filter(pk__in=value).values_list('name')
        return queryset.filter(test__in=test)

    def filter_results(self, queryset, name, value):
        result = HelpertablePathogen.objects.filter(
            pathogen__in=value
        ).values_list('pathogen')
        return queryset.filter(possiblepathogen__in=result)


class ClinicalinfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visitid',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    calfid = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    visitid = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    lescat = filters.MultipleChoiceFilter(
        label='Select disorder/lesion category (i.e. gastrointestinal, superficial lymphnodes etc.)',
        choices=HelpertableLesioncat.objects.values_list(
            'id', 'lesion_cat'
        ),
        method='filter_lesion_categories',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    lestype = filters.MultipleChoiceFilter(
        label=('Select disorder/lesion type (i.e. diarrhoea, constipation, enlarged'
               'etc.)'),
        choices=HelpertableLesiontype.objects.values_list(
            'lesion_type', 'lesion_type'
        ).distinct().order_by('lesion_type'),
        method='filter_lesion_types',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    position = filters.MultipleChoiceFilter(
        label='Select by position of lesion<br/>&nbsp;',
        choices=sorted(
            Clinicalinfo.objects.filter(
                position__isnull=False
            ).values_list(
                'position',
                'position'
            ).distinct(),
            key=lambda x: 1 if re.match(r'[A-Z]{2}', x[0]) else 0
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    extension_pattern_lesion = filters.MultipleChoiceFilter(
        label='Select by extension-pattern of the lesion',
        choices=sorted(
            Clinicalinfo.objects.filter(
                extension_pattern_lesion__isnull=False
            ).values_list(
                'extension_pattern_lesion',
                'extension_pattern_lesion'
            ).distinct(),
            key=lambda x: 1 if re.match(r'[A-Z]{2}', x[0]) else 0
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    lesion_location_capsule = filters.MultipleChoiceFilter(
        label=('Select by whether or not the lesion is located in the organs '
               'capsule or not'),
        choices=sorted(
            Clinicalinfo.objects.filter(
                lesion_location_capsule__isnull=False
            ).values_list(
                'lesion_location_capsule',
                'lesion_location_capsule'
            ).distinct(),
            key=lambda x: 1 if re.match(r'[A-Z]{2}', x[0]) else 0
        ),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    ccs = filters.MultipleChoiceFilter(
        label='Select by who observed the disorder/lesion',
        choices=Clinicalinfo.objects.filter(
                ccs__isnull=False
            ).values_list(
              'ccs',
              'ccs'
            ).distinct().order_by('ccs'),
        help_text=constants.MULTIPLE_SELECT_HELP
    )

    class Meta:
        model = Clinicalinfo
        exclude = ('other', 'bodypart','dam_ids', 'dam_id',)
        fields = (
           'calf_ids', 'visit_ids', 'calfid', 'visitid',
           'lescat', 'lestype', 'position', 'extension_pattern_lesion',
           'lesion_location_capsule', 'ccs'
        )

    def filter_lesion_categories(self, queryset, name, value):
        lesion_cat = HelpertableLesioncat.objects.filter(
            pk__in=value
        ).values_list('lesion_cat')
        return queryset.filter(lescat__in=lesion_cat)

    def filter_lesion_types(self, queryset, name, value):
        lesion_type = HelpertableLesiontype.objects.filter(
            lesion_type__in=value
        ).values_list('lesion_type')
        return queryset.filter(lestype__in=lesion_type)


class PostmorteminfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visitid',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    calfid = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    visitid = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    deathdate = filters.DateFromToRangeFilter(
        label='Date of death',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Deaths occured between Oct 2007 and Sept 2010'
    )
    euthanised = filters.ChoiceFilter(
        label='Calf euthanised or not',
        empty_label='-- Choose euthanised status --',
        choices=(('No', 'No'), ('Yes', 'Yes'))
    )
    pathology = filters.ChoiceFilter(
        name='immediate_cause_pathology',
        label='Immediate or contributing pathology cause of death',
        empty_label='-- Choose pathology --',
        choices=(
                 ('Anaemia', 'Anaemia'),
                 ('Anemia (whole blood loss)', 'Anemia (whole blood loss)'),
                 ('Anoxia', 'Anoxia'),
                 ('Asphyxia', 'Asphyxia'),
                 ('Bronchopneumonia', 'Bronchopneumonia'),
                 ('Cachexia', 'Cachexia'),
                 ('Cerebral oedema', 'Cerebral oedema'),
                 ('Chronic nephritis', 'Chronic nephritis'),
                 ('Circulating infected erythrocytes', 'Circulating infected erythrocytes'),
                 ('Circulating lymphoblasts', 'Circulating lymphoblasts'),
                 ('Diarrhoea', 'Diarrhoea'),
                 ('Diptheric enteritis', 'Diptheric enteritis'),
                 ('Dislocated fetlock joint', 'Dislocated fetlock joint'),
                 ('Endotoxic shock', 'Endotoxic shock'),
                 ('Eosinophilic pneumonia', 'Eosinophilic pneumonia'),
                 ('Fibrinous pneumonia', 'Fibrinous pneumonia'),
                 ('Generalised lymphoblastic infiltration', 'Generalised lymphoblastic infiltration'),
                 ('Glial cell oedema', 'Glial cell oedema'),
                 ('Hepatic necrosis', 'Hepatic necrosis'),
                 ('Hypoproteinaemia', 'Hypoproteinaemia'),
                 ('Interstitial lymphoblastosis', 'Interstitial lymphoblastosis'),
                 ('Interstitial pneumonia', 'Interstitial pneumonia'),
                 ('Intestinal mucosa inflammation', 'Intestinal mucosa inflammation'),
                 ('Loss of condition (weight loss)', 'Loss of condition (weight loss)'),
                 ('Lymphoblastic interstitial pneumonia', 'Lymphoblastic interstitial pneumonia'),
                 ('Lymphocytic interstitial pneumonia', 'Lymphocytic interstitial pneumonia'),
                 ('Lymphocytosis', 'Lymphocytosis'),
                 ('Lymphopaenia', 'Lymphopaenia'),
                 ('Multi-organ failure', 'Multi-organ failure'),
                 ('Nervous system abnormalities', 'Nervous system abnormalities'),
                 ('Pallor', 'Pallor'),
                 ('Periacinar to midzonal hepatic necrosis', 'Periacinar to midzonal hepatic necrosis'),
                 ('Pneumonia', 'Pneumonia'),
                 ('Pulmonary oedema', 'Pulmonary oedema'),
                 ('Renal failure', 'Renal failure'),
                 ('Right hind fracture', 'Right hind fracture'),
                 ('Rumenitis', 'Rumenitis'),
                 ('Septicaemia', 'Septicaemia'),
                 ('Soiling', 'Soiling'),
                 ('Starvation', 'Starvation'),
                 ('Toxaemia', 'Toxaemia'),
                 ('Toxicity', 'Toxicity'),
                 ('Viral hepatic necrosis', 'Viral hepatic necrosis'),
                 ('Viral pneumonia', 'Viral pneumonia'),
                 ('Weightloss/loss of condition', 'Weightloss/loss of condition'),
                 ('Unknown', 'Unknown'),
                 ('NA', 'NA')
        ),
        method='filter_pathology'
    )
    cause = filters.ChoiceFilter(
        name='definitive_aetiological_cause',
        label='Aetiological or contributing cause of death',
        empty_label='-- Choose cause of death --',
        choices=(
                 ('Actiomyces pyogenes', 'Actiomyces pyogenes'),
                 ('Adenovirus', 'Adenovirus'),
                 ('Anaplamosis', 'Anaplamosis'),
                 ('Arcanobacterium', 'Arcanobacterium'),
                 ('Babesiosis', 'Babesiosis'),
                 ('Bacterial pneumonia', 'Bacterial pneumonia'),
                 ('Black quarter', 'Black quarter'),
                 ('Cassava', 'Cassava'),
                 ('Dictyocaulus viviparous', 'Dictyocaulus viviparous'),
                 ('East coast fever', 'East coast fever'),
                 ('Foreign body', 'Foreign body'),
                 ('Haemonchosis', 'Haemonchosis'),
                 ('Heartwater', 'Heartwater'),
                 ('Helminthisasis', 'Helminthisasis'),
                 ('Lead poisoning', 'Lead poisoning'),
                 ('Malignant catarrhal fever', 'Malignant catarrhal fever'),
                 ('Mis-mothering', 'Mis-mothering'),           
                 ('Poor nutrition', 'Poor nutrition'),
                 ('Rabies', 'Rabies'),
                 ('Rotavirus', 'Rotavirus'),
                 ('Salmonellosis', 'Salmonellosis'),
                 ('Theileriosis', 'Theileriosis'),
                 ('Trauma', 'Trauma'),
                 ('Trypanosomiasis', 'Trypanosomiasis'),
                 ('Turning sickness', 'Turning sickness'),
                 ('Viral pneumonia', 'Viral pneumonia'),
                 ('Unknown', 'Unknown'),
                 ('NA', 'NA')
        ),
        method='filter_cause'
    )
    pathogen = filters.ChoiceFilter(
        name='definitive_cause_pathogen',
        label='Definitive or contributing pathogen which caused death',
        empty_label='-- Choose pathogen --',
        choices=(                 
                 ('No Pathogen Found', 'No Pathogen Found'),
                 ('Actinomyces sp.', 'Actinomyces sp.'),
                 ('Anaemia', 'Anaemia'),
                 ('Babesia spp.', 'Babesia spp.'),
                 ('Clostridium spp.', 'Clostridium spp.'),
                 ('Dictyocaulus viviparus (L1)', 'Dictyocaulus viviparus (L1)'),
                 ('Ehrlichia ruminatum', 'Ehrlichia ruminatum'),
                 ('Haemonchus placei', 'Haemonchus placei'),
                 ('Hepatic necrosis', 'Hepatic necrosis'),
                 ('Hypoproteinaemia', 'Hypoproteinaemia'),
                 ('IBR (Infectious bovine rhinochetius)', 'IBR (Infectious bovine rhinochetius)'),
                 ('Maligant Catarrahal Fever (MCR)', 'Maligant Catarrahal Fever (MCR)'),
                 ('Rotavirus', 'Rotavirus'),
                 ('Salmonella spp.', 'Salmonella spp.'),
                 ('Strongyle eggs', 'Strongyle eggs'),
                 ('Theileria parva', 'Theileria parva'),
                 ('Theileria spp.', 'Theileria spp.'),
                 ('Trypanosoma spp.', 'Trypanosoma spp.'),
                 ('Trypanosoma vivax', 'Trypanosoma vivax'),
                 ('Viral pneumonia', 'Viral pneumonia'),     
                 ('NA', 'NA')
        ),
        method='filter_pathogen'
    )

    class Meta:
        model = Postmorteminfo
        exclude = ('dam_ids', 'dam_id',
            'pm_comments', 'histopath_report', 'histo_aetiological_diagnosis',
            'histo_comments', 'stomach_content', 'immediate_cause_pathology',
            'definitive_aetiological_cause', 'definitive_cause_pathogen',
            'contributing_pathology_1', 'contributing_cause_1',
            'contributing_cause_pathogen_1', 'contributing_pathology_2',
            'contributing_cause_2', 'contributing_cause_pathogen_2'
        )
        fields = (
            'calf_ids', 'visit_ids', 'calfid', 'visitid',
            'deathdate', 'euthanised', 'pathology', 'cause', 'pathogen'
        )

    def filter_pathology(self, queryset, name, value):
        queryset = queryset.filter(
            Q(immediate_cause_pathology__contains=value) |
            Q(contributing_pathology_1__contains=value) |
            Q(contributing_pathology_2__contains=value)
        )
        return queryset

    def filter_cause(self, queryset, name, value):
        queryset = queryset.filter(
            Q(definitive_aetiological_cause__contains=value) |
            Q(contributing_cause_1__contains=value) |
            Q(contributing_cause_2__contains=value)
        )
        return queryset
    
    def filter_pathogen(self, queryset, name, value):
        queryset = queryset.filter(
            Q(definitive_cause_pathogen__contains=value) |
            Q(contributing_cause_pathogen_1__contains=value) |
            Q(contributing_cause_pathogen_2__contains=value)
        )
        return queryset


class SampleinfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    dam_ids = CharInFilter(
        name='damid',
        label='Dam ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visitid',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    sample_ids = CharInFilter(
        name='sampleid',
        label='Sample ID is in',
        widget=TextareaCSVWidget()
    )
    store_label = CharInFilter(
        name='storelabel',
        label='Store label is in',
        widget=TextareaCSVWidget()
    )
    calfid = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    damid = filters.CharFilter(
        label='Dam ID contains',
        lookup_expr='icontains'
    )
    visitid = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    sampleid = filters.CharFilter(
        label='Sample ID contains',
        lookup_expr='icontains'
    )
    storelabel = filters.CharFilter(
        label='Store label contains',
        lookup_expr='icontains'
    )
    visitdate = filters.DateFromToRangeFilter(
        label='Date of visit',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Visits occured between Oct 2007 and Sept 2010'
    )
    visittype = filters.MultipleChoiceFilter(
        label='Select the type of visit',
        choices=Sampleinfo.objects.all().values_list(
                                         'visittype',
                                         'visittype'
                                       ).distinct().order_by('visittype'),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    sampletype = filters.MultipleChoiceFilter(
        label='Select the type of sample taken',
        choices=Sampleinfo.objects.filter(
                    sampletype__isnull=False
                ).values_list(
                    'sampletype',
                    'sampletype'
                ).distinct().order_by('sampletype'),
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    storetype = filters.MultipleChoiceFilter(
        label='Select the type of sample stored',
        choices=Sampleinfo.objects.filter(
                    storetype__isnull=False
                ).values_list(
                    'storetype',
                    'storetype'
                ).distinct().order_by('storetype'),
        help_text=constants.MULTIPLE_SELECT_HELP
    )

    class Meta:
        model = Sampleinfo
        exclude = ()
        fields = (
            'calf_ids', 'dam_ids', 'visit_ids',  'calfid', 'damid', 'visitid',
            'sample_ids', 'store_label', 'sampleid','storelabel', 'visittype',
            'sampletype','storetype', 'visitdate'
        )
