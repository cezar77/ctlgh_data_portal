from functools import reduce

from django.db.models import Q
from django import forms

import django_filters as filters

from .models import (
    Farminfo,
    Daminfo,
    Calfinfo,
    Testinfo,
    Clinicalinfo,
    Postmorteminfo,
    Sampleinfo,
    Followupinfo
)
from .helper.models import (
    HelpertableTest,
    HelpertablePathogen,
    HelpertableLesioncat,
    HelpertableLesiontype
)
from . import constants
from . import choices


class TextareaCSVWidget(filters.widgets.BaseCSVWidget, forms.Textarea):
    def render(self, name, value, attrs=None):
        if not self._isiterable(value):
            value = [value]

        if len(value) <= 1:
            value = value[0] if value else ''
            return super(TextareaCSVWidget, self).render(name, value, attrs)

        value = ','.join(value)
        return super(TextareaCSVWidget, self).render(name, value, attrs)


class CharInFilter(filters.BaseInFilter, filters.CharFilter):
    pass


class FarminfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    farmer_ids = CharInFilter(
        name='farmer_id',
        label='Farmer ID is in',
        widget=TextareaCSVWidget()
    )
    dam_ids = CharInFilter(
        name='dam_id',
        label='Dam ID is in',
        widget=TextareaCSVWidget()
    )
    calf_id = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    farmer_id = filters.CharFilter(
        label='Farmer ID contains',
        lookup_expr='icontains'
    )
    dam_id = filters.CharFilter(
        label='Dam ID contains',
        lookup_expr='icontains'
    )
    calf_sex = filters.ChoiceFilter(
        label='Calf sex',
        empty_label='-- Choose calf sex --',
        choices=constants.SEXES
    )
    calf_date_of_birth = filters.DateFromToRangeFilter(
        label='Calf date of birth',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Births occurred between Oct 2007 and Sept 2009'
    )
    sublocation_id = filters.MultipleChoiceFilter(
        label='Sublocation where household is located',
        choices=choices.SUBLOCATION_ID,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    dam_age = filters.RangeFilter(
        label='Age of dam (years) as estimated by farmer',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 0.5,
                'min': 0,
            }
        ),
        help_text='Dam age ranges between 1 and 15, it is unknown for some individuals'
    )
    dam_calvings = filters.RangeFilter(
        label=('Number of calvings undergone by dam including the calving of '
               'recruited calf'),
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 0,
            }
        ),
        help_text='Number of calvings range between 1 and 9, it is unknown for some individuals'
    )
    bull_origin = filters.MultipleChoiceFilter(
        label='Origin of bull that fathered the calf',
        choices=choices.BULL_ORIGIN,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    bull_type = filters.MultipleChoiceFilter(
        label=('Type of bull that fathered the calf (i.e. indigenous, exotic '
               'or cross)'),
        choices=choices.BULL_TYPE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    milked_prior_calving = filters.BooleanFilter(
        label='Whether the dam was milked on the week before calving'
    )
    milked_post_calving = filters.BooleanFilter(
        label='Whether the dam was milked on the week after calving'
    )
    milked_prior_colostrum = filters.BooleanFilter(
        label=('After calving, whether the dam was milked prior to the calf '
               'suckling colostrum')
    )
    calf_suckled = filters.BooleanFilter(
        label=('Whether the calf suckled directly from dam within 24 hours of '
               'birth')
    )
    housing_dry = filters.MultipleChoiceFilter(
        label='Type of housing provided to cattle during the dry season',
        choices=constants.HOUSING_TYPE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    housing_wet = filters.MultipleChoiceFilter(
        label='Type of housing provided to cattle during the wet season',
        choices=constants.HOUSING_TYPE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    number_of_cattle = filters.RangeFilter(
        label='Total number of cattle on the farm at the time of recruitment',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 0,
                'style': 'width:40%;'
            }
        ),
        help_text='Number of cattle ranges between 1 and 131, it is unknown for some individuals'
    )

    class Meta:
        model = Farminfo
        exclude = (
            'sublocation', 'longitude', 'latitude', 'altitude',
            'farmer_sex', 'farmer_age', 'education', 'training',
            'position', 'occupation', 'selling_point', 'market',
            'cattle_kept_w_chicken',
            'dam_born_in_household', 'dam_time_at_farm', 'milked_prior_time',
            'milked_prior_frequency', 'milked_post_frequency',
            'milked_prior_colostrum', 'calf_suckled_alternative',
            'navel_desinfected', 'land_ownership', 'total_acres_used',
            'total_acres_leased', 'crops', 'diseases', 'housing_calves',
            'roof_dry', 'roof_wet', 'wall_dry', 'wall_wet', 'floor_dry',
            'floor_wet', 'nutritional_supplements', 'vaccine',
            'veterinary_support', 'watered_dry', 'watered_wet',
            'water_distance_dry', 'water_distance_wet',
            'watering_frequency_dry', 'watering_frequency_wet',
            'water_quality_dry', 'water_quality_wet', 'grazed_with_adults',
            'number_of_chicken', 'number_of_dogs', 'number_of_sheep',
            'number_of_goats', 'number_of_pigs',
            'disease_cat', 'disease_type', 'treatment_cat', 'treatment_type',
            'ectoparasites_method', 'ectoparasites_cat', 'ectoparasites_type',
            'ectoparasites_freqdry', 'ectoparasites_freqwet',
            'endoparasites_method', 'endoparasites_cat', 'endoparasites_type',
            'endoparasites_freqdry', 'endoparasites_freqwet',
            'trypanosoma_method', 'trypanosoma_cat', 'trypanosoma_type',
            'trypanosoma_freqdry', 'trypanosoma_freqwet', 'vaccine_type',
            'vaccine_freq', 'vet_assit'
        )
        fields = (
            'calf_ids',  'dam_ids', 'farmer_ids', 'calf_id', 'dam_id',
            'farmer_id'
        )


class DaminfoFilter(filters.FilterSet):
    dam_ids = CharInFilter(
        name='dam_id',
        label='Dam ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visitid',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    dam_id = filters.CharFilter(
        label='Dam ID contains',
        lookup_expr='icontains'
    )
    visitid = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    breed = filters.ChoiceFilter(
        label='Breed of the dam',
        empty_label='-- Select a breed --',
        choices=choices.BREED
    )
    local_name = filters.MultipleChoiceFilter(
        label='Local name for the breed of the dam',
        choices=choices.LOCAL_NAME,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    visitdate = filters.DateFromToRangeFilter(
        label='Date of visit',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Visits occurred between Oct 2007 and Sept 2010'
    )
    visit_type = filters.MultipleChoiceFilter(
        label='Visit type  (i.e. recruitment, 5-weekly, final)',
        choices=choices.DAM_VISIT_TYPE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    lossfollow = filters.ChoiceFilter(
        label='Whether or not dam is available for visit',
        empty_label='-- Choose dam availability at visit --',
        choices=constants.LOSSFOLLOW
    )
    reasonsloss = filters.ChoiceFilter(
        label='Reason for dam lost to follow-up before the final visit',
        empty_label='-- Choose reason for dam loss to follow-up --',
        choices=choices.DAM_REASONSLOSS
    )
    girthdam = filters.RangeFilter(
        label='Girth of dam (cm)',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 100,
                'max': 250,
            }
        ),
        help_text='Girth ranges from 110cm to 228cm, it is unknown for some visits'
    )
    subjdam = filters.MultipleChoiceFilter(
        label='Subjective assessment of the health of the dam at the visit',
        choices=constants.SUBJ_DAM,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    csdam = filters.MultipleChoiceFilter(
        label='Condition score of the dam',
        choices=constants.CS_DAM,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    uareadam = filters.ChoiceFilter(
        label=('Whether the ventral surface around the udder appears normal '
               'during examination'),
        empty_label='-- Choose udder area status --',
        choices=choices.UAREADAM
    )
    lnudderdam = filters.ChoiceFilter(
        label=('Whether the udder lymph nodes appears normal during '
               'examination'),
        empty_label='-- Choose lymph node status --',
        choices=choices.LNUDDERDAM
    )
    mastitis = filters.ChoiceFilter(
        name='cmtlfq',
        label='California mastitis test result',
        empty_label='-- Choose California mastitis test result --',
        choices=constants.MASTITIS,
        method='filter_mastitis'
    )

    class Meta:
        model = Daminfo
        # fill in all fields that should be excluded from searching
        exclude = (
            'calf_ids', 'calf_id',
            'pattern', 'hair', 'bodyht_f', 'bodyln_f', 'bodyln_f',
            'dewlap_size', 'hump_f', 'hump_orn', 'hump_loc', 'face',
            'back_pf', 'rump_pf', 'horn_f', 'horn_shape', 'horn_ornt',
            'spac_hrn', 'lnth_hrn', 'nvl_sz', 'ear_sz', 'ear_shp', 'ear_ornt',
            'tail_ln', 'tail_th', 'udd_sz', 'udd_teat', 'hwd','sthd', 'bld',
            'front_udder_lesion_dam', 'back_udder_lesion_dam',
            'front_teat_lesion_dam', 'back_teat_lesion_dam',
            'front_content_lesion_dam', 'back_content_lesion_dam', 'leslndam',
            'polelndam', 'lesvadam', 'body_colour_predominant',
            'body_colour_second', 'body_colour_third', 'body_colour_fourth',
            'body_colour_fifth', 'head_colour_predominant',
            'head_colour_second', 'head_colour_third', 'head_colour_fourth',
            'ear_colour_predominant', 'ear_colour_second', 'ear_colour_third',
            'tail_colour_predominant', 'tail_colour_second',
            'tail_colour_third', 'hoof_colour_predominant',
            'hoof_colour_second', 'hoof_colour_third',
            'muzzle_colour_predominant', 'muzzle_colour_second',
            'cmtlfq', 'cmtrfq', 'cmtlhq', 'cmtrhq','lastvisitwithdata',
            'datelastvisitwithdata', 'typeloss'
        )
        fields = (
            'dam_ids', 'visit_ids',  'dam_id',
            'visitid', 'breed', 'local_name', 'visitdate', 'visit_type',
            'lossfollow',  'reasonsloss', 'girthdam', 'subjdam', 'csdam',
            'uareadam', 'lnudderdam', 'mastitis'
        )

    def filter_mastitis(self, queryset, name, value):
        queryset = queryset.filter(
            Q(cmtlfq__contains=value) | Q(cmtrfq__contains=value) |
            Q(cmtlhq__contains=value) | Q(cmtrhq__contains=value)
        )
        return queryset


class CalfinfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visitid',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    calf_id = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    visitid = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    visitdate = filters.DateFromToRangeFilter(
        label='Date of visit',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Visits occurred between Oct 2007 and Sept 2010'
    )
    visit_type = filters.MultipleChoiceFilter(
        label='Visit type  (i.e. recruitment, 5-weekly, final)',
        choices=choices.CALF_VISIT_TYPE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    ce = filters.ChoiceFilter(
        label=('Whether the calf presents with a clinical episode at the time '
               'of the current visit'),
        empty_label='-- Choose a clinical visit type --',
        choices=choices.CE
    )
    ceever = filters.ChoiceFilter(
        label=('Did the calf ever experience a clinical episode during '
               'its enrolment in the IDEAL project?'),
        empty_label='-- Choose a clinical episode status --',
        choices=choices.CEEVER
    )
    deadalive = filters.MultipleChoiceFilter(
        label=('Did the calf survive until the end of the study period at '
               '51 weeks of age?'),
        choices=choices.DEADALIVE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    reasonsloss = filters.MultipleChoiceFilter(
        label='Reason for calf lost to follow-up before the final visit',
        choices=choices.CALF_REASONSLOSS,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    postmortemdone = filters.ChoiceFilter(
        label='Post-mortem done or not',
        empty_label='-- Choose whether or not a post-mortem was done --',
        choices=choices.POSTMORTEMDONE
    )
    cadob = filters.DateFromToRangeFilter(
        label='Calf date of birth',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Births occurred between Oct 2007 and Sept 2009'
    )
    calfsex = filters.ChoiceFilter(
        label='Calf sex',
        empty_label='-- Choose calf sex --',
        choices=constants.SEXES
    )
    rappend = filters.MultipleChoiceFilter(
        label='Level of infestation with adult Rhipicephalus appendiculatus',
        choices=choices.RAPPEND,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    ammbly = filters.MultipleChoiceFilter(
        label='Level of infestation with adult Amblyomma spp.',
        choices=choices.AMMBLY,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    booph = filters.MultipleChoiceFilter(
        label='Level of infestation with adult Boophilus spp.',
        choices=choices.BOOPH,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    hyalomm = filters.MultipleChoiceFilter(
        label='Level of infestation with adult Hyalomma spp.',
        choices=choices.HYALOMM,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    other_tick_louse = filters.MultipleChoiceFilter(
        label='Level of infestation with other tick species',
        choices=choices.OTHER_TICK_LOUSE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    lice = filters.MultipleChoiceFilter(
        label='Level of infestation with lice',
        choices=choices.LICE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    fleas = filters.MultipleChoiceFilter(
        label='Level of infestation with fleas',
        choices=choices.FLEAS,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    girth = filters.RangeFilter(
        label='Girth of calf (cm)',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 20,
                'max': 150,
            }
        ),
        help_text='Girth ranges from 25cm to 125cm, it is unknown for some visits'
    )
    weight = filters.RangeFilter(
        label='Weight of calf (kg)',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 5,
                'max': 150,
            }
        ),
        help_text='Weight ranges from 8kg to 145kg, it is unknown for some visits'
    )
    suckling = filters.ChoiceFilter(
        label=('Whether the calf is still suckling milk from the dam at the'
               ' current visit'),
        empty_label='-- Select a suckling status --',
        choices=choices.SUCKLING
    )
    grazing = filters.ChoiceFilter(
        label=('Whether the calf has started to go out grazing with adults'
               ' at the time of the current visit'),
        empty_label='-- Select a grazing status --',
        choices=choices.GRAZING
    )
    rt = filters.RangeFilter(
        label='Rectal temperature at the time of the current visit',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 1,
                'min': 30,
                'max': 45,
            }
        ),
        help_text='Rectal temperature ranges from 33°C to 42°C, it is unknown for some visits'
    )
    f_consist = filters.MultipleChoiceFilter(
        label='The consistency of the faeces at the the current visit',
        choices=choices.F_CONSIST,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    hprobcat = filters.MultipleChoiceFilter(
        label=('All herd health disorders observed during the inspection at '
               'rest and from the time of the last inter-visit history till '
               'present'),
        choices=choices.HPROBCAT,
        method='filter_disorders',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    hlestype = filters.MultipleChoiceFilter(
        label=('All herd health disorders observed during the inspection at '
               'rest and from the time of the last inter-visit history till '
               'present'),
        choices=choices.HLESTYPE,
        method='filter_disorders',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    bites = filters.ChoiceFilter(
        name='cynb',
        label=('History of animal bites for all cattle in the herd from the '
               'time of the last inter-visit history till present '),
        empty_label='-- Choose animal bite status --',
        choices=constants.BITES,
        method='filter_bites'
    )
    vtcalfyn = filters.ChoiceFilter(
        label=('Whether the calf has benefited from any sort of veterinary '
               'intervention since the time of the last inter-visit history '
               'till present'),
        empty_label='-- Select veterinary intervention (calf) --',
        choices=choices.VTCALFYN
    )
    vtdamyn = filters.ChoiceFilter(
        label=('Whether the dam has benefited from any sort of veterinary '
               'intervention since the time of the last inter-visit history '
               'till present'),
        empty_label='-- Select veterinary intervention (dam) --',
        choices=choices.VTDAMYN
    )
    vtherdyn = filters.ChoiceFilter(
        label=('Whether other cattle in the herd has benefited from any '
               'sort of veterinary intervention since the time of the last '
               'inter-visit history till present'),
        empty_label='-- Select veterinary intervention (herd) --',
        choices=choices.VTHERDYN
    )

    class Meta:
        model = Calfinfo
        exclude = (
            'dam_ids', 'dam_id', 'lossfollow', 'typeloss',
            'hrsscm', 'hlsscm', 'hrpccm', 'hlpccm', 'famacha_l', 'famacha_r',
            'elasticity','diaorseverity', 'diaorkind', 'diaorodour',
            'observedby', 'damaffected', 'percentherd', 'cynb',
            'dynb', 'hynb', 'vetinter_calf_cattto', 'vetinter_calf_typetto',
            'vetinter_calf_typeapplic', 'vetinter_dam_cattto',
            'vetinter_dam_typetto', 'vetinter_dam_typeapplic',
            'vetinter_herd_cattto', 'vetinter_herd_typetto',
            'vetinter_herd_typeapplic', 'vetinter_herd_nherdtto',
            'currentnumbercattle', 'totalentries', 'totaldeaths',
            'totalexits', 'animalcatdead', 'numdeadanicat', 'whydead',
            'calfdonev', 'breed', 'local_name', 'pattern', 'body_colours',
            'head_colours', 'ear_colours', 'tail_colours', 'hoof_colours',
            'muzzle_colours', 'hair', 'hair_typ', 'dewlap_size', 'hump_size',
            'hump_orientation', 'hump_location', 'face', 'back_profile',
            'rump_profile', 'horn_presence', 'horn_shape', 'horn_orientation',
            'horn_spacing', 'horn_length', 'naval_flap_size', 'ear_size',
            'ear_shape','ear_orientation', 'tail_length', 'tail_thickness',
            'udder_size', 'teats_size', 'testis', 'perpuce', 'hwc', 'sthc',
            'blc', 'body_colour_predominant', 'body_colour_second',
            'body_colour_third', 'body_colour_fourth', 'body_colour_fifth',
            'head_colour_predominant', 'head_colour_second',
            'head_colour_third', 'head_colour_fourth', 'head_colour_fifth',
            'ear_colour_predominant', 'ear_colour_second', 'ear_colour_third',
            'tail_colour_predominant', 'tail_colour_second',
            'tail_colour_third', 'hoof_colour_predominant',
            'hoof_colour_second', 'hoof_colour_third',
            'muzzle_colour_predominant', 'muzzle_colour_second',
            'lastvisitwithdata', 'datelastvisitwithdata','reasonspmnotdone',
            'dam_ids', 'dam_id'
        )
        fields = (
            'calf_ids',  'visit_ids', 'calf_id',
            'visitid', 'visitdate', 'visit_type', 'ce', 'ceever', 'deadalive',
            'reasonsloss', 'postmortemdone', 'cadob', 'calfsex', 'girth',
            'weight', 'rappend', 'ammbly', 'booph', 'hyalomm',
            'other_tick_louse', 'lice', 'fleas', 'suckling', 'grazing', 'rt',
            'f_consist', 'hprobcat', 'hlestype', 'bites', 'vtcalfyn',
            'vtdamyn', 'vtherdyn'
        )

    def filter_bites(self, queryset, name, value):
        queryset = queryset.filter(
            Q(cynb=value) | Q(dynb=value) | Q(hynb=value)
        )
        return queryset

    def filter_disorders(self, queryset, name, value):
        query = reduce(
            lambda q1, q2: q1 | q2,
            (Q(**{name+'__contains': v}) for v in value), Q()
        )
        print(query)
        queryset = queryset.filter(query)
        return queryset


class TestinfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    dam_ids = CharInFilter(
        name='dam_id',
        label='Dam ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visit_id',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    result_ids = CharInFilter(
        name='result_id',
        label='Result ID is in',
        widget=TextareaCSVWidget()
    )
    calf_id = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    dam_id = filters.CharFilter(
        label='Dam ID contains',
        lookup_expr='icontains'
    )
    visit_id = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    result_id = filters.CharFilter(
        label='Result ID contains',
        lookup_expr='icontains'
    )
    visitdate = filters.DateFromToRangeFilter(
        label='Date of visit',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Visits occurred between Oct 2007 and Sept 2010'
    )
    samplecode = filters.MultipleChoiceFilter(
        label='Sample code contains',
        choices=choices.SAMPLECODE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    test = filters.MultipleChoiceFilter(
        label='Test',
        choices=choices.TEST,
        method='filter_tests',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    possiblepathogen = filters.MultipleChoiceFilter(
        label='Pathological agent',
        choices=choices.POSSIBLEPATHOGEN,
        method='filter_results',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    resultstatus = filters.MultipleChoiceFilter(
        label='Status of the diagnostic test result',
        choices=choices.RESULTSTATUS,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    resultnum = filters.NumericRangeFilter(
        label='Quantitative result number is between',
        widget=filters.widgets.RangeWidget(
            attrs={
                'type': 'number',
                'step': 0.1
            }
        )
    )
    lifestage = filters.MultipleChoiceFilter(
        label='Life stage',
        choices=choices.LIFESTAGE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )

    class Meta:
        model = Testinfo
        exclude = ('samplegrouping',)
        fields = ('calf_ids', 'dam_ids', 'visit_ids', 'result_ids',)

    def filter_tests(self, queryset, name, value):
        test = HelpertableTest.objects.filter(pk__in=value).values_list('name')
        return queryset.filter(test__in=test)

    def filter_results(self, queryset, name, value):
        result = HelpertablePathogen.objects.filter(
            pathogen__in=value
        ).values_list('pathogen')
        return queryset.filter(possiblepathogen__in=result)


class ClinicalinfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visitid',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    calfid = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    visitid = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    lescat = filters.MultipleChoiceFilter(
        label=('Select disorder/lesion category '
               '(i.e. gastrointestinal, superficial lymphnodes etc.)'),
        choices=choices.LESCAT,
        method='filter_lesion_categories',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    lestype = filters.MultipleChoiceFilter(
        label=('Select disorder/lesion type '
               '(i.e. diarrhoea, constipation, enlarged etc.)'),
        choices=choices.LESTYPE,
        method='filter_lesion_types',
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    position = filters.MultipleChoiceFilter(
        label='Select by position of lesion<br>&nbsp;',
        choices=choices.POSITION,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    extension_pattern_lesion = filters.MultipleChoiceFilter(
        label='Select by extension-pattern of the lesion<br>&nbsp;',
        choices=choices.EXTENSION_PATTERN_LESION,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    lesion_location_capsule = filters.MultipleChoiceFilter(
        label=('Select by whether or not the lesion is located in the organs '
               'capsule or not'),
        choices=choices.LESION_LOCATION_CAPSULE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    ccs = filters.MultipleChoiceFilter(
        label='Select by who observed the disorder/lesion<br>&nsp;',
        choices=choices.CCS,
        help_text=constants.MULTIPLE_SELECT_HELP
    )

    class Meta:
        model = Clinicalinfo
        exclude = ('other', 'bodypart', 'dam_ids', 'dam_id',)
        fields = (
           'calf_ids', 'visit_ids', 'calfid', 'visitid',
           'lescat', 'lestype', 'position', 'extension_pattern_lesion',
           'lesion_location_capsule', 'ccs'
        )

    def filter_lesion_categories(self, queryset, name, value):
        lesion_cat = HelpertableLesioncat.objects.filter(
            pk__in=value
        ).values_list('lesion_cat')
        return queryset.filter(lescat__in=lesion_cat)

    def filter_lesion_types(self, queryset, name, value):
        lesion_type = HelpertableLesiontype.objects.filter(
            lesion_type__in=value
        ).values_list('lesion_type')
        return queryset.filter(lestype__in=lesion_type)


class PostmorteminfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visitid',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    calfid = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    visitid = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    deathdate = filters.DateFromToRangeFilter(
        label='Date of death',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Deaths occurred between Oct 2007 and Sept 2010'
    )
    euthanised = filters.ChoiceFilter(
        label='Calf euthanised or not',
        empty_label='-- Choose euthanised status --',
        choices=constants.EUTHANISED
    )
    pathology = filters.ChoiceFilter(
        name='immediate_cause_pathology',
        label='Immediate or contributing pathology cause of death',
        empty_label='-- Choose pathology --',
        choices=constants.PATHOLOGY,
        method='filter_pathology'
    )
    cause = filters.ChoiceFilter(
        name='definitive_aetiological_cause',
        label='Aetiological or contributing cause of death',
        empty_label='-- Choose cause of death --',
        choices=constants.CAUSE,
        method='filter_cause'
    )
    pathogen = filters.ChoiceFilter(
        name='definitive_cause_pathogen',
        label='Definitive or contributing pathogen which caused death',
        empty_label='-- Choose pathogen --',
        choices=constants.PATHOGEN,
        method='filter_pathogen'
    )

    class Meta:
        model = Postmorteminfo
        exclude = (
            'dam_ids', 'dam_id',
            'pm_comments', 'histopath_report', 'histo_aetiological_diagnosis',
            'histo_comments', 'stomach_content', 'immediate_cause_pathology',
            'definitive_aetiological_cause', 'definitive_cause_pathogen',
            'contributing_pathology_1', 'contributing_cause_1',
            'contributing_cause_pathogen_1', 'contributing_pathology_2',
            'contributing_cause_2', 'contributing_cause_pathogen_2'
        )
        fields = (
            'calf_ids', 'visit_ids', 'calfid', 'visitid',
            'deathdate', 'euthanised', 'pathology', 'cause', 'pathogen'
        )

    def filter_pathology(self, queryset, name, value):
        queryset = queryset.filter(
            Q(immediate_cause_pathology__contains=value) |
            Q(contributing_pathology_1__contains=value) |
            Q(contributing_pathology_2__contains=value)
        )
        return queryset

    def filter_cause(self, queryset, name, value):
        queryset = queryset.filter(
            Q(definitive_aetiological_cause__contains=value) |
            Q(contributing_cause_1__contains=value) |
            Q(contributing_cause_2__contains=value)
        )
        return queryset
    
    def filter_pathogen(self, queryset, name, value):
        queryset = queryset.filter(
            Q(definitive_cause_pathogen__contains=value) |
            Q(contributing_cause_pathogen_1__contains=value) |
            Q(contributing_cause_pathogen_2__contains=value)
        )
        return queryset


class SampleinfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    dam_ids = CharInFilter(
        name='damid',
        label='Dam ID is in',
        widget=TextareaCSVWidget()
    )
    visit_ids = CharInFilter(
        name='visitid',
        label='Visit ID is in',
        widget=TextareaCSVWidget()
    )
    sample_ids = CharInFilter(
        name='sampleid',
        label='Sample ID is in',
        widget=TextareaCSVWidget()
    )
    store_label = CharInFilter(
        name='storelabel',
        label='Store label is in',
        widget=TextareaCSVWidget()
    )
    calfid = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    damid = filters.CharFilter(
        label='Dam ID contains',
        lookup_expr='icontains'
    )
    visitid = filters.CharFilter(
        label='Visit ID contains',
        lookup_expr='icontains'
    )
    sampleid = filters.CharFilter(
        label='Sample ID contains',
        lookup_expr='icontains'
    )
    storelabel = filters.CharFilter(
        label='Store label contains',
        lookup_expr='icontains'
    )
    visitdate = filters.DateFromToRangeFilter(
        label='Date of visit',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Visits occurred between Oct 2007 and Sept 2010'
    )
    visittype = filters.MultipleChoiceFilter(
        label='Select the type of visit',
        choices=choices.SAMPLE_VISIT_TYPE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    sampletype = filters.MultipleChoiceFilter(
        label='Select the type of sample taken',
        choices=choices.SAMPLETYPE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    storetype = filters.MultipleChoiceFilter(
        label='Select the type of sample stored',
        choices=choices.STORETYPE,
        help_text=constants.MULTIPLE_SELECT_HELP
    )

    class Meta:
        model = Sampleinfo
        exclude = ()
        fields = (
            'calf_ids', 'dam_ids', 'visit_ids',  'calfid', 'damid', 'visitid',
            'sample_ids', 'store_label', 'sampleid','storelabel', 'visittype',
            'sampletype', 'storetype', 'visitdate'
        )


class FollowupinfoFilter(filters.FilterSet):
    calf_ids = CharInFilter(
        name='calf_id',
        label='Calf ID is in',
        widget=TextareaCSVWidget()
    )
    calf_id = filters.CharFilter(
        label='Calf ID contains',
        lookup_expr='icontains'
    )
    cadob = filters.DateFromToRangeFilter(
        label='Calf date of birth',
        widget=filters.widgets.RangeWidget(
            attrs={
                'class': 'datepicker',
                'style': 'width:45%;'
            }
        ),
        help_text='Births occurred between Oct 2007 and Sept 2009'
    )
    calf_sex = filters.ChoiceFilter(
        label='Calf sex',
        empty_label='-- Choose calf sex --',
        choices=constants.SEXES
    )
    dead_alive_end_ideal = filters.MultipleChoiceFilter(
        label='Select status of calf at 51 weeks of age',
        choices=choices.DEAD_ALIVE_END_IDEAL,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    status_1year = filters.MultipleChoiceFilter(
        label=('Select status of the animal at the time of the '
               'follow-up questionnaire'),
        choices=choices.STATUS_1YEAR,
        help_text=constants.MULTIPLE_SELECT_HELP
    )
    offspring_status = filters.MultipleChoiceFilter(
        label='Select whether or not the IDEAL calf had any offspring',
        choices=choices.OFFSPRING_STATUS,
        help_text=constants.MULTIPLE_SELECT_HELP
    )

    class Meta:
        model = Followupinfo
        exclude = (
            'status_1year_comments', 'year_died','death_comments',
            'num_calves', 'num_abortions', 'age_first_birth',
            'age_first_birth_year', 'age_last_birth', 'age_last_birth_year'
        )
        fields = (
            'calf_ids', 'calf_id',  'calf_sex', 'cadob','dead_alive_end_ideal',
            'status_1year','offspring_status'
        )
