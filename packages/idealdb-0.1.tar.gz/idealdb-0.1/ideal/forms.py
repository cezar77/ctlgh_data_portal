from django import forms


class FarminfoHideColumnsForm(forms.Form):
    hide_farmer = forms.BooleanField(
        label='Farmer variables',
        required=False
    )
    hide_market = forms.BooleanField(
        label='Selling/buying point variables',
        required=False
    )
    hide_farm_and_husbandry = forms.BooleanField(
        label='Farm and husbandry variables',
        required=False
    )
    hide_common_diseases = forms.BooleanField(
        label='Common diseases affecting farm variables',
        required=False
    )
    hide_ectoparasites = forms.BooleanField(
        label='Methods of ectoparasite control variables',
        required=False
    )
    hide_endoparasites = forms.BooleanField(
        label='Methods of intestinal parasites control variables',
        required=False
    )
    hide_tryps = forms.BooleanField(
        label='Methods of trypanosoma control variables',
        required=False
    )
    hide_vaccine = forms.BooleanField(
        label='Methods of trypanosoma control variables',
        required=False
    )
    hide_housing = forms.BooleanField(
        label='Housing variables',
        required=False
    )
    hide_watering = forms.BooleanField(
        label='Watering variables',
        required=False
    )
    hide_livestock = forms.BooleanField(
        label='Livestock variables',
        required=False
    )
    hide_dam = forms.BooleanField(
        label='Dam variables',
        required=False
    )
    hide_milking = forms.BooleanField(
        label='Milking variables',
        required=False
    )
    hide_suckling = forms.BooleanField(
        label='Suckling variables',
        required=False
    )
    hide_bull = forms.BooleanField(
        label='Bull variables',
        required=False
    )


class DaminfoHideColumnsForm(forms.Form):
    hide_visit = forms.BooleanField(
        label='Visit variables',
        required=False
    )
    hide_loss = forms.BooleanField(
        label='Reason for missing visit variables',
        required=False
    )
    hide_reasonloss = forms.BooleanField(
        label='Reason for loss to follow-up variables',
        required=False
    )
    hide_measurements_condition = forms.BooleanField(
        label='Measurement and body condition variables',
        required=False
    )
    hide_phenotype = forms.BooleanField(
        label='Phenotype variables',
        required=False
    )
    hide_udder = forms.BooleanField(
        label='Udder health variables',
        required=False
    )


class CalfinfoHideColumnsForm(forms.Form):
    hide_visit = forms.BooleanField(
        label='Visit information',
        required=False
        )
    hide_loss = forms.BooleanField(
        label='Reason for missing visit variables',
        required=False
        )
    hide_reasonloss = forms.BooleanField(
        label='Reason for loss to follow-up variables',
        required=False
    )
    hide_calf_key_info = forms.BooleanField(
        label='Calf sex and date of birth',
        required=False
        )
    hide_calf_visit_measurements = forms.BooleanField(
        label='Calf measurements at visits',
        required=False
        )
    hide_ectoparasites = forms.BooleanField(
        label='Ectoparasite at visits',
        required=False
        )
    hide_sucking_grazing = forms.BooleanField(
        label='Suckling and grazing at visits',
        required=False
        )
    hide_clinical_information = forms.BooleanField(
        label='Clinical measurements',
        required=False
        )
    hide_lypmh_nodes = forms.BooleanField(
        label='Abnormal lymph nodes',
        required=False
        )
    hide_diarrhoea = forms.BooleanField(
        label='Diarrhoea descriptions',
        required=False
        )
    hide_calf_disorders = forms.BooleanField(
        label='Calf disorders',
        required=False
        )
    hide_herd_disorders = forms.BooleanField(
        label='Herd disorders',
        required=False
        )
    hide_animal_bites = forms.BooleanField(
        label='Animal bites',
        required=False
        )
    hide_veterinary_interventions = forms.BooleanField(
        label='Veterinary interventions',
        required=False
        )
    hide_cattle_movements = forms.BooleanField(
        label='Cattle movements',
        required=False
        )
    hide_phenotype = forms.BooleanField(
        label='Phenotype variables',
        required=False
        )
    hide_fixed_measurements = forms.BooleanField(
        label='Phenotype measurements at one visit',
        required=False
        )


class TestinfoHideColumnsForm(forms.Form):
    hide_visitdate = forms.BooleanField(
        label='Visit date information',
        required=False
        )
    hide_sampleinfo = forms.BooleanField(
        label='Sample ID information',
        required=False
        )
    hide_testinfo = forms.BooleanField(
        label='Test and result information',
        required=False
        )


class ClinicalinfoHideColumnsForm(forms.Form):
    hide_bodypart = forms.BooleanField(
        label='Body part information',
        required=False
        )
    hide_lescat = forms.BooleanField(
        label='Disorder/lesion catergory information',
        required=False
        )
    hide_lestype = forms.BooleanField(
        label='Disorder/lesion type information',
        required=False
        )
    hide_other = forms.BooleanField(
        label='Other disorder/lesion information',
        required=False
        )
    hide_position = forms.BooleanField(
        label='Position of disorder/lesion information',
        required=False
        )
    hide_extension_pattern_lesion = forms.BooleanField(
        label='Extension pattern of disorder/lesion information',
        required=False
        )
    hide_lesion_location_capsule = forms.BooleanField(
        label='Lesion location in organ capsule information',
        required=False
        )
    hide_ccs = forms.BooleanField(
        label='Who observed the disorder/lesion information',
        required=False
        )

class PostmorteminfoHideColumnsForm(forms.Form):
    hide_immediate_cause = forms.BooleanField(
        label='Immediate cause of death information',
        required=False
        )
    hide_contributing_cause_1 = forms.BooleanField(
        label='Contributing cause of death (1) information',
        required=False
        )
    hide_contributing_cause_2 = forms.BooleanField(
        label='Contributing cause of death (2) information',
        required=False
        )
    hide_postmortem_comments = forms.BooleanField(
        label='Postmortem comments',
        required=False
        )
    hide_histpath = forms.BooleanField(
        label='Histopathology comments',
        required=False
        )
    hide_stomach_contents = forms.BooleanField(
        label='Stomach contents',
        required=False
        )


class SampleinfoHideColumnsForm(forms.Form):
    hide_sampleid = forms.BooleanField(
        label='SampleID information',
        required=False
    )
    hide_storelabel = forms.BooleanField(
        label='Store label information',
        required=False
    )
    hide_type = forms.BooleanField(
        label='Visit and sample type information',
        required=False
    )
    hide_store = forms.BooleanField(
        label='Store information',
        required=False
    )
