import csv
import json
from collections import OrderedDict

from django.core.management.base import BaseCommand

from ideal.models import Followupinfo

class Command(BaseCommand):
    help = 'Convert the CSV file with FollowupInfo data to JSON fixtures'
    csv_file = 'ideal/Follow_up_study/IDEAL_follow_up_study_2012.csv'
    json_file = 'ideal/fixtures/followupinfo.json'

    def handle(self, *args, **options):
        input_data = self.read_input_file()
        fields = self.get_model_fields()
        fixtures = self.generate_fixtures(input_data, fields)
        self.write_output_file(fixtures)
            
    def read_input_file(self):
        with open(self.csv_file, 'r') as input_file:
            next(input_file)
            rows = csv.reader(input_file)
            input_data = [row for row in rows]
        return input_data

    def write_output_file(self, data):
        with open(self.json_file, 'w') as output_file:
            output_file.write(json.dumps(data, indent=4, default=str))

    @staticmethod
    def get_model_fields():
        """
        Get all field names from the model Followupinfo,
        but drop out the auto-generated 'id'.
        """
        fields = [field.name for field in Followupinfo._meta.fields]
        return fields[1:]

    @staticmethod
    def generate_fixtures(input_data, fields):
        return [
            OrderedDict([
                ('model', 'ideal.followupinfo'),
                ('pk', row_no+1),
                ('fields', OrderedDict(zip(fields, items)))
            ]) for row_no, items in enumerate(input_data)
        ]
