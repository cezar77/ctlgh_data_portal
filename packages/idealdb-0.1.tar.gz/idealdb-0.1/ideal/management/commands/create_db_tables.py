from django.core.management.base import BaseCommand
from django.apps import apps
from django.db import connections


class Command(BaseCommand):
    help = "Create (or drop) tables for all unmanaged models."
    mapping = {
        'farminfo': 'v_farminfo',
        'daminfo': 'v_daminfo',
        'calfinfo': 'v_calfinfo',
        'testinfo': 'st_testinfo',
        'clinicalinfo': 'v_clinicalinfo',
        'postmorteminfo': 'v_postmorteminfo',
        'sampleinfo': 'st_sampleinfo',
    }

    def add_arguments(self, parser):
        parser.add_argument(
            '-o',
            '--operation',
            type=str,
            choices=('create', 'drop'),
            default='create',
            help='The operation to be performed: create or drop.'
        )

    def handle(self, *args, **options):
        models = apps.all_models['ideal']
        operations = {
            'create': self.generate_create_queries,
            'drop': self.generate_drop_queries
        }
        operation = options['operation']
        queries = operations[operation](models)
        with connections['remote'].cursor() as cursor:
            for query in queries:
                cursor.execute(query)

    def get_db_columns(self, model):
        db_columns = [
            field.db_column if field.db_column else field.name
            for field in model._meta.fields
            if not field.primary_key
        ]
        return ', '.join(db_columns)

    def generate_create_queries(self, models):
        statement = (
            'CREATE TABLE IF NOT EXISTS {} '
            '(id INT NOT NULL AUTO_INCREMENT PRIMARY KEY)'
            ' SELECT {} FROM {}'
        )
        return [
            statement.format(model._meta.db_table, self.get_db_columns(model), self.mapping[key])
            for key, model in models.items()
            if not model._meta.managed
        ]

    def generate_drop_queries(self, models):
        statement = 'DROP TABLE IF EXISTS {}'
        return [
            statement.format(model._meta.db_table)
            for model in models.values()
            if not model._meta.managed
        ]
