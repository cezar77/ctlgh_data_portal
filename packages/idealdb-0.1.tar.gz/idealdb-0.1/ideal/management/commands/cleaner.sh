#!/usr/bin/bash
# Clean the directory pictures from all files named Thumbs.db

echo $1
if [ $1 ]
then
    INPUT_DIR=$1
else
    INPUT_DIR="ideal/static/ideal/pictures"
fi

if [ -d $INPUT_DIR ]
then
    echo "All files named 'Thumbs.db' in the directory $INPUT_DIR will be deleted recursive"
else
    echo "The directory $INPUT_DIR doesn't exist"
    exit 1
fi

THUMBS=`find $INPUT_DIR -name 'Thumbs.db'`
rm $THUMBS
