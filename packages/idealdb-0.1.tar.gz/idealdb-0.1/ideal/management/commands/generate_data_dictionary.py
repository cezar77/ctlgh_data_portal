import os
import csv

from django.core.management.base import BaseCommand

from ideal.tables import (
    FarminfoTable,
    DaminfoTable,
    CalfinfoTable,
    TestinfoTable,
    ClinicalinfoTable,
    PostmorteminfoTable,
    SampleinfoTable,
    FollowupinfoTable
)

class Command(BaseCommand):
    help = "Generate a data dictionary for the IDEAL app."
    infotables = [
        FarminfoTable,
        DaminfoTable,
        CalfinfoTable,
        TestinfoTable,
        ClinicalinfoTable,
        PostmorteminfoTable,
        SampleinfoTable,
        FollowupinfoTable
    ]
    header = ['Name', 'Description', 'Table']

    def handle(self, *args, **options):
        with open('data_dictionary.csv', 'w', newline='') as csvfile:
            w = csv.writer(csvfile)
            w.writerow(self.header)
            for t in self.infotables:
                for column in t.base_columns.values():
                    row = []
                    row.append(column.verbose_name)
                    row.append(column.attrs.get('th')['title'])
                    row.append(t._meta.model()._meta.verbose_name)
                    w.writerow(row)
                    
