from django.apps import AppConfig


class HelperConfig(AppConfig):
    name = 'ideal.helper'
    label = 'helper'
