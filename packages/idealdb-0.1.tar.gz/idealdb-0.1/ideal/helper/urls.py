from django.conf.urls import url

from . import views

urlpatterns = [
    url(
        r'^pathogenlist/$',
        views.HelpertablePathogenListView.as_view(),
        name='pathogen-list'
    ),
    url(
        r'^lesiontypelist/$',
        views.HelpertableLesiontypeListView.as_view(),
        name='lesiontype-list'
    ),
]

