from django.core import serializers
from django.views.generic.list import ListView
from django.http import JsonResponse
from django.views.decorators.cache import cache_page
from django.utils.decorators import method_decorator

from .models import HelpertablePathogen, HelpertableLesiontype


@method_decorator(cache_page(30 * 24 * 60 * 60), name='dispatch')
class HelpertablePathogenListView(ListView):
    model = HelpertablePathogen

    def get(self, request, *args, **kwargs):
        qs = self.get_queryset()
        q = request.GET.get('q', False)
        ids = []
        if q:
            ids = q.split(',')
        fk_list = []
        for i in ids:
            try:
                fk_list.append(int(i))
            except ValueError:
                pass
        if fk_list:
            qs = qs.filter(
                name__in=fk_list
            ).order_by('pathogen')
        data = serializers.serialize('json', qs)
        return JsonResponse(data, status=200, safe=False)


@method_decorator(cache_page(30 * 24 * 60 * 60), name='dispatch')
class HelpertableLesiontypeListView(ListView):
    model = HelpertableLesiontype

    def get(self, request, *args, **kwargs):
        qs = self.get_queryset()
        q = request.GET.get('q', False)
        ids = []
        if q:
            ids = q.split(',')
        fk_list = []
        for i in ids:
            try:
                fk_list.append(int(i))
            except ValueError:
                pass
        if fk_list:
            qs = qs.filter(
                lesion_cat__in=fk_list
            ).order_by('lesion_type')
        data = serializers.serialize('json', qs)
        return JsonResponse(data, status=200, safe=False)
