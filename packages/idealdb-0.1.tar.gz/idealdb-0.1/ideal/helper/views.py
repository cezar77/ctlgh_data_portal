from django.core import serializers
from django.views.generic.list import ListView
from django.http import JsonResponse

from .models import HelpertablePathogen, HelpertableLesiontype


class HelpertablePathogenListView(ListView):
    model = HelpertablePathogen

    def get(self, request, *args, **kwargs):
        qs = self.get_queryset()
        q = request.GET.get('q', False)
        ids = []
        if q:
            ids = q.split(',')
        fk_list = []
        for i in ids:
            try:
                fk_list.append(int(i))
            except ValueError:
                pass
        if fk_list:
            qs = qs.filter(
                name__in=fk_list
            ).order_by('pathogen')
        data = serializers.serialize('json', qs)
        return JsonResponse(data, status=200, safe=False)


class HelpertableLesiontypeListView(ListView):
    model = HelpertableLesiontype

    def get(self, request, *args, **kwargs):
        qs = self.get_queryset()
        q = request.GET.get('q', False)
        ids = []
        if q:
            ids = q.split(',')
        fk_list = []
        for i in ids:
            try:
                fk_list.append(int(i))
            except ValueError:
                pass
        if fk_list:
            qs = qs.filter(
                lesion_cat__in=fk_list
            ).order_by('lesion_type')
        data = serializers.serialize('json', qs)
        return JsonResponse(data, status=200, safe=False)
