from django.db import models


class HelpertableTest(models.Model):
    name = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'helpertable_test'

    def __str__(self):
        return self.name


class HelpertablePathogen(models.Model):
    pathogen = models.CharField(max_length=255)
    name = models.ForeignKey('HelpertableTest', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'helpertable_pathogen'
        unique_together = ('pathogen', 'name')

    def __str__(self):
        return self.pathogen


class HelpertableLesioncat(models.Model):
    lesion_cat = models.CharField(max_length=255)

    class Meta:
        managed = False
        db_table = 'helpertable_lesioncat'

    def __str__(self):
        return self.lesion_cat


class HelpertableLesiontype(models.Model):
    lesion_type = models.CharField(max_length=255)
    lesion_cat = models.ForeignKey('HelpertableLesioncat', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'helpertable_lesiontype'

    def __str__(self):
        return '{} - {}'.format(self.lesion_type, self.lesion_cat)
