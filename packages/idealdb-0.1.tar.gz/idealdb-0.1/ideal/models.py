from django.db import models
from django.utils.html import format_html
from django.utils.functional import cached_property

from .constants import *


class Farminfo(models.Model):
    """
    Contains all the farm level information. Includes details about
    the farmer, the farm, husbandry and management practices and
    markets.
    """
    calf_id = models.CharField(
        db_column='CalfID',
        max_length=50
    )
    farmer_id = models.CharField(
        db_column='FarmerID',
        max_length=50,
        blank=True,
        null=True
    )
    dam_id = models.CharField(
        db_column='DamID',
        max_length=50,
        blank=True,
        null=True
    )
    calf_sex = models.CharField(
        max_length=1,
        blank=True,
        null=True
    )
    calf_date_of_birth = models.DateField(
        db_column='CADOB',
        blank=True,
        null=True
    )
    sublocation = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    sublocation_id = models.IntegerField(
        blank=True,
        null=True
    )
    farmer_sex = models.CharField(
        max_length=1,
        blank=True,
        null=True
    )
    farmer_age = models.IntegerField(
        blank=True,
        null=True
    )
    longitude = models.DecimalField(
        max_digits=8,
        decimal_places=5,
        blank=True,
        null=True
    )
    latitude = models.DecimalField(
        max_digits=7,
        decimal_places=5,
        blank=True,
        null=True
    )
    altitude = models.BigIntegerField(
        blank=True,
        null=True
    )
    education = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    training = models.CharField(
        max_length=3,
        blank=True,
        null=True
    )
    position = models.CharField(
        max_length=60,
        blank=True,
        null=True,
        choices=POSITION
    )
    occupation = models.CharField(
        max_length=12,
        blank=True,
        null=True
    )
    selling_point = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    market = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    cattle_kept_w_chicken = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    dam_age = models.DecimalField(
        max_digits=4,
        decimal_places=1,
        blank=True,
        null=True
    )
    dam_calvings = models.DecimalField(
        db_column='calvings',
        max_digits=4,
        decimal_places=1, 
        blank=True,
        null=True
    )
    dam_born_in_household = models.BigIntegerField(
        blank=True,
        null=True
    )
    dam_time_at_farm = models.IntegerField(
        blank=True,
        null=True
    )
    bull_origin = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    bull_type = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    milked_prior_calving = models.BigIntegerField(
        blank=True,
        null=True
    )
    milked_prior_time = models.IntegerField(
        blank=True,
        null=True
    )
    milked_prior_frequency = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    milked_post_calving = models.BigIntegerField(
        blank=True,
        null=True
    )
    milked_post_frequency = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    milked_prior_colostrum = models.BigIntegerField(
        blank=True,
        null=True
    )
    calf_suckled = models.BigIntegerField(
        blank=True,
        null=True
    )
    calf_suckled_alternative = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    navel_desinfected = models.BigIntegerField(
        db_column='navel_desinfection',
        blank=True,
        null=True
    )
    land_ownership = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    total_acres_used = models.DecimalField(
        max_digits=11,
        decimal_places=5,
        blank=True,
        null=True
    )
    total_acres_leased = models.DecimalField(
        max_digits=11,
        decimal_places=5,
        blank=True,
        null=True
    )
    crops = models.BigIntegerField(
        blank=True,
        null=True
    )
    diseases = models.BigIntegerField(
        blank=True,
        null=True
    )
    housing_dry = models.CharField(
        max_length=60,
        blank=True,
        null=True,
        choices=HOUSING_TYPE
    )
    housing_wet = models.CharField(
        max_length=60,
        blank=True,
        null=True,
        choices=HOUSING_TYPE
    )
    housing_calves = models.IntegerField(
        blank=True,
        null=True
    )
    roof_dry = models.IntegerField(
        blank=True,
        null=True
    )
    roof_wet = models.IntegerField(
        blank=True,
        null=True
    )
    wall_dry = models.IntegerField(
        blank=True,
        null=True
    )
    wall_wet = models.IntegerField(
        blank=True,
        null=True
    )
    floor_dry = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    floor_wet = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    nutritional_supplements = models.BigIntegerField(
        blank=True,
        null=True
    )
    vaccine = models.BigIntegerField(
        blank=True,
        null=True
    )
    veterinary_support = models.BigIntegerField(
        blank=True,
        null=True
    )
    watered_dry = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    watered_wet = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    water_distance_dry = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    water_distance_wet = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    watering_frequency_dry = models.CharField(
        db_column='water_frequency_dry',
        max_length=60,
        blank=True,
        null=True
    )
    watering_frequency_wet = models.CharField(
        db_column='water_frequency_wet',
        max_length=60,
        blank=True,
        null=True
    )
    water_quality_dry = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    water_quality_wet = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    grazed_with_adults = models.BigIntegerField(
        blank=True,
        null=True
    )
    number_of_cattle = models.BigIntegerField(
        blank=True,
        null=True
    )
    number_of_chicken = models.BigIntegerField(
        blank=True,
        null=True
    )
    number_of_dogs = models.BigIntegerField(
        blank=True,
        null=True
    )
    number_of_sheep = models.BigIntegerField(
        blank=True,
        null=True
    )
    number_of_goats = models.BigIntegerField(
        blank=True,
        null=True
    )
    number_of_pigs = models.BigIntegerField(
        blank=True,
        null=True
    )
    disease_cat = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    disease_type = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    treatment_cat = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    treatment_type = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    ectoparasites_method = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    ectoparasites_cat = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    ectoparasites_type = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    ectoparasites_freqdry = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    ectoparasites_freqwet = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    endoparasites_method = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    endoparasites_cat = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    endoparasites_type = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    endoparasites_freqdry = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    endoparasites_freqwet = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    trypanosoma_method = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    trypanosoma_cat = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    trypanosoma_type = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    trypanosoma_freqdry = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    trypanosoma_freqwet = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    vaccine_type = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    vaccine_freq = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    vet_assit = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    class Meta:
        managed = False
        db_table = 'web__farm_info'
        verbose_name = 'Farm information'

    def __str__(self):
        return 'Calf: {} - Dam: {} - Farmer: {}'.format(
            self.calf_id,
            self.dam_id,
            self.farmer_id
        )


class AnimalinfoModel(models.Model):
    visitid = models.CharField(
        db_column='VisitID',
        max_length=50
    )  # Field name made lowercase.
    dam_id = models.CharField(
        db_column='DamID',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    calf_id = models.CharField(
        db_column='CalfID',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    breed = models.CharField(
        max_length=20,
        blank=True,
        null=True
    )
    local_name = models.CharField(
        max_length=50,
        blank=True,
        null=True
    )
    visitdate = models.DateField(
        db_column='VisitDate',
        blank=True,
        null=True
    )  # Field name made lowercase.
    visit_type = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    typeloss = models.CharField(
        db_column='TypeLoss',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    pattern = models.CharField(
        db_column='PATTERN',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    hair = models.CharField(
        db_column='HAIR',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    body_colour_predominant = models.IntegerField(blank=True, null=True)
    body_colour_second = models.IntegerField(blank=True, null=True)
    body_colour_third = models.IntegerField(blank=True, null=True)
    body_colour_fourth = models.IntegerField(blank=True, null=True)
    body_colour_fifth = models.IntegerField(blank=True, null=True)
    head_colour_predominant = models.IntegerField(blank=True, null=True)
    head_colour_second = models.IntegerField(blank=True, null=True)
    head_colour_third = models.IntegerField(blank=True, null=True)
    head_colour_fourth = models.IntegerField(blank=True, null=True)
    ear_colour_predominant = models.IntegerField(blank=True, null=True)
    ear_colour_second = models.IntegerField(blank=True, null=True)
    ear_colour_third = models.IntegerField(blank=True, null=True)
    tail_colour_predominant = models.IntegerField(blank=True, null=True)
    tail_colour_second = models.IntegerField(blank=True, null=True)
    tail_colour_third = models.IntegerField(blank=True, null=True)
    hoof_colour_predominant = models.IntegerField(blank=True, null=True)
    hoof_colour_second = models.IntegerField(blank=True, null=True)
    hoof_colour_third = models.IntegerField(blank=True, null=True)
    muzzle_colour_predominant = models.IntegerField(blank=True, null=True)
    muzzle_colour_second = models.IntegerField(blank=True, null=True)
    dewlap_size = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    
    class Meta:
        abstract = True

    def get_colours_hex(self, value):
        if value is None:
            return ''
        return COLOURS_CHART[str(value)]

    def get_colours(self, value):
        colours = self.get_colours_hex(value)
        no_colours = len(colours)
        contents = (
            '<div class="colours" style="background-color:{c}; width:{w}%;">'
            '</div>'
        )
        colour_divs = []
        for colour in colours:
            colour_divs.append(
                contents.format(c=colour, w=int(100/no_colours))
            )
        container = '<div class="colours-holder">{}</div>'.format(
            ''.join(colour_divs)
        )
        return format_html(container)

    @cached_property
    def body_colours(self):
        return format_html(
            self.get_colours(self.body_colour_predominant) +
            self.get_colours(self.body_colour_second) +
            self.get_colours(self.body_colour_third) +
            self.get_colours(self.body_colour_fourth) +
            self.get_colours(self.body_colour_fifth)
        )

    @cached_property
    def body_colours_hex(self):
        return '1. {}; 2. {}; 3. {}; 4. {}; 5. {}'.format(
            self.get_colours_hex(self.body_colour_predominant),
            self.get_colours_hex(self.body_colour_second),
            self.get_colours_hex(self.body_colour_third),
            self.get_colours_hex(self.body_colour_fourth),
            self.get_colours_hex(self.body_colour_fifth)
        )

    @cached_property
    def head_colours(self):
        return format_html(
            self.get_colours(self.head_colour_predominant) +
            self.get_colours(self.head_colour_second) +
            self.get_colours(self.head_colour_third) +
            self.get_colours(self.head_colour_fourth)
        )

    @cached_property
    def head_colours_hex(self):
        return '1. {}; 2. {}; 3. {}; 4. {}'.format(
            self.get_colours_hex(self.head_colour_predominant),
            self.get_colours_hex(self.head_colour_second),
            self.get_colours_hex(self.head_colour_third),
            self.get_colours_hex(self.head_colour_fourth)
        )

    @cached_property
    def ear_colours(self):
        return format_html(
            self.get_colours(self.ear_colour_predominant) +
            self.get_colours(self.ear_colour_second) +
            self.get_colours(self.ear_colour_third)
        )

    @cached_property
    def ear_colours_hex(self):
        return '1. {}; 2. {}; 3. {}'.format(
            self.get_colours_hex(self.ear_colour_predominant),
            self.get_colours_hex(self.ear_colour_second),
            self.get_colours_hex(self.ear_colour_third)
        )

    @cached_property
    def tail_colours(self):
        return format_html(
            self.get_colours(self.tail_colour_predominant) +
            self.get_colours(self.tail_colour_second) +
            self.get_colours(self.tail_colour_third)
        )

    @cached_property
    def tail_colours_hex(self):
        return '1: {}; 2: {}; 3. {}'.format(
            self.get_colours_hex(self.tail_colour_predominant),
            self.get_colours_hex(self.tail_colour_second),
            self.get_colours_hex(self.tail_colour_third)
        )

    @cached_property
    def hoof_colours(self):
        return format_html(
            self.get_colours(self.hoof_colour_predominant) +
            self.get_colours(self.hoof_colour_second) +
            self.get_colours(self.hoof_colour_third)
        )

    @cached_property
    def hoof_colours_hex(self):
        return '1: {}; 2: {}; 3 {}'.format(
            self.get_colours_hex(self.hoof_colour_predominant),
            self.get_colours_hex(self.hoof_colour_second),
            self.get_colours_hex(self.hoof_colour_third)
        )

    @cached_property
    def muzzle_colours(self):
        return format_html(
            self.get_colours(self.muzzle_colour_predominant) +
            self.get_colours(self.muzzle_colour_second)
        )

    @cached_property
    def muzzle_colours_hex(self):
        return '1: {}; 2: {}'.format(
            self.get_colours_hex(self.muzzle_colour_predominant),
            self.get_colours_hex(self.muzzle_colour_second)
        )


class Daminfo(AnimalinfoModel):
    """
    Contains information about the dam at each visit, this includes
    subjective assemsments of the dams health, girth measurements,
    ‘California Mastitis Test’ results and disorders of the udder areas.

    Dam phenotype information is also included in this table. 
    """
    hump_f = models.CharField(
        db_column='HUMP_F',
        max_length=4,
        blank=True,
        null=True,
        choices=HUMP_F
    )  # Field name made lowercase.
    hump_orn = models.CharField(
        db_column='HUMP_ORN',
        max_length=4,
        blank=True,
        null=True,
        choices=HUMP_ORN
    )  # Field name made lowercase.
    hump_loc = models.CharField(
        db_column='HUMP_LOC',
        max_length=4,
        blank=True,
        null=True,
        choices=HUMP_LOC
    )  # Field name made lowercase.
    face = models.CharField(
        db_column='FACE',
        max_length=4,
        blank=True,
        null=True,
        choices=FACE
    )  # Field name made lowercase.
    back_pf = models.CharField(
        db_column='BACK_PF',
        max_length=4,
        blank=True,
        null=True,
        choices=BACK_PF
    )  # Field name made lowercase.
    rump_pf = models.CharField(
        db_column='RUMP_PF',
        max_length=4,
        blank=True,
        null=True,
        choices=RUMP_PF
    )  # Field name made lowercase.
    horn_f = models.CharField(
        db_column='HORN_F',
        max_length=4,
        blank=True,
        null=True,
        choices=HORN_F
    )  # Field name made lowercase.
    horn_shape = models.CharField(
        db_column='HORN_SHAPE',
        max_length=4,
        blank=True,
        null=True,
        choices=HORN_SHAPE
    )  # Field name made lowercase.
    horn_ornt = models.CharField(
        db_column='HORN_ORNT',
        max_length=4,
        blank=True,
        null=True,
        choices=HORN_ORNT
    )  # Field name made lowercase.
    spac_hrn = models.CharField(
        db_column='SPAC_HRN',
        max_length=4,
        blank=True,
        null=True,
        choices=SPAC_HORN
    )  # Field name made lowercase.
    lnth_hrn = models.CharField(
        db_column='LNTH_HRN',
        max_length=4,
        blank=True,
        null=True,
        choices=LNTH_HRN
    )  # Field name made lowercase.
    nvl_sz = models.CharField(
        db_column='NVL_SZ',
        max_length=4,
        blank=True,
        null=True,
        choices=HUMP_F
    )  # Field name made lowercase.
    ear_sz = models.CharField(
        db_column='EAR_SZ',
        max_length=4,
        blank=True,
        null=True,
        choices=EAR_SZ
    )  # Field name made lowercase.
    ear_shp = models.CharField(
        db_column='EAR_SHP',
        max_length=4,
        blank=True,
        null=True,
        choices=EAR_SHP
    )  # Field name made lowercase.
    ear_ornt = models.CharField(
        db_column='EAR_ORNT',
        max_length=4,
        blank=True,
        null=True,
        choices=EAR_ORNT
    )  # Field name made lowercase.
    tail_ln = models.CharField(
        db_column='TAIL_LN',
        max_length=4,
        blank=True,
        null=True,
        choices=TAIL_LN
    )  # Field name made lowercase.
    tail_th = models.CharField(
        db_column='TAIL_TH',
        max_length=4,
        blank=True,
        null=True,
        choices=TAIL_TH
    )  # Field name made lowercase.
    udd_sz = models.CharField(
        db_column='UDD_SZ',
        max_length=4,
        blank=True,
        null=True,
        choices=UDD_SZ
    )  # Field name made lowercase.
    udd_teat = models.CharField(
        db_column='UDD_TEAT',
        max_length=4,
        blank=True,
        null=True,
        choices=UDD_TEAT
    )  # Field name made lowercase.
    hwd = models.DecimalField(
        max_digits=5,
        decimal_places=1,
        blank=True,
        null=True
    )  # Field name made lowercase.
    sthd = models.DecimalField(
        max_digits=4,
        decimal_places=1,
        blank=True,
        null=True
    )  # Field name made lowercase.
    bld = models.DecimalField(
        max_digits=4,
        decimal_places=1,
        blank=True,
        null=True
    )  # Field name made lowercase.
    lossfollow = models.CharField(
        db_column='LossFollow',
        max_length=50,
        blank=True,
        null=True,
        choices=LOSSFOLLOWD
    )  # Field name made lowercase.
    girthdam = models.DecimalField(
        db_column='GirthDam',
        max_digits=4,
        decimal_places=1,
        blank=True,
        null=True
    )  # Field name made lowercase.
    subjdam = models.CharField(
        db_column='SubjDam',
        max_length=50,
        blank=True,
        null=True,
        choices = SUBJ_DAM
    )  # Field name made lowercase.
    csdam = models.CharField(
        db_column='CSDam',
        max_length=50,
        blank=True,
        null=True,
        choices=CS_DAM
    )  # Field name made lowercase.
    uareadam = models.CharField(
        db_column='UAreaDam',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    lnudderdam = models.CharField(
        db_column='LNUdderDam',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    cmtlfq = models.CharField(
        db_column='CMTLFQ',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    cmtrfq = models.CharField(
        db_column='CMTRFQ',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    cmtlhq = models.CharField(
        db_column='CMTLHQ',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    cmtrhq = models.CharField(
        db_column='CMTRHQ',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    front_udder_lesion_dam = models.TextField(blank=True, null=True)
    back_udder_lesion_dam = models.TextField(blank=True, null=True)
    front_teat_lesion_dam = models.TextField(blank=True, null=True)
    back_teat_lesion_dam = models.TextField(blank=True, null=True)
    front_content_lesion_dam = models.TextField(blank=True, null=True)
    back_content_lesion_dam = models.TextField(blank=True, null=True)
    leslndam = models.CharField(
        db_column='LesLNDam',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    polelndam = models.CharField(
        db_column='PoLeLNDam',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    lesvadam = models.CharField(
        db_column='LesVADam',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    lastvisitwithdata = models.CharField(
        db_column='LastVisitWithData',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    datelastvisitwithdata = models.DateField(
        db_column='DateLastVisitWithData',
        blank=True,
        null=True
    )  # Field name made lowercase.
    reasonsloss = models.DateField(
        db_column='ReasonsLoss',
        blank=True,
        null=True
    )  # Field name made lowercase.
    
    class Meta:
        managed = False
        db_table = 'web__dam_info'
        verbose_name = 'Dam information'

    def __str__(self):
        return '{} - {}'.format(self.dam_id, self.visitid)


class Calfinfo(AnimalinfoModel):
    """
    Contains information about the calf at each visit, this includes
    weight and girth measurements, rectal temperature, presence of
    ectoparasites as well as movement in and out of the herd between
    visits and illnesses within the herd.

    Calf phenotype information is also included in this table. 
    """
    cadob = models.DateField(
        db_column='CADOB',
        blank=True,
        null=True
    )  # Field name made lowercase.
    calfsex = models.CharField(
        db_column='CalfSex',
        max_length=1,
        blank=True,
        null=True
    )  # Field name made lowercase.
    lossfollow = models.CharField(
        db_column='LossFollow',
        max_length=3,
        blank=True,
        null=True
    )  # Field name made lowercase.
    ce = models.CharField(max_length=3, blank=True, null=True)
    girth = models.DecimalField(
        max_digits=5,
        decimal_places=1,
        blank=True,
        null=True
    )
    weight = models.DecimalField(
        max_digits=5,
        decimal_places=1,
        blank=True,
        null=True
    )
    suckling = models.IntegerField(
        blank=True,
        null=True
    )
    rt = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        blank=True,
        null=True
    )
    famacha_l = models.BigIntegerField(blank=True, null=True)
    famacha_r = models.BigIntegerField(blank=True, null=True)
    elasticity = models.CharField(max_length=9, blank=True, null=True)
    f_consist = models.CharField(
        max_length=60,
        blank=True,
        null=True
    )
    diaorseverity = models.CharField(
        db_column='diaorSeverity',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    diaorkind = models.CharField(
        db_column='diaorKind',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    diaorodour = models.CharField(
        db_column='diaorOdour',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    hrsscm = models.DecimalField(
        db_column='HRSSCM',
        max_digits=11,
        decimal_places=5,
        blank=True,
        null=True
    )  # Field name made lowercase.
    hlsscm = models.DecimalField(
        db_column='HLSSCM',
        max_digits=11,
        decimal_places=5,
        blank=True,
        null=True
    )  # Field name made lowercase.
    hrpccm = models.DecimalField(
        db_column='HRPCCM',
        max_digits=11,
        decimal_places=5,
        blank=True,
        null=True
    )  # Field name made lowercase.
    hlpccm = models.DecimalField(
        db_column='HLPCCM',
        max_digits=11,
        decimal_places=5,
        blank=True,
        null=True
    )  # Field name made lowercase.
    rappend = models.CharField(
        db_column='RAPPEND',
        max_length=7,
        blank=True,
        null=True
    )  # Field name made lowercase.
    ammbly = models.CharField(
        db_column='AMMBLY',
        max_length=7,
        blank=True,
        null=True
    )  # Field name made lowercase.
    booph = models.CharField(
        db_column='BOOPH',
        max_length=7,
        blank=True,
        null=True
    )  # Field name made lowercase.
    hyalomm = models.CharField(
        db_column='HYALOMM',
        max_length=7,
        blank=True,
        null=True
    )  # Field name made lowercase.
    other_tick_louse = models.CharField(max_length=7, blank=True, null=True)
    lice = models.CharField(
        db_column='LICE',
        max_length=7,
        blank=True,
        null=True
    )  # Field name made lowercase.
    fleas = models.CharField(
        db_column='FLEAS',
        max_length=7,
        blank=True,
        null=True
    )  # Field name made lowercase.
    vtcalfyn = models.CharField(
        db_column='VTCalfYN',
        max_length=3,
        blank=True,
        null=True
    )  # Field name made lowercase.
    vtdamyn = models.CharField(
        db_column='VTDamYN',
        max_length=3,
        blank=True,
        null=True
    )  # Field name made lowercase.
    vtherdyn = models.CharField(
        db_column='VTHerdYN',
        max_length=3,
        blank=True,
        null=True
    )  # Field name made lowercase.
    grazing = models.CharField(
        db_column='Grazing',
        max_length=3,
        blank=True,
        null=True
    )  # Field name made lowercase.
    cynb = models.CharField(
        db_column='CYNB',
        max_length=3,
        blank=True,
        null=True
    )  # Field name made lowercase.
    dynb = models.CharField(
        db_column='DYNB',
        max_length=3,
        blank=True,
        null=True
    )  # Field name made lowercase.
    hynb = models.CharField(
        db_column='HYNB',
        max_length=3,
        blank=True,
        null=True
    )  # Field name made lowercase.
    currentnumbercattle = models.BigIntegerField(
        db_column='CurrentNumberCattle',
        blank=True,
        null=True
    )  # Field name made lowercase.
    totalentries = models.BigIntegerField(
        db_column='TotalEntries',
        blank=True,
        null=True
    )  # Field name made lowercase.
    totaldeaths = models.BigIntegerField(
        db_column='TotalDeaths',
        blank=True,
        null=True
    )  # Field name made lowercase.
    totalexits = models.BigIntegerField(
        db_column='TotalExits',
        blank=True,
        null=True
    )  # Field name made lowercase.
    animalcatdead = models.TextField(
        db_column='AnimalCatDead',
        blank=True,
        null=True
    )  # Field name made lowercase.
    numdeadanicat = models.TextField(
        db_column='NumDeadAniCat',
        blank=True,
        null=True
    )  # Field name made lowercase.
    whydead = models.TextField(db_column='WhyDead',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_calf_cattto = models.TextField(
        db_column='VetInter_Calf_CatTto',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_calf_typetto = models.TextField(
        db_column='VetInter_Calf_TypeTto',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_calf_typeapplic = models.TextField(
        db_column='VetInter_Calf_TypeApplic',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_calf_nherdtto = models.TextField(
        db_column='VetInter_Calf_NHerdTto',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_dam_cattto = models.TextField(
        db_column='VetInter_Dam_CatTto',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_dam_typetto = models.TextField(
        db_column='VetInter_Dam_TypeTto',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_dam_typeapplic = models.TextField(
        db_column='VetInter_Dam_TypeApplic',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_dam_nherdtto = models.TextField(
        db_column='VetInter_Dam_NHerdTto',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_herd_cattto = models.TextField(
        db_column='VetInter_Herd_CatTto',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_herd_typetto = models.TextField(
        db_column='VetInter_Herd_TypeTto',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_herd_typeapplic = models.TextField(
        db_column='VetInter_Herd_TypeApplic',
        blank=True,
        null=True
    )  # Field name made lowercase.
    vetinter_herd_nherdtto = models.TextField(
        db_column='VetInter_Herd_NHerdTto',
        blank=True,
        null=True
    )  # Field name made lowercase.
    hprobcat = models.TextField(
        db_column='HProbCat',
        blank=True,
        null=True
    )  # Field name made lowercase.
    hlestype = models.TextField(
        db_column='HLesType',
        blank=True,
        null=True
    )  # Field name made lowercase.
    observedby = models.TextField(
        db_column='ObservedBy',
        blank=True,
        null=True
    )  # Field name made lowercase.
    damaffected = models.TextField(
        db_column='DamAffected',
        blank=True,
        null=True
    )  # Field name made lowercase.
    percentherd = models.TextField(
        db_column='PercentHerd',
        blank=True,
        null=True
    )  # Field name made lowercase.
    #cprobcat = models.TextField(
    #    db_column='CProbCat',
    #    blank=True, null=True
    #)  # Field name made lowercase.
    #clestype = models.TextField(
    #    db_column='CLesType',
    #    blank=True,
    #    null=True
    #)  # Field name made lowercase.
    #ccs = models.TextField(
    #    db_column='CCS',
    #    blank=True,
    #    null=True
    #)  # Field name made lowercase.
    calfdonev = models.CharField(
        db_column='CalfDoneV',
        max_length=25,
        blank=True,
        null=True
    )  # Field name made lowercase.
    hair_typ = models.CharField(
        db_column='HAIR_TYP',
        max_length=60,
        blank=True,
        null=True
    )  # Field name made lowercase.
    head_colour_fifth = models.IntegerField(blank=True, null=True)
    hump_size = models.CharField(max_length=6, blank=True, null=True)
    hump_orientation = models.CharField(max_length=13, blank=True, null=True)
    hump_location = models.CharField(max_length=16, blank=True, null=True)
    face = models.CharField(max_length=7, blank=True, null=True)
    back_profile = models.CharField(max_length=8, blank=True, null=True)
    rump_profile = models.CharField(max_length=7, blank=True, null=True)
    horn_presence = models.CharField(max_length=7, blank=True, null=True)
    horn_shape = models.CharField(max_length=11, blank=True, null=True)
    horn_orientation = models.CharField(max_length=8, blank=True, null=True)
    horn_spacing = models.CharField(max_length=6, blank=True, null=True)
    horn_length = models.CharField(max_length=6, blank=True, null=True)
    naval_flap_size = models.CharField(max_length=6, blank=True, null=True)
    ear_size = models.CharField(max_length=5, blank=True, null=True)
    ear_shape = models.CharField(max_length=14, blank=True, null=True)
    ear_orientation = models.CharField(max_length=8, blank=True, null=True)
    tail_length = models.CharField(max_length=6, blank=True, null=True)
    tail_thickness = models.CharField(max_length=6, blank=True, null=True)
    udder_size = models.CharField(max_length=6, blank=True, null=True)
    teats_size = models.CharField(max_length=11, blank=True, null=True)
    testis = models.CharField(max_length=6, blank=True, null=True)
    perpuce = models.CharField(max_length=6, blank=True, null=True)
    hwc = models.DecimalField(
        db_column='HWC',
        max_digits=11,
        decimal_places=5,
        blank=True,
        null=True
    )
    sthc = models.DecimalField(
        db_column='STHC',
        max_digits=11,
        decimal_places=5,
        blank=True, null=True
    )
    blc = models.DecimalField(
        db_column='BLC',
        max_digits=5,
        decimal_places=1,
        blank=True,
        null=True
    )
    lastvisitwithdata = models.CharField(
        db_column='LastVisitWithData',
        blank=True,
        null=True,
        max_length=50
    )
    datelastvisitwithdata = models.DateField(
        db_column='DateLastVisitWithdata',
        blank=True, null=True
    )
    reasonsloss = models.CharField(
        db_column='ReasonsLoss',
        blank=True,
        max_length=50,
        null=True
    )
    postmortemdone = models.CharField(
        db_column='PostMortemDone',
        blank=True,
        max_length=50,
        null=True
    )
    reasonspmnotdone = models.CharField(
        db_column='ReasonsPMNotDone',
        blank=True,
        max_length=50,
        null=True
    )
    deadalive = models.CharField(
        db_column='DeadAlive',
        blank=True,
        max_length=50,
        null=True
    )
    ceever = models.CharField(
        db_column='ce_ever',
        blank=True,
        max_length=50,
        null=True
    )
    class Meta:
        managed = False
        db_table = 'web__calf_info'
        verbose_name = 'Calf information'

    def __str__(self):
        return '{} {}'.format(self.calf_id, self.visitid)

    @cached_property
    def head_colours(self):
        return format_html(
            self.get_colours(self.head_colour_predominant) +
            self.get_colours(self.head_colour_second) +
            self.get_colours(self.head_colour_third) +
            self.get_colours(self.head_colour_fourth) +
            self.get_colours(self.head_colour_fifth)
        )
          
    @cached_property
    def head_colours_hex(self):
        return '1. {}; 2. {}; 3. {}; 4. {}; 5: {}'.format(
            self.get_colours_hex(self.head_colour_predominant),
            self.get_colours_hex(self.head_colour_second),
            self.get_colours_hex(self.head_colour_third),
            self.get_colours_hex(self.head_colour_fourth),
            self.get_colours_hex(self.head_colour_fifth)
        )


class Testinfo(models.Model):
    """
    Contains the results of all the tests carried out on the calves and dams.  
    """
    calf_id = models.CharField(
        db_column='CalfID',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    dam_id = models.CharField(
        db_column='DamID',
        max_length=50,
        blank=True,
        null=True
    )
    visit_id = models.CharField(
        db_column='VisitID',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    visitdate = models.DateField(
        db_column='VisitDate',
        blank=True,
        null=True
    )  # Field name made lowercase.
    result_id = models.CharField(
        db_column='ResultID',
        max_length=50
    )  # Field name made lowercase.
    rsid = models.CharField(
        db_column='RSID',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    samplecode = models.CharField(
        db_column='SampleCode',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    test = models.CharField(
        db_column='Test',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    possiblepathogen = models.CharField(
        db_column='PossiblePathogen',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    resultstatus = models.CharField(
        db_column='ResultStatus',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.
    resultnum = models.DecimalField(
        db_column='ResultNum',
        max_digits=11,
        decimal_places=5,
        blank=True,
        null=True
    )  # Field name made lowercase.
    lifestage = models.CharField(
        db_column='LifeStage',
        max_length=50,
        blank=True,
        null=True
    )  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'web__test_info'
        verbose_name = 'Test information'

    def __str__(self):
        return self.result_id


class Clinicalinfo(models.Model):
    """
    Information about the clinical episodes the calf experienced.
    Contains infomation on the body part affected by the disorder,
    the disorder/lesion and the extent of the lesion.
    """
    calfid = models.CharField(
        db_column='CalfID',
        max_length=50,
        blank=True,
        null=True
    )
    damid = models.CharField(
        db_column='DamID',
        max_length=50,
        blank=True,
        null=True
    )
    visitid = models.CharField(
        db_column='VisitID',
        max_length=50,
    )
    bodypart = models.CharField(
        db_column='BodyPart',
        max_length=50,
        blank=True,
        null=True
    )
    lescat = models.CharField(
        db_column='LesCat',
        max_length=50,
        blank=True,
        null=True
    )
    lestype = models.CharField(
        db_column='LesType',
        max_length=50,
        blank=True,
        null=True
    )
    other = models.CharField(
        db_column='Other',
        max_length=50,
        blank=True,
        null=True
    )
    position = models.CharField(
        db_column='Position',
        max_length=50,
        blank=True,
        null=True
    )
    extension_pattern_lesion = models.CharField(
        db_column='Extension_pattern_lesion',
        max_length=50,
        blank=True,
        null=True
    )
    lesion_location_capsule = models.CharField(
        db_column='Lesion_location_capsule',
        max_length=50,
        blank=True,
        null=True
    )
    ccs = models.CharField(
        db_column='CCS',
        max_length=50,
        blank=True,
        null=True
    )
    class Meta:
        managed = False
        db_table = 'web__clinical_info'
        verbose_name = 'Clinical information'

    def __str__(self):
        return '{} {}'.format(self.calfid, self.visitid)


class Postmorteminfo(models.Model):
    """
    Post-mortem reports for the dead calves.
    """
    calfid = models.CharField(
        db_column='CalfID',
        max_length=50,
        blank=True,
        null=True
    )
    damid = models.CharField(
        db_column='DamID',
        max_length=50,
        blank=True,
        null=True
    )
    visitid = models.CharField(
        db_column='VisitID',
        max_length=50,
    )
    deathdate = models.DateField(
        db_column='DeathDate',
        blank=True,
        null=True
    )
    euthanised = models.CharField(
        db_column='Euthanised',
        max_length=50,
        blank=True,
        null=True
    )
    immediate_cause_pathology = models.CharField(
        db_column='ImmediateCausePathology',
        max_length=100,
        blank=True,
        null=True
    )
    definitive_aetiological_cause = models.CharField(
        db_column='DefinitiveAetiologicalCause',
        max_length=100,
        blank=True,
        null=True
    )
    definitive_cause_pathogen = models.CharField(
        db_column='DefCausePathogen',
        max_length=100,
        blank=True,
        null=True
    )
    contributing_pathology_1 = models.CharField(
        db_column='ContributingPathology1',
        max_length=100,
        blank=True,
        null=True
    )
    contributing_cause_1 = models.CharField(
        db_column='ContributingCause1',
        max_length=100,
        blank=True,
        null=True
    )
    contributing_cause_pathogen_1 = models.CharField(
        db_column='ContCausePathogen1',
        max_length=100,
        blank=True,
        null=True
    )
    contributing_pathology_2 = models.CharField(
        db_column='ContributingPathology2',
        max_length=100,
        blank=True,
        null=True
    )
    contributing_cause_2 = models.CharField(
        db_column='ContributingCause2',
        max_length=100,
        blank=True,
        null=True
    )
    contributing_cause_pathogen_2 = models.CharField(
        db_column='ContCausePathogen2',
        max_length=100,
        blank=True,
        null=True
    )
    pm_comments = models.CharField(
        db_column='PMComments',
        max_length=200,
        blank=True,
        null=True
    )
    pm_report = models.CharField(
        db_column='PMReport',
        max_length=50,
        blank=True,
        null=True
    )
    histopath_report = models.CharField(
        db_column='HistopathReport',
        max_length=200,
        blank=True,
        null=True
    )
    histo_aetiological_diagnosis  = models.CharField(
        db_column='HistoAetiologicalDiagnosis',
        max_length=200,
        blank=True,
        null=True
    )
    histo_comments = models.CharField(
        db_column='HistoComments',
        max_length=200,
        blank=True,
        null=True
    )
    stomach_content = models.CharField(
        db_column='stomach_content',
        max_length=200,
        blank=True,
        null=True
    )
    class Meta:
        managed = False
        db_table = 'web__postmortem_info'
        verbose_name = 'Post-mortem information'

    def __str__(self):
        return '{} {}'.format(self.calfid, self.visitid)


class Sampleinfo(models.Model):
    """
    Information about the samples taken at each visit and links the visit to the samples stored in the biobank. 
    """
    calfid = models.CharField(
        db_column='CalfID',
        max_length=50,
        blank=True,
    )
    damid = models.CharField(
        db_column='DamID',
        max_length=50,
        blank=True,
    )
    visitid = models.CharField(
        db_column='VisitID',
        max_length=50,
        blank=True,
    )
    visitdate = models.DateField(
        db_column='VisitDate',
        blank=True,
        null=True
    )
    sampleid = models.CharField(
        db_column='SampleID',
        max_length=50,
        blank=True,
    )
    storelabel = models.CharField(
        db_column='StoreLabel',
        max_length=50,
        blank=True,
    )
    visittype = models.CharField(
        db_column='VisitType',
        max_length=3,
        blank=True,
    )
    sampletype = models.CharField(
        db_column='SampleType',
        max_length=3,
        blank=True,
    )
    storetype = models.CharField(
        db_column='StoreType',
        max_length=3,
        blank=True,
    )
    tank = models.IntegerField(
        db_column='Tank',
        blank=True,
        null=True,
    )  # Field name made lowercase.
    sector = models.CharField(
        db_column='Sector',
        max_length=2,
        blank=True,
    )  # Field name made lowercase.
    boxnum = models.CharField(
        db_column='BoxNum',
        max_length=12,
        blank=True,
        null=True,
    )  # Field name made lowercase.
    boxposition = models.IntegerField(
        db_column='BoxPosition',
        blank=True,
        null=True,
    )  # Field name made lowercase.
    samplepos = models.IntegerField(
        db_column='SamplePos',
        blank=True,
        null=True,
    )  # Field name made lowercase.
    comments = models.CharField(
        db_column='Comments',
        max_length=255,
        blank=True
    )  # Field name made lowercase.
    
    class Meta:
        managed = False
        db_table = 'web__sample_info'
        verbose_name = 'Sample information'
        verbose_name_plural = 'Sample information'

    def __str__(self):
        return self.sampleid


class Followupinfo(models.Model):
    """
    Contains the results of a follow-up questionnaire which happened
    one year after the IDEAL project was completed to find out what had
    happened to them; if they where alive, dead or sold and if they had
    offspring.
    """
    calf_id = models.CharField(max_length=11, unique=True)
    cadob = models.DateField()
    calf_sex = models.CharField(max_length=1, choices=SEXES) 
    dead_alive_end_ideal = models.CharField(max_length=50)
    status_1year = models.CharField(max_length=100)
    status_1year_comments = models.CharField(max_length=100)
    year_died = models.CharField(max_length=4)
    death_comments = models.CharField(max_length=255)
    offspring_status = models.CharField(max_length=25)
    num_calves = models.CharField(max_length=2)
    num_abortions = models.CharField(max_length=2)
    age_first_birth = models.CharField(max_length=2)
    age_first_birth_year = models.CharField(max_length=4)
    age_last_birth = models.CharField(max_length=2)
    age_last_birth_year = models.CharField(max_length=4)

    class Meta:
        managed = True
        db_table = 'web__followup_info'
        verbose_name = 'Follow-up information'

    def __str__(self):
        return self.calf_id
