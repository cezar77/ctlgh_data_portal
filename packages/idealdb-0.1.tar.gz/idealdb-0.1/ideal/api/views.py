from rest_framework import viewsets

from ideal.models import (
    Calfinfo,
    Clinicalinfo,
    Daminfo,
    Farminfo,
    Followupinfo,
    Postmorteminfo,
    Sampleinfo,
    Testinfo,
)
from .serializers import (
    CalfInfoSerializer,
    ClinicalInfoSerializer,
    DamInfoSerializer,
    FarmInfoSerializer,
    FollowUpInfoSerializer,
    PostmortemInfoSerializer,
    SampleInfoSerializer,
    TestInfoSerializer
)


class CalfInfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Calf Info View Set** automatically provides the following actions:

     - `list`
     - `retrieve`
    """
    queryset = Calfinfo.objects.all()
    serializer_class = CalfInfoSerializer


class ClinicalInfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Clinical Info View Set** automatically provides the following actions:

     - `list`
     - `retrieve`
    """
    queryset = Clinicalinfo.objects.all()
    serializer_class = ClinicalInfoSerializer


class DamInfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Dam Info View Set** automatically provides the following actions:

     - `list`
     - `retrieve`
    """
    queryset = Daminfo.objects.all()
    serializer_class = DamInfoSerializer


class FarmInfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Farm Info View Set** automatically provides the following actions:

     - `list`
     - `retrieve`
    """
    queryset = Farminfo.objects.all()
    serializer_class = FarmInfoSerializer


class FollowUpInfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Follow Up Info View Set** automatically provides the following actions:

     - `list`
     - `retrieve`
    """
    queryset = Followupinfo.objects.all()
    serializer_class = FollowUpInfoSerializer


class PostmortemInfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Postmortem Info View Set** automatically provides the following actions:

     - `list`
     - `retrieve`
    """
    queryset = Postmorteminfo.objects.all()
    serializer_class = PostmortemInfoSerializer


class SampleInfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Sample Info View Set** automatically provides the following actions:

     - `list`
     - `retrieve`
    """
    queryset = Sampleinfo.objects.all()
    serializer_class = SampleInfoSerializer


class TestInfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Test Info View Set** automatically provides the following actions:

     - `list`
     - `retrieve`
    """
    queryset = Testinfo.objects.all()
    serializer_class = TestInfoSerializer
