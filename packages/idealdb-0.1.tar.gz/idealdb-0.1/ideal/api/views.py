from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters
from rest_framework import status
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from ideal.api.models import Genotype
from ideal.api.renderers import PedRenderer
from ideal.models import (
    Calfinfo,
    Clinicalinfo,
    Daminfo,
    Farminfo,
    Followupinfo,
    Postmorteminfo,
    Sampleinfo,
    Testinfo,
)
from ideal.tables import CalfinfoTable, DaminfoTable
from .filters import (
    CalfinfoFilter,
    ClinicalinfoFilter,
    DaminfoFilter,
    FarminfoFilter,
    FollowupinfoFilter,
    PostmorteminfoFilter,
    SampleinfoFilter,
    TestinfoFilter,
)
from .serializers import (
    CalfinfoSerializer,
    ClinicalinfoSerializer,
    DaminfoSerializer,
    FarminfoSerializer,
    FollowupinfoSerializer,
    PostmorteminfoSerializer,
    SampleinfoSerializer,
    TestinfoSerializer,
)


def get_response(serializer, fixed_attributes):
    data = serializer.data.copy()
    result = {k: v for k, v in data[0].items() if k in fixed_attributes}
    result['visits'] = list(map(
        lambda x: {k: v for k, v in x.items() if k not in fixed_attributes},
        data
    ))
    return result


class CalfinfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Calf Information** endpoint automatically provides
    the following actions:

     - `list`
     - `retrieve`

    Endpoints are filtered by **Calf ID** and provide a list of
    Calf Information instances associated with a given calf.

    ###Hyperlinks
    - The **daminfo_url** hyperlink provides automatic
    access to the given Dam Information endpoint.

    - The **ped_50k** hyperlink provides automatic
    access to the given SNP 50K Pedigree data.

    - The **ped_770k** hyperlink provides automatic
    access to the given SNP 770K Pedigree data.

    ###Filters
    - The search field is available for automatic searches
    across all text fields.

    - Field filters will narrow down the list based on specific fields.

    ###Extra Actions
    - **Pedigree(s) 50K** : Accesses SNP 50K Pedigree data from all calves listed.
    - **Pedigree(s) 770K** : Accesses SNP 770K Pedigree data from all calves listed.

    ##`Warning`
    SNP 50K or SNP 770K Pedigree files may be very large
    and take a long time to be processed. Please proceed with caution.
    """
    queryset = Calfinfo.objects.all().order_by('calf_id')
    serializer_class = CalfinfoSerializer
    lookup_field = 'calf_id'
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    filter_class = CalfinfoFilter
    search_fields = [
        field.name for field in Calfinfo._meta.get_fields()
        if field.get_internal_type() in ('CharField', 'TextField')
    ]

    def retrieve(self, request, *args, **kwargs):
        calf_id = self.kwargs.get('calf_id')
        queryset = Calfinfo.objects.filter(calf_id=calf_id)
        serializer = self.get_serializer(queryset, many=True)
        fixed_attributes = []
        fixed_attributes.extend(CalfinfoTable.column_groups['hide_phenotype']['columns'])
        fixed_attributes.extend(CalfinfoTable.column_groups['hide_fixed_measurements']['columns'])
        fixed_attributes.extend(CalfinfoTable.column_groups['hide_calf_key_info']['columns'])
        fixed_attributes.extend(['calf_id', 'dam_id', 'daminfo_url', 'ped_50k', 'ped_770k', 'url', 'body_colours_hex',
                                 'head_colours_hex', 'ear_colours_hex', 'tail_colours_hex',
                                 'hoof_colours_hex', 'muzzle_colours_hex'])
        result = get_response(serializer, fixed_attributes)
        return Response(result)

    @action(detail=False, renderer_classes=[PedRenderer])
    def pedigrees_50k(self, request, *args, **kwargs):
        """An additional endpoint which returns the calves' 50k pedigree data in text format."""
        qs = self.filter_queryset(self.get_queryset())
        calf_ids = qs.values_list('calf_id', flat=True).distinct()
        entries = Genotype.objects.filter(calf_id__in=calf_ids)
        output = [entry.ped_50k for entry in entries]
        return Response(output)

    @action(detail=False, renderer_classes=[PedRenderer])
    def pedigrees_770k(self, request, *args, **kwargs):
        """An additional endpoint which returns the calves' 50k pedigree data in text format."""
        qs = self.filter_queryset(self.get_queryset())
        calf_ids = qs.values_list('calf_id', flat=True).distinct()
        entries = Genotype.objects.filter(calf_id__in=calf_ids)
        output = [entry.ped_770k for entry in entries]
        return Response(output)

    @action(detail=True, renderer_classes=[PedRenderer])
    def pedigree_50k(self, request, *args, **kwargs):
        """An additional endpoint which returns the calf's 50k pedigree data in text format."""
        calf_id = self.kwargs.get('calf_id')
        entry = Genotype.objects.get(calf_id=calf_id)
        return Response(entry.ped_50k)

    @action(detail=True, renderer_classes=[PedRenderer])
    def pedigree_770k(self, request, *args, **kwargs):
        """An additional endpoint which returns the calf's 770k pedigree data in text format."""
        calf_id = self.kwargs.get('calf_id')
        entry = Genotype.objects.get(calf_id=calf_id)
        if entry.ped_770k == '':
            return Response(
                data='HD genotyping data not available for calf {}.'.format(calf_id),
                status=status.HTTP_404_NOT_FOUND)
        else:
            return Response(entry.ped_770k)


class ClinicalinfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Clinical Information** endpoint automatically provides
    the following actions:

     - `list`
     - `retrieve`

    Endpoints are filtered by **Visit ID** and provide a list of
    Clinical Information instances associated with a given visit.

    ###Hyperlinks
    - The **calfinfo_url** hyperlink provides automatic access
    to the given Calf Information endpoint.

    ###Filters
    - The search field is available for automatic searches
    across all text fields.

    - Field filters will narrow down the list based on specific fields.
    """
    queryset = Clinicalinfo.objects.all().order_by('visitid')
    serializer_class = ClinicalinfoSerializer
    lookup_field = 'visitid'
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    filter_class = ClinicalinfoFilter
    search_fields = [
        field.name for field in Clinicalinfo._meta.get_fields()
        if field.get_internal_type() in ('CharField', 'TextField')
    ]

    def retrieve(self, request, *args, **kwargs):
        visitid = self.kwargs.get('visitid')
        queryset = Clinicalinfo.objects.filter(visitid=visitid)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class DaminfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Dam Information** endpoint automatically provides
    the following actions:

     - `list`
     - `retrieve`

    Endpoints are filtered by **Dam ID** and provide a list of
    Dam Information instances associated with a given dam.

    ###Hyperlinks
    - The **calfinfo_url** hyperlink provides automatic access
    to the given Calf Information endpoint.

    ###Filters
    - The search field is available for automatic searches
    across all text fields.

    - Field filters will narrow down the list based on specific fields.
    """
    queryset = Daminfo.objects.all().order_by('dam_id')
    serializer_class = DaminfoSerializer
    lookup_field = 'dam_id'
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    filter_class = DaminfoFilter
    search_fields = [
        field.name for field in Daminfo._meta.get_fields()
        if field.get_internal_type() in ('CharField', 'TextField')
    ]

    def retrieve(self, request, *args, **kwargs):
        dam_id = self.kwargs.get('dam_id')
        queryset = Daminfo.objects.filter(dam_id=dam_id)
        serializer = self.get_serializer(queryset, many=True)
        fixed_attributes = []
        fixed_attributes.extend(DaminfoTable.column_groups['hide_phenotype']['columns'])
        fixed_attributes.extend(['dam_id', 'calfinfo_url', 'url', 'body_colours_hex',
                                 'head_colours_hex', 'ear_colours_hex', 'tail_colours_hex',
                                 'hoof_colours_hex', 'muzzle_colours_hex'])
        result = get_response(serializer, fixed_attributes)
        return Response(result)


class FarminfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Farm Information** endpoint automatically provides
    the following actions:

     - `list`
     - `retrieve`

    Endpoints are filtered by **Farmer ID** and provide the
    Farm Information instance associated with a given farmer.

    ###Hyperlinks
    - The **calfinfo_url** hyperlink provides automatic access
    to the given Calf Information endpoint.

    - The **daminfo_url** hyperlink provides automatic
    access to the given Dam Information endpoint.

    ###Filters
    - The search field is available for automatic searches
    across all text fields.

    - Field filters will narrow down the list based on specific fields.
    """
    queryset = Farminfo.objects.all().order_by('farmer_id')
    serializer_class = FarminfoSerializer
    lookup_field = 'farmer_id'
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    filter_class = FarminfoFilter
    search_fields = [
        field.name for field in Farminfo._meta.get_fields()
        if field.get_internal_type() in ('CharField', 'TextField')
    ]


class FollowupinfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Followup Information** endpoint automatically provides
    the following actions:

     - `list`
     - `retrieve`

    Endpoints are filtered by **Calf ID** and provide the Follow Up
    Information instance associated with a given calf.

    ###Hyperlinks
    - The **calfinfo_url** hyperlink provides automatic access
    to the given Calf Information endpoint.

    ###Filters
    - The search field is available for automatic searches
    across all text fields.

    - Field filters will narrow down the list based on specific fields.
    """
    queryset = Followupinfo.objects.all().order_by('calf_id')
    serializer_class = FollowupinfoSerializer
    lookup_field = 'calf_id'
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    filter_class = FollowupinfoFilter
    search_fields = [
        field.name for field in Followupinfo._meta.get_fields()
        if field.get_internal_type() in ('CharField', 'TextField')
    ]


class PostmorteminfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Postmortem Information** endpoint automatically provides
    the following actions:

     - `list`
     - `retrieve`

    Endpoints are filtered by **Visit ID** and provide the
    Postmortem Information instance associated with a given visit.

    ###Hyperlinks
    - The **calfinfo_url** hyperlink provides automatic access
    to the given Calf Information endpoint.

    ###Filters
    - The search field is available for automatic searches
    across all text fields.

    - Field filters will narrow down the list based on specific fields.
    """
    queryset = Postmorteminfo.objects.all().order_by('visitid')
    serializer_class = PostmorteminfoSerializer
    lookup_field = 'visitid'
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    filter_class = PostmorteminfoFilter
    search_fields = [
        field.name for field in Postmorteminfo._meta.get_fields()
        if field.get_internal_type() in ('CharField', 'TextField')
    ]


class SampleinfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Sample Information** endpoint automatically provides
    the following actions:

     - `list`
     - `retrieve`

    Endpoints are filtered by **Visit ID** and provide a list of
    Sample Information instances associated with a given visit.

    ###Hyperlinks
    - The **calfinfo_url** hyperlink provides automatic access
    to the given Calf Information endpoint.

    - The **daminfo_url** hyperlink provides automatic
    access to the given Dam Information endpoint.

    ###Filters
    - The search field is available for automatic searches
    across all text fields.

    - Field filters will narrow down the list based on specific fields.
    """
    queryset = Sampleinfo.objects.all().order_by('visitid')
    serializer_class = SampleinfoSerializer
    lookup_field = 'visitid'
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    filter_class = SampleinfoFilter
    search_fields = [
        field.name for field in Sampleinfo._meta.get_fields()
        if field.get_internal_type() in ('CharField', 'TextField')
    ]

    def retrieve(self, request, *args, **kwargs):
        visitid = self.kwargs.get('visitid')
        queryset = Sampleinfo.objects.filter(visitid=visitid)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class TestinfoViewSet(viewsets.ReadOnlyModelViewSet):
    """
    This **Test Information** endpoint automatically provides
    the following actions:

     - `list`
     - `retrieve`

    Endpoints are filtered by **Visit ID** and provide a list of
    Test Information instances associated with a given visit.

    ###Hyperlinks
    - The **calfinfo_url** hyperlink provides automatic access
    to the given Calf Information endpoint.

    - The **daminfo_url** hyperlink provides automatic
    access to the given Dam Information endpoint.

    ###Filters
    - The search field is available for automatic searches
    across all text fields.

    - Field filters will narrow down the list based on specific fields.
    """
    queryset = Testinfo.objects.all().order_by('visit_id')
    serializer_class = TestinfoSerializer
    lookup_field = 'visit_id'
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    filter_class = TestinfoFilter
    search_fields = [
        field.name for field in Testinfo._meta.get_fields()
        if field.get_internal_type() in ('CharField', 'TextField')
    ]

    def retrieve(self, request, *args, **kwargs):
        visit_id = self.kwargs.get('visit_id')
        queryset = Testinfo.objects.filter(visit_id=visit_id)
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)
