from django.conf.urls import include, url

from rest_framework.routers import DefaultRouter

from . import views


router = DefaultRouter()
router.register(r'calfinfo', views.CalfinfoViewSet)
router.register(r'clinicalinfo', views.ClinicalinfoViewSet)
router.register(r'daminfo', views.DaminfoViewSet)
router.register(r'farminfo', views.FarminfoViewSet)
router.register(r'followupinfo', views.FollowupinfoViewSet)
router.register(r'postmorteminfo', views.PostmorteminfoViewSet)
router.register(r'sampleinfo', views.SampleinfoViewSet)
router.register(r'testinfo', views.TestinfoViewSet)


app_name = 'api'
urlpatterns = [
    url('^', include(router.urls)),
]
