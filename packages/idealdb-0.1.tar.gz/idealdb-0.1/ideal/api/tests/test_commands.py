from io import StringIO
import os

from django.core.management import call_command
from django.test import TestCase

from ideal.api.models import Genotype
from .utils import create_table_calfinfo, drop_table_calfinfo


class Genotype50KTestCase(TestCase):
    """
    Includes testing for the genotype_50k command, which involves
    updating or creating database entries with 50K Genotyping data.

    Detailed information on **50K Genotyping** and the
    **Illumina BovineSNP50 v3 BeadChip** can be accessed on:
    https://www.illumina.com/products/by-type/microarray-kits/bovine-snp50.html
    """
    multi_db = True
    fixtures = ['test/calfinfo']

    @classmethod
    def setUpClass(cls):
        create_table_calfinfo()
        super(Genotype50KTestCase, cls).setUpClass()
        calf_id = 'CA010110001'
        Genotype.objects.create(calf_id=calf_id)
        cls.out = StringIO()
        test_dir = os.path.dirname(os.path.abspath(__file__))
        call_command(
            'genotype_50k',
            os.path.join(test_dir, 'test_50k.ped'),
            stdout=cls.out,
        )

    @classmethod
    def tearDownClass(cls):
        super(Genotype50KTestCase, cls).tearDownClass()
        drop_table_calfinfo()
        Genotype.objects.all().delete()

    def test_all_genotypes_saved(self):
        """
        50K Genotyping entries should be saved for
        all calves with a database record.
        """
        genotypes = Genotype.objects.all()
        self.assertEqual(genotypes.count(), 2)

    def test_genotype_updated(self):
        """
        Existing 50K Genotyping entries should be successfully updated.
        """
        genotype = Genotype.objects.get(calf_id='CA010110001')
        self.assertEqual(genotype.ped_50k[:21], '0 CA010110001 0 0 2 0')
        self.assertEqual(len(genotype.ped_50k), 225654)

    def test_genotype_created(self):
        """
        Novel 50K Genotyping entries should be successfully created for
        calves with a database record.
        """
        genotype = Genotype.objects.get(calf_id='CA010110002')
        self.assertEqual(genotype.ped_50k[:21], '0 CA010110002 0 0 1 0')
        self.assertEqual(len(genotype.ped_50k), 225654)

    def test_genotype_not_saved(self):
        """
        50K Genotyping entries should not be saved for
        calves without a database record.
        """
        genotype = Genotype.objects.filter(calf_id='CA010110004')
        self.assertFalse(genotype.exists())

    def test_command_output(self):
        """
        Feedback of the number of pedigree entries created and updated
        should be output successfully.
        """
        message = 'The pedigree entries for 1 calves were created. The pedigree entries for 1 calves were updated.'
        self.assertIn(message, self.out.getvalue())


class Genotype770KTestCase(TestCase):
    """
    Includes testing for the genotype_770k command, which involves
    updating or creating database entries with 770K Genotyping data.

    Detailed information on **770k Genotyping** and the
    **Illumina BovineHD Genotyping BeadChip** can be accessed on:
    https://www.illumina.com/products/by-type/microarray-kits/bovinehd.html
    """
    @classmethod
    def setUpClass(cls):
        super(Genotype770KTestCase, cls).setUpClass()
        calf_id = 'CA010310063'
        Genotype.objects.create(calf_id=calf_id)
        cls.out = StringIO()
        test_dir = os.path.dirname(os.path.abspath(__file__))
        call_command(
            'genotype_770k',
            os.path.join(test_dir, 'test_770k.ped'),
            os.path.join(test_dir, 'test_sampleid_calfid.csv'),
            stdout=cls.out,
        )

    @classmethod
    def tearDownClass(cls):
        super(Genotype770KTestCase, cls).tearDownClass()
        Genotype.objects.all().delete()

    def test_all_genotypes_saved(self):
        """
        770K Genotyping entries should be saved for
        all calves with a database record.
        """
        genotypes = Genotype.objects.all()
        self.assertEqual(genotypes.count(), 2)

    def test_genotype_updated(self):
        """
        Existing 770K Genotyping entries should be successfully updated.
        """
        genotype = Genotype.objects.get(calf_id='CA010310063')
        self.assertEqual(genotype.ped_770k[:13], '1 74 0 0 2 -9')
        self.assertEqual(len(genotype.ped_770k), 3111862)

    def test_genotype_created(self):
        """
        Novel 770K Genotyping entries should be successfully created for
        calves with a database record.
        """
        genotype = Genotype.objects.get(calf_id='CA041610451')
        self.assertEqual(genotype.ped_770k[:13], '2 76 0 0 2 -9')
        self.assertEqual(len(genotype.ped_770k), 3111862)

    def test_command_output(self):
        """
        Feedback of the number of pedigree entries created and updated
        should be output successfully.
        """
        message = 'The pedigree entries for 1 calves were created. The pedigree entries for 1 calves were updated.'
        self.assertIn(message, self.out.getvalue())
