from rest_framework.test import APITestCase

from .utils import (
    create_table_calfinfo,
    drop_table_calfinfo,
    create_table_clinicalinfo,
    drop_table_clinicalinfo,
    create_table_daminfo,
    drop_table_daminfo,
    create_table_farminfo,
    drop_table_farminfo,
    create_table_followupinfo,
    drop_table_followupinfo,
    create_table_postmorteminfo,
    drop_table_postmorteminfo,
    create_table_sampleinfo,
    drop_table_sampleinfo,
    create_table_testinfo,
    drop_table_testinfo,
)
from ..models import Genotype


class CalfinfoViewSetTestCase(APITestCase):
    multi_db = True
    fixtures = ['test/calfinfo']

    @classmethod
    def setUpClass(cls):
        create_table_calfinfo()
        super(CalfinfoViewSetTestCase, cls).setUpClass()

    @classmethod
    def tearDownClass(cls):
        drop_table_calfinfo()
        super(CalfinfoViewSetTestCase, cls).tearDownClass()

    @classmethod
    def setUpTestData(cls):
        cls.calf_1 = Genotype.objects.create(
            calf_id='CA010110001',
            ped_50k='0 CA010110001 0 0 2 0 G G C C'
        )
        cls.calf_2 = Genotype.objects.create(
            calf_id='CA010110012',
            ped_50k='0 CA010110012 0 0 1 1 G G T C',
            ped_770k='28 417 0 0 2 -9 A A A A'
        )
        cls.calf_3 = Genotype.objects.create(
            calf_id='CA010110002',
            ped_50k='0 CA010110002 0 0 1 1 G G T C',
            ped_770k='28 417 0 0 2 -9 A A A A'
        )

    def test_list_calfinfo(self):
        """
        All Calfinfo entries should be listed.
        """
        response = self.client.get('/ideal/api/calfinfo/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['count'], 22)
        self.assertEqual(response.data['next'], None)

    def test_retrieve_calfinfo(self):
        """
        A Calfinfo Instance should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/calfinfo/CA010110001/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data['visits']), 12)
        self.assertEqual(response.data['calf_id'], 'CA010110001')

    def test_filter_ped770k_present(self):
        """
        Calf instances, for which 770K SNP data is present, should be
        retrieved successfully.
        """
        response = self.client.get('/ideal/api/calfinfo/?ped_770k=true')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['results'][0]['calf_id'], 'CA010110002')

    def test_filter_ped770k_absent(self):
        """
        Calf instances, for which 770K SNP data is absent, should be
        retrieved successfully.
        """
        response = self.client.get('/ideal/api/calfinfo/?ped_770k=false')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['results'][0]['calf_id'], 'CA010110001')

    def test_retrieve_ped50k(self):
        """
        The 50K SNP data for all calves featured
        in a given Calfinfo List should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/calfinfo/pedigrees_50k/?ped_770k=true')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, ['0 CA010110002 0 0 1 1 G G T C'])

    def test_retrieve_ped50k_instance(self):
        """
        The 50K SNP data for a Calfinfo Instance should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/calfinfo/CA010110001/pedigree_50k/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.calf_1.ped_50k, '0 CA010110001 0 0 2 0 G G C C')

    def test_retrieve_ped770k(self):
        """
        The 770K SNP data for all calves featured
        in a given Calfinfo List should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/calfinfo/pedigrees_770k/?ped_770k=true')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, ['28 417 0 0 2 -9 A A A A'])

    def test_retrieve_available_ped770k_instance(self):
        """
        When 770K SNP data is available for a Calfinfo Instance,
        it should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/calfinfo/CA010110012/pedigree_770k/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.calf_2.ped_770k, '28 417 0 0 2 -9 A A A A')

    def test_retrieve_unavailable_ped770k_instance(self):
        """
        When 770K SNP data is unavailable for a Calfinfo Instance,
        the user should be informed with an error message.
        """
        response = self.client.get('/ideal/api/calfinfo/CA010110001/pedigree_770k/')
        self.assertEqual(response.status_code, 404)


class ClinicalinfoViewSetTestCase(APITestCase):
    multi_db = True
    fixtures = ['test/clinicalinfo']

    @classmethod
    def setUpClass(cls):
        create_table_clinicalinfo()
        super(ClinicalinfoViewSetTestCase, cls).setUpClass()

    @classmethod
    def tearDownClass(cls):
        drop_table_clinicalinfo()
        super(ClinicalinfoViewSetTestCase, cls).tearDownClass()

    def test_list_clinicalinfo(self):
        """
        All Clinicalinfo entries should be listed.
        """
        response = self.client.get('/ideal/api/clinicalinfo/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['count'], 252)
        self.assertTrue(response.data['next'].endswith('?page=2'))

    def test_retrieve_clinicalinfo(self):
        """
        A Clinicalinfo Instance should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/clinicalinfo/VCC010001/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 64)
        self.assertEqual(response.data[0]['visitid'], 'VCC010001')


class DaminfoViewSetTestCase(APITestCase):
    multi_db = True
    fixtures = ['test/daminfo']

    @classmethod
    def setUpClass(cls):
        create_table_daminfo()
        super(DaminfoViewSetTestCase, cls).setUpClass()

    @classmethod
    def tearDownClass(cls):
        drop_table_daminfo()
        super(DaminfoViewSetTestCase, cls).tearDownClass()

    def test_list_daminfo(self):
        """
        All Daminfo entries should be listed.
        """
        response = self.client.get('/ideal/api/daminfo/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['count'], 17)
        self.assertEqual(response.data['next'], None)

    def test_retrieve_daminfo(self):
        """
        A Daminfo Instance should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/daminfo/DM010120001/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data['visits']), 10)
        self.assertEqual(response.data['dam_id'], 'DM010120001')


class FarminfoViewSetTestCase(APITestCase):
    multi_db = True
    fixtures = ['test/farminfo']

    @classmethod
    def setUpClass(cls):
        create_table_farminfo()
        super(FarminfoViewSetTestCase, cls).setUpClass()

    @classmethod
    def tearDownClass(cls):
        drop_table_farminfo()
        super(FarminfoViewSetTestCase, cls).tearDownClass()

    def test_list_farminfo(self):
        """
        All Farminfo entries should be listed.
        """
        response = self.client.get('/ideal/api/farminfo/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['count'], 5)
        self.assertEqual(response.data['next'], None)

    def test_retrieve_farminfo(self):
        """
        A Farminfo Instance should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/farminfo/FR010130001/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['calf_id'], 'CA010110001')
        self.assertEqual(response.data['farmer_id'], 'FR010130001')
        self.assertEqual(response.data['dam_id'], 'DM010120001')


class FollowupinfoViewSetTestCase(APITestCase):
    multi_db = True
    fixtures = ['test/followupinfo']

    @classmethod
    def setUpClass(cls):
        create_table_followupinfo()
        super(FollowupinfoViewSetTestCase, cls).setUpClass()

    @classmethod
    def tearDownClass(cls):
        drop_table_followupinfo()
        super(FollowupinfoViewSetTestCase, cls).tearDownClass()

    def test_list_followupinfo(self):
        """
        All Followupinfo entries should be listed.
        """
        response = self.client.get('/ideal/api/followupinfo/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['count'], 5)
        self.assertEqual(response.data['next'], None)

    def test_retrieve_followupinfo(self):
        """
        A Followupinfo Instance should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/followupinfo/CA010110001/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['calf_id'], 'CA010110001')
        self.assertEqual(response.data['cadob'], '2007-10-06')
        self.assertEqual(response.data['dead_alive_end_ideal'], 'Alive')


class PostmorteminfoViewSetTestCase(APITestCase):
    multi_db = True
    fixtures = ['test/postmorteminfo']

    @classmethod
    def setUpClass(cls):
        create_table_postmorteminfo()
        super(PostmorteminfoViewSetTestCase, cls).setUpClass()

    @classmethod
    def tearDownClass(cls):
        drop_table_postmorteminfo()
        super(PostmorteminfoViewSetTestCase, cls).tearDownClass()

    def test_list_postmorteminfo(self):
        """
        All Postmorteminfo entries should be listed.
        """
        response = self.client.get('/ideal/api/postmorteminfo/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['count'], 5)
        self.assertEqual(response.data['next'], None)

    def test_retrieve_postmorteminfo(self):
        """
        A Postmorteminfo Instance should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/postmorteminfo/VPC010002/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['calfid'], 'CA010110002')
        self.assertEqual(response.data['damid'], 'DM010120002')
        self.assertEqual(response.data['visitid'], 'VPC010002')


class SampleinfoViewSetTestCase(APITestCase):
    multi_db = True
    fixtures = ['test/sampleinfo']

    @classmethod
    def setUpClass(cls):
        create_table_sampleinfo()
        super(SampleinfoViewSetTestCase, cls).setUpClass()

    @classmethod
    def tearDownClass(cls):
        drop_table_sampleinfo()
        super(SampleinfoViewSetTestCase, cls).tearDownClass()

    def test_list_sampleinfo(self):
        """
        All Sampleinfo entries should be listed.
        """
        response = self.client.get('/ideal/api/sampleinfo/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['count'], 24)
        self.assertEqual(response.data['next'], None)

    def test_retrieve_sampleinfo(self):
        """
        A Sampleinfo Instance should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/sampleinfo/VCC010001/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 13)
        self.assertEqual(response.data[0]['visitid'], 'VCC010001')


class TestinfoViewSetTestCase(APITestCase):
    multi_db = True
    fixtures = ['test/testinfo']

    @classmethod
    def setUpClass(cls):
        create_table_testinfo()
        super(TestinfoViewSetTestCase, cls).setUpClass()

    @classmethod
    def tearDownClass(cls):
        drop_table_testinfo()
        super(TestinfoViewSetTestCase, cls).tearDownClass()

    def test_list_testinfo(self):
        """
        All Testinfo entries should be listed.
        """
        response = self.client.get('/ideal/api/testinfo/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['count'], 167)
        self.assertTrue(response.data['next'].endswith('?page=2'))

    def test_retrieve_testinfo(self):
        """
        A Testinfo Instance should be retrieved successfully.
        """
        response = self.client.get('/ideal/api/testinfo/VCC010001/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data), 76)
        self.assertEqual(response.data[0]['visit_id'], 'VCC010001')
