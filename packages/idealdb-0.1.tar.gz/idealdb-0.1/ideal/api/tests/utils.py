from django.db import connections


def create_table_calfinfo():
    connections['remote'].cursor().execute("""
        CREATE TABLE `web__calf_info` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `VisitID` varchar(50) NOT NULL COMMENT 'Unique Barcode for Each Visit',
            `DamID` varchar(50) DEFAULT NULL,
            `CalfID` varchar(50) DEFAULT NULL,
            `breed` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
            `local_name` varchar(50) DEFAULT NULL,
            `VisitDate` date DEFAULT NULL,
            `visit_type` varchar(60) DEFAULT NULL,
            `TypeLoss` varchar(60) DEFAULT NULL,
            `PATTERN` varchar(60) DEFAULT NULL,
            `HAIR` varchar(60) DEFAULT NULL,
            `body_colour_predominant` int(11) DEFAULT NULL,
            `body_colour_second` int(11) DEFAULT NULL,
            `body_colour_third` int(11) DEFAULT NULL,
            `body_colour_fourth` int(11) DEFAULT NULL,
            `body_colour_fifth` int(11) DEFAULT NULL,
            `head_colour_predominant` int(11) DEFAULT NULL,
            `head_colour_second` int(11) DEFAULT NULL,
            `head_colour_third` int(11) DEFAULT NULL,
            `head_colour_fourth` int(11) DEFAULT NULL,
            `ear_colour_predominant` int(11) DEFAULT NULL,
            `ear_colour_second` int(11) DEFAULT NULL,
            `ear_colour_third` int(11) DEFAULT NULL,
            `tail_colour_predominant` int(11) DEFAULT NULL,
            `tail_colour_second` int(11) DEFAULT NULL,
            `tail_colour_third` int(11) DEFAULT NULL,
            `hoof_colour_predominant` int(11) DEFAULT NULL,
            `hoof_colour_second` int(11) DEFAULT NULL,
            `hoof_colour_third` int(11) DEFAULT NULL,
            `muzzle_colour_predominant` int(11) DEFAULT NULL,
            `muzzle_colour_second` int(11) DEFAULT NULL,
            `dewlap_size` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
            `CADOB` date DEFAULT NULL,
            `CalfSex` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
            `LossFollow` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `ce` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `girth` decimal(4,1) DEFAULT NULL,
            `weight` decimal(4,1) DEFAULT NULL,
            `suckling` varchar(4) CHARACTER SET utf8 DEFAULT NULL,
            `rt` decimal(4,2) DEFAULT NULL,
            `famacha_l` int(11) DEFAULT NULL,
            `famacha_r` int(11) DEFAULT NULL,
            `elasticity` varchar(9) CHARACTER SET utf8 DEFAULT NULL,
            `f_consist` varchar(60) DEFAULT NULL,
            `diaorSeverity` varchar(50) DEFAULT NULL,
            `diaorKind` varchar(50) DEFAULT NULL,
            `diaorOdour` varchar(50) DEFAULT NULL,
            `HRSSCM` decimal(4,2) DEFAULT NULL,
            `HLSSCM` decimal(4,2) DEFAULT NULL,
            `HRPCCM` decimal(4,2) DEFAULT NULL,
            `HLPCCM` decimal(4,2) DEFAULT NULL,
            `RAPPEND` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
            `AMMBLY` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
            `BOOPH` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
            `HYALOMM` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
            `other_tick_louse` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
            `LICE` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
            `FLEAS` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
            `VTCalfYN` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `VTDamYN` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `VTHerdYN` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `Grazing` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `CYNB` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `DYNB` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `HYNB` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `CurrentNumberCattle` int(11) DEFAULT NULL,
            `TotalEntries` int(11) DEFAULT NULL,
            `TotalDeaths` int(11) DEFAULT NULL,
            `TotalExits` int(11) DEFAULT NULL,
            `AnimalCatDead` mediumtext CHARACTER SET utf8 DEFAULT NULL,
            `NumDeadAniCat` mediumtext CHARACTER SET utf8 DEFAULT NULL,
            `WhyDead` mediumtext DEFAULT NULL,
            `VetInter_Calf_CatTto` mediumtext DEFAULT NULL,
            `VetInter_Calf_TypeTto` mediumtext DEFAULT NULL,
            `VetInter_Calf_TypeApplic` mediumtext DEFAULT NULL,
            `VetInter_Calf_NHerdTto` mediumtext DEFAULT NULL,
            `VetInter_Dam_CatTto` mediumtext DEFAULT NULL,
            `VetInter_Dam_TypeTto` mediumtext DEFAULT NULL,
            `VetInter_Dam_TypeApplic` mediumtext DEFAULT NULL,
            `VetInter_Dam_NHerdTto` mediumtext DEFAULT NULL,
            `VetInter_Herd_CatTto` mediumtext DEFAULT NULL,
            `VetInter_Herd_TypeTto` mediumtext DEFAULT NULL,
            `VetInter_Herd_TypeApplic` mediumtext DEFAULT NULL,
            `VetInter_Herd_NHerdTto` mediumtext DEFAULT NULL,
            `HProbCat` mediumtext DEFAULT NULL,
            `HLesType` mediumtext DEFAULT NULL,
            `ObservedBy` mediumtext DEFAULT NULL,
            `DamAffected` mediumtext DEFAULT NULL,
            `PercentHerd` mediumtext CHARACTER SET utf8 DEFAULT NULL,
            `CalfDoneV` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
            `HAIR_TYP` varchar(60) DEFAULT NULL,
            `head_colour_fifth` int(11) DEFAULT NULL,
            `hump_size` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
            `hump_orientation` varchar(13) CHARACTER SET utf8 DEFAULT NULL,
            `hump_location` varchar(16) CHARACTER SET utf8 DEFAULT NULL,
            `face` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
            `back_profile` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
            `rump_profile` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
            `horn_presence` varchar(7) CHARACTER SET utf8 DEFAULT NULL,
            `horn_shape` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
            `horn_orientation` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
            `horn_spacing` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
            `horn_length` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
            `naval_flap_size` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
            `ear_size` varchar(5) CHARACTER SET utf8 DEFAULT NULL,
            `ear_shape` varchar(14) CHARACTER SET utf8 DEFAULT NULL,
            `ear_orientation` varchar(8) CHARACTER SET utf8 DEFAULT NULL,
            `tail_length` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
            `tail_thickness` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
            `udder_size` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
            `teats_size` varchar(11) CHARACTER SET utf8 DEFAULT NULL,
            `testis` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
            `perpuce` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
            `hwc` decimal(4,1) DEFAULT NULL,
            `sthc` decimal(4,1) DEFAULT NULL,
            `blc` decimal(4,1) DEFAULT NULL,
            `LastVisitWithData` varchar(50) DEFAULT NULL COMMENT 'Enter Last VRC visit with data (i.e. dismiss VRC visits where all fields in the questionnaire where recorded as ND due to animal not being available for visit or other)',
            `DateLastVisitWithdata` date DEFAULT NULL,
            `ReasonsLoss` varchar(60) DEFAULT NULL,
            `PostMortemDone` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `ReasonsPMNotDone` text DEFAULT NULL,
            `DeadAlive` varchar(22) CHARACTER SET utf8 DEFAULT NULL,
            `ce_ever` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=5642 DEFAULT CHARSET=latin1
    """)


def drop_table_calfinfo():
    connections['remote'].cursor().execute(
        "DROP TABLE IF EXISTS `web__calf_info`"
    )


def create_table_clinicalinfo():
    connections['remote'].cursor().execute("""
        CREATE TABLE `web__clinical_info` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `CalfID` varchar(50) DEFAULT NULL,
            `DamID` varchar(50) DEFAULT NULL,
            `VisitID` varchar(50) NOT NULL DEFAULT '',
            `BodyPart` varchar(60) DEFAULT NULL,
            `LesCat` varchar(60) DEFAULT NULL,
            `LesType` varchar(60) DEFAULT NULL,
            `Other` varchar(50) DEFAULT NULL,
            `Position` varchar(60) DEFAULT NULL,
            `Extension_pattern_lesion` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
            `Lesion_location_capsule` varchar(63) CHARACTER SET utf8 DEFAULT NULL,
            `CCS` varchar(60) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=361899 DEFAULT CHARSET=latin1
    """)


def drop_table_clinicalinfo():
    connections['remote'].cursor().execute(
        "DROP TABLE IF EXISTS `web__clinical_info`"
    )


def create_table_daminfo():
    connections['remote'].cursor().execute("""
        CREATE TABLE `web__dam_info` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `VisitID` varchar(50) DEFAULT NULL,
            `DamID` varchar(50) DEFAULT NULL,
            `CalfID` varchar(50) NOT NULL,
            `breed` varchar(20) DEFAULT NULL,
            `local_name` varchar(50) DEFAULT NULL,
            `VisitDate` date DEFAULT NULL,
            `visit_type` varchar(60) DEFAULT NULL,
            `TypeLoss` varchar(60) DEFAULT NULL,
            `PATTERN` varchar(60) DEFAULT NULL,
            `HAIR` varchar(60) DEFAULT NULL,
            `body_colour_predominant` int(11) DEFAULT NULL,
            `body_colour_second` int(11) DEFAULT NULL,
            `body_colour_third` int(11) DEFAULT NULL,
            `body_colour_fourth` int(11) DEFAULT NULL,
            `body_colour_fifth` int(11) DEFAULT NULL,
            `head_colour_predominant` int(11) DEFAULT NULL,
            `head_colour_second` int(11) DEFAULT NULL,
            `head_colour_third` int(11) DEFAULT NULL,
            `head_colour_fourth` int(11) DEFAULT NULL,
            `ear_colour_predominant` int(11) DEFAULT NULL,
            `ear_colour_second` int(11) DEFAULT NULL,
            `ear_colour_third` int(11) DEFAULT NULL,
            `tail_colour_predominant` int(11) DEFAULT NULL,
            `tail_colour_second` int(11) DEFAULT NULL,
            `tail_colour_third` int(11) DEFAULT NULL,
            `hoof_colour_predominant` int(11) DEFAULT NULL,
            `hoof_colour_second` int(11) DEFAULT NULL,
            `hoof_colour_third` int(11) DEFAULT NULL,
            `muzzle_colour_predominant` int(11) DEFAULT NULL,
            `muzzle_colour_second` int(11) DEFAULT NULL,
            `dewlap_size` varchar(60) DEFAULT NULL,
            `HUMP_F` int(10) DEFAULT NULL COMMENT 'Hump       -   Females',
            `HUMP_ORN` int(10) DEFAULT NULL COMMENT 'Hump       -  Orientation',
            `HUMP_LOC` int(10) DEFAULT NULL COMMENT 'Hump      -   Location',
            `FACE` int(10) DEFAULT NULL COMMENT 'Profile      - face',
            `BACK_PF` int(10) DEFAULT NULL COMMENT 'Profile      - back',
            `RUMP_PF` int(10) DEFAULT NULL COMMENT 'Profile      - rump',
            `HORN_F` int(10) DEFAULT NULL COMMENT 'Horns      -  Female',
            `HORN_SHAPE` int(10) DEFAULT NULL COMMENT 'Horns      - shape',
            `HORN_ORNT` int(10) DEFAULT NULL COMMENT 'Horns      - orientation',
            `SPAC_HRN` int(10) DEFAULT NULL COMMENT 'Horns      - spacing',
            `LNTH_HRN` int(10) DEFAULT NULL COMMENT 'Horns      - length',
            `NVL_SZ` int(10) DEFAULT NULL COMMENT 'Body        -  naval flap',
            `EAR_SZ` int(10) DEFAULT NULL COMMENT 'Ears      - size',
            `EAR_SHP` int(10) DEFAULT NULL COMMENT 'Ears      - shape',
            `EAR_ORNT` int(10) DEFAULT NULL COMMENT 'Ears      - orientation',
            `TAIL_LN` int(10) DEFAULT NULL COMMENT 'Tail - length',
            `TAIL_TH` int(10) DEFAULT NULL COMMENT 'Tail - Thickness at base',
            `UDD_SZ` int(10) DEFAULT NULL COMMENT 'Udder - size',
            `UDD_TEAT` int(10) DEFAULT NULL COMMENT 'Udder - teats',
            `hwd` decimal(4,1) DEFAULT NULL,
            `sthd` decimal(4,1) DEFAULT NULL,
            `bld` decimal(4,1) DEFAULT NULL,
            `LossFollow` varchar(50) DEFAULT NULL,
            `GirthDam` decimal(4,1) DEFAULT NULL,
            `SubjDam` varchar(50) DEFAULT NULL COMMENT 'subjective score of the dam''s health',
            `CSDam` decimal(5,2) DEFAULT NULL COMMENT 'Condition score of the dam',
            `UAreaDam` varchar(60) DEFAULT NULL,
            `LNUdderDam` varchar(60) DEFAULT NULL,
            `CMTLFQ` varchar(60) DEFAULT NULL,
            `CMTRFQ` varchar(60) DEFAULT NULL,
            `CMTLHQ` varchar(60) DEFAULT NULL,
            `CMTRHQ` varchar(60) DEFAULT NULL,
            `front_udder_lesion_dam` mediumtext DEFAULT NULL,
            `back_udder_lesion_dam` mediumtext DEFAULT NULL,
            `front_teat_lesion_dam` mediumtext DEFAULT NULL,
            `back_teat_lesion_dam` mediumtext DEFAULT NULL,
            `front_content_lesion_dam` mediumtext DEFAULT NULL,
            `back_content_lesion_dam` mediumtext DEFAULT NULL,
            `LesLNDam` varchar(60) DEFAULT NULL,
            `PoLeLNDam` varchar(60) DEFAULT NULL,
            `LesVADam` varchar(27) CHARACTER SET utf8 DEFAULT NULL,
            `LastVisitWithData` varchar(50) DEFAULT NULL,
            `DateLastVisitWithdata` date DEFAULT NULL,
            `ReasonsLoss` varchar(60) DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=5045 DEFAULT CHARSET=latin1
    """)


def drop_table_daminfo():
    connections['remote'].cursor().execute(
        "DROP TABLE IF EXISTS `web__dam_info`"
    )


def create_table_farminfo():
    connections['remote'].cursor().execute("""
        CREATE TABLE `web__farm_info` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `CalfID` varchar(50) NOT NULL,
            `FarmerID` varchar(50) DEFAULT NULL,
            `DamID` varchar(50) DEFAULT NULL,
            `calf_sex` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
            `CADOB` date DEFAULT NULL,
            `sublocation` varchar(60) DEFAULT NULL,
            `sublocation_id` int(10) DEFAULT NULL,
            `farmer_sex` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
            `farmer_age` int(10) DEFAULT NULL,
            `longitude` decimal(8,5) DEFAULT NULL,
            `latitude` decimal(7,5) DEFAULT NULL,
            `altitude` bigint(21) DEFAULT NULL,
            `education` varchar(60) DEFAULT NULL,
            `training` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `position` varchar(60) DEFAULT NULL,
            `occupation` varchar(12) CHARACTER SET utf8 DEFAULT NULL,
            `selling_point` varchar(60) DEFAULT NULL,
            `market` varchar(60) DEFAULT NULL,
            `cattle_kept_w_chicken` varchar(60) DEFAULT NULL,
            `dam_age` decimal(4,1) DEFAULT NULL,
            `calvings` decimal(4,1) DEFAULT NULL,
            `dam_born_in_household` int(11) DEFAULT NULL,
            `dam_time_at_farm` int(10) DEFAULT NULL,
            `bull_origin` varchar(60) DEFAULT NULL,
            `bull_type` varchar(60) DEFAULT NULL,
            `milked_prior_calving` int(11) DEFAULT NULL,
            `milked_prior_time` int(10) DEFAULT NULL,
            `milked_prior_frequency` varchar(60) DEFAULT NULL,
            `milked_post_calving` int(11) DEFAULT NULL,
            `milked_post_frequency` varchar(60) DEFAULT NULL,
            `milked_prior_colostrum` int(11) DEFAULT NULL,
            `calf_suckled` int(11) DEFAULT NULL,
            `calf_suckled_alternative` varchar(60) DEFAULT NULL,
            `navel_desinfection` int(11) DEFAULT NULL,
            `land_ownership` varchar(60) DEFAULT NULL,
            `total_acres_used` decimal(11,5) DEFAULT NULL COMMENT 'total number of acres used by farmer (owned / rented)',
            `total_acres_leased` decimal(11,5) DEFAULT NULL COMMENT 'total number of acres leased by farmer',
            `crops` int(11) DEFAULT NULL,
            `diseases` int(11) DEFAULT NULL,
            `housing_dry` varchar(60) DEFAULT NULL,
            `housing_wet` varchar(60) DEFAULT NULL,
            `housing_calves` int(10) DEFAULT NULL COMMENT 'Calves housed with adults',
            `roof_dry` int(10) DEFAULT NULL COMMENT 'If housing = yes: is there roof (dry)?',
            `roof_wet` int(10) DEFAULT NULL COMMENT 'If housing = yes: is there roof (wet)?',
            `wall_dry` int(10) DEFAULT NULL COMMENT 'If housing = yes: is there solid wall (dry)?',
            `wall_wet` int(10) DEFAULT NULL COMMENT 'If housing = yes: is there solid wall (wet)?',
            `floor_dry` varchar(60) DEFAULT NULL,
            `floor_wet` varchar(60) DEFAULT NULL,
            `nutritional_supplements` int(11) DEFAULT NULL,
            `vaccine` int(11) DEFAULT NULL,
            `veterinary_support` int(11) DEFAULT NULL,
            `watered_dry` varchar(60) DEFAULT NULL,
            `watered_wet` varchar(60) DEFAULT NULL,
            `water_distance_dry` varchar(60) DEFAULT NULL,
            `water_distance_wet` varchar(60) DEFAULT NULL,
            `water_frequency_dry` varchar(60) DEFAULT NULL,
            `water_frequency_wet` varchar(60) DEFAULT NULL,
            `water_quality_dry` varchar(60) DEFAULT NULL,
            `water_quality_wet` varchar(60) DEFAULT NULL,
            `grazed_with_adults` int(11) DEFAULT NULL,
            `number_of_cattle` bigint(20) unsigned DEFAULT NULL,
            `number_of_chicken` bigint(20) unsigned DEFAULT NULL,
            `number_of_dogs` bigint(20) unsigned DEFAULT NULL,
            `number_of_sheep` bigint(20) unsigned DEFAULT NULL,
            `number_of_goats` bigint(20) unsigned DEFAULT NULL,
            `number_of_pigs` bigint(20) unsigned DEFAULT NULL,
            `disease_cat` mediumtext DEFAULT NULL,
            `disease_type` mediumtext DEFAULT NULL,
            `treatment_cat` mediumtext DEFAULT NULL,
            `treatment_type` mediumtext DEFAULT NULL,
            `ectoparasites_method` mediumtext DEFAULT NULL,
            `ectoparasites_cat` mediumtext DEFAULT NULL,
            `ectoparasites_type` mediumtext DEFAULT NULL,
            `ectoparasites_freqdry` mediumtext DEFAULT NULL,
            `ectoparasites_freqwet` mediumtext DEFAULT NULL,
            `endoparasites_method` mediumtext DEFAULT NULL,
            `endoparasites_cat` mediumtext DEFAULT NULL,
            `endoparasites_type` mediumtext DEFAULT NULL,
            `endoparasites_freqdry` mediumtext DEFAULT NULL,
            `endoparasites_freqwet` mediumtext DEFAULT NULL,
            `trypanosoma_method` mediumtext DEFAULT NULL,
            `trypanosoma_cat` mediumtext DEFAULT NULL,
            `trypanosoma_type` mediumtext DEFAULT NULL,
            `trypanosoma_freqdry` mediumtext DEFAULT NULL,
            `trypanosoma_freqwet` mediumtext DEFAULT NULL,
            `vaccine_type` mediumtext DEFAULT NULL,
            `vaccine_freq` mediumtext DEFAULT NULL,
            `vet_assit` mediumtext DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=549 DEFAULT CHARSET=latin1
    """)


def drop_table_farminfo():
    connections['remote'].cursor().execute(
        "DROP TABLE IF EXISTS `web__farm_info`"
    )


def create_table_followupinfo():
    connections['remote'].cursor().execute("""
        CREATE TABLE `web__followup_info` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `calf_id` varchar(11) NOT NULL,
            `cadob` date NOT NULL,
            `calf_sex` varchar(1) NOT NULL,
            `dead_alive_end_ideal` varchar(50) NOT NULL,
            `status_1year` varchar(100) NOT NULL,
            `status_1year_comments` varchar(100) NOT NULL,
            `year_died` varchar(4) NOT NULL,
            `death_comments` varchar(255) NOT NULL,
            `offspring_status` varchar(25) NOT NULL,
            `num_calves` varchar(2) NOT NULL,
            `num_abortions` varchar(2) NOT NULL,
            `age_first_birth` varchar(2) NOT NULL,
            `age_first_birth_year` varchar(4) NOT NULL,
            `age_last_birth` varchar(2) NOT NULL,
            `age_last_birth_year` varchar(4) NOT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `calf_id` (`calf_id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=549 DEFAULT CHARSET=latin1
    """)


def drop_table_followupinfo():
    connections['remote'].cursor().execute(
        "DROP TABLE IF EXISTS `web__followup_info`"
    )


def create_table_postmorteminfo():
    connections['remote'].cursor().execute("""
        CREATE TABLE `web__postmortem_info` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `CalfID` varchar(50) DEFAULT NULL,
            `DamID` varchar(50) DEFAULT NULL,
            `VisitID` varchar(50) NOT NULL,
            `DeathDate` date DEFAULT NULL,
            `Euthanised` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `ImmediateCausePathology` varchar(50) DEFAULT NULL,
            `DefinitiveAetiologicalCause` varchar(50) DEFAULT NULL,
            `DefCausePathogen` varchar(50) DEFAULT NULL,
            `ContributingPathology1` varchar(50) DEFAULT NULL,
            `ContributingCause1` varchar(50) DEFAULT NULL,
            `ContCausePathogen1` varchar(50) DEFAULT NULL,
            `ContributingPathology2` varchar(50) DEFAULT NULL,
            `ContributingCause2` varchar(50) DEFAULT NULL,
            `ContCausePathogen2` varchar(50) DEFAULT NULL,
            `PMComments` text DEFAULT NULL,
            `PMReport` varchar(3) CHARACTER SET utf8 DEFAULT NULL,
            `HistopathReport` varchar(1000) DEFAULT NULL,
            `HistoAetiologicalDiagnosis` varchar(1000) DEFAULT NULL,
            `HistoComments` varchar(1000) DEFAULT NULL,
            `stomach_content` mediumtext DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=latin1
    """)


def drop_table_postmorteminfo():
    connections['remote'].cursor().execute(
        "DROP TABLE IF EXISTS `web__postmortem_info`"
    )


def create_table_sampleinfo():
    connections['remote'].cursor().execute("""
        CREATE TABLE `web__sample_info` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `CalfID` varchar(50) DEFAULT '',
            `DamID` varchar(50) DEFAULT '',
            `VisitID` varchar(50) NOT NULL DEFAULT '',
            `VisitDate` date DEFAULT NULL,
            `SampleID` varchar(50) DEFAULT '',
            `StoreLabel` varchar(50) DEFAULT '',
            `VisitType` varchar(3) NOT NULL DEFAULT '',
            `SampleType` varchar(3) DEFAULT '',
            `StoreType` varchar(3) DEFAULT '',
            `Tank` tinyint(3) unsigned DEFAULT NULL,
            `Sector` varchar(2) NOT NULL DEFAULT '',
            `BoxNum` varchar(12) NOT NULL DEFAULT '',
            `BoxPosition` tinyint(3) unsigned DEFAULT NULL,
            `SamplePos` tinyint(3) unsigned DEFAULT NULL,
            `Comments` varchar(255) NOT NULL DEFAULT '',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=60695 DEFAULT CHARSET=latin1
    """)


def drop_table_sampleinfo():
    connections['remote'].cursor().execute(
        "DROP TABLE IF EXISTS `web__sample_info`"
    )


def create_table_testinfo():
    connections['remote'].cursor().execute("""
        CREATE TABLE `web__test_info` (
            `id` int(11) NOT NULL AUTO_INCREMENT,
            `CalfID` varchar(50) DEFAULT NULL,
            `DamID` varchar(50) DEFAULT NULL,
            `VisitID` varchar(50) DEFAULT NULL,
            `VisitDate` date DEFAULT NULL COMMENT 'Date of visit',
            `ResultID` varchar(50) NOT NULL,
            `RSID` varchar(50) DEFAULT NULL,
            `SampleCode` varchar(50) DEFAULT NULL,
            `Test` varchar(150) DEFAULT NULL,
            `PossiblePathogen` varchar(74) DEFAULT NULL,
            `ResultStatus` varchar(29) CHARACTER SET utf8 DEFAULT NULL,
            `ResultNum` decimal(55,5) DEFAULT NULL,
            `LifeStage` varchar(24) CHARACTER SET utf8 DEFAULT NULL,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB AUTO_INCREMENT=504866 DEFAULT CHARSET=latin1 
    """)


def drop_table_testinfo():
    connections['remote'].cursor().execute(
        "DROP TABLE IF EXISTS `web__test_info`"
    )
