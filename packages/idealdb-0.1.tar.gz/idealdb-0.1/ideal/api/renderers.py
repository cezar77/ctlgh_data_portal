from rest_framework import renderers


class PedRenderer(renderers.BaseRenderer):
    media_type = 'text/plain'
    format = 'ped'

    def render(self, data, media_type=None, renderer_context=None):
        return data
