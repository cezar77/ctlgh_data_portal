import argparse
import csv

from django.core.management.base import BaseCommand

from ideal.api.models import Genotype


class Command(BaseCommand):
    help = 'Extracts pedigree information for each calf and updates database'

    def __init__(self, *args, **kwargs):
        super(Command, self).__init__(*args, **kwargs)
        self.id_mapping = []

    def add_arguments(self, parser):
        parser.add_argument(
            'ped_file',
            type=argparse.FileType('r'),
            help='Specify a .ped file',
        )
        parser.add_argument(
            'id_mapping',
            type=argparse.FileType('r'),
            help='Specify a .csv file',
        )

    def handle(self, *args, **options):
        ped_file = options['ped_file']
        self.id_mapping = list(csv.DictReader(options['id_mapping']))

        pedigrees = [{'sample_id': line.split()[1], 'ped_770k': line} for line in ped_file]

        genotypes = list(map(self.process_genotype, pedigrees))
        created = genotypes.count(True)
        updated = genotypes.count(False)

        self.stdout.write(
            self.style.SUCCESS(
                ('The pedigree entries for {} calves were created.'.format(created) +
                 ' The pedigree entries for {} calves were updated.'.format(updated))
            )
        )

    def process_genotype(self, ped):
        calf_id = next(
            item['CalfID'] for item in self.id_mapping if item['SampleID'] == ped['sample_id']
        )
        defaults = {'calf_id': calf_id, 'ped_770k': ped['ped_770k']}
        genotype = Genotype.objects.update_or_create(calf_id=calf_id, defaults=defaults)
        return genotype[1]
