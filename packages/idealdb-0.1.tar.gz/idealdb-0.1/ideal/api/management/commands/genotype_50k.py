import argparse

from django.core.management.base import BaseCommand

from ideal.api.models import Genotype
from ideal.models import Calfinfo


class Command(BaseCommand):
    help = 'Extracts pedigree information for each calf and updates database'

    def __init__(self, *args, **kwargs):
        super(Command, self).__init__(*args, **kwargs)
        self.calves = Calfinfo.objects.values_list('calf_id', flat=True).distinct()

    def add_arguments(self, parser):
        parser.add_argument(
            'ped_file',
            type=argparse.FileType('r'),
            help='Specify a .ped file',
        )

    def handle(self, *args, **options):
        ped_file = options['ped_file']

        pedigrees = [{'calf_id': line.split()[1], 'ped_50k': line} for line in ped_file]

        genotypes = list(map(self.process_genotype, pedigrees))
        created = genotypes.count(True)
        updated = genotypes.count(False)

        self.stdout.write(
            self.style.SUCCESS(
                ('The pedigree entries for {} calves were created.'.format(created) +
                 ' The pedigree entries for {} calves were updated.'.format(updated))
            )
        )

    def process_genotype(self, ped):
        calf_id = ped.get('calf_id')
        if calf_id in self.calves:
            genotype = Genotype.objects.update_or_create(calf_id=calf_id, defaults=ped)
            return genotype[1]
        return None
