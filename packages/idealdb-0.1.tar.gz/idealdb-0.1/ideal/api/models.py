from django.db import models


class Genotype(models.Model):
    """
    Contains all the 50K and 770K Genotyping information.

    Detailed information on **50K Genotyping** and the
    **Illumina BovineSNP50 v3 BeadChip** can be accessed at:
    https://www.illumina.com/products/by-type/microarray-kits/bovine-snp50.html

    Detailed information on **770K Genotyping** and the
    **Illumina BovineHD Genotyping BeadChip** can be accessed at:
    https://www.illumina.com/products/by-type/microarray-kits/bovinehd.html

    """
    calf_id = models.CharField(
        unique=True,
        max_length=11
    )
    ped_50k = models.TextField(
        blank=True
    )
    ped_770k = models.TextField(
        blank=True
    )

    class Meta:
        db_table = 'web__genotype'

    def __str__(self):
        return 'Pedigree data for {}'.format(self.calf_id)
