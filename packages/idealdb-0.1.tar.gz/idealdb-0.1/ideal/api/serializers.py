from rest_framework.reverse import reverse
from rest_framework import serializers

from ideal.models import (
    Calfinfo,
    Clinicalinfo,
    Daminfo,
    Farminfo,
    Followupinfo,
    Postmorteminfo,
    Sampleinfo,
    Testinfo,
)
from ideal.tables import CalfinfoTable, DaminfoTable


class CalfinfoSerializer(serializers.HyperlinkedModelSerializer):
    daminfo_url = serializers.SerializerMethodField()
    ped_50k = serializers.SerializerMethodField()
    ped_770k = serializers.SerializerMethodField()

    class Meta:
        model = Calfinfo
        extra_kwargs = {
            'url': {
                'view_name': 'api:calfinfo-detail',
                'lookup_field': 'calf_id',
            },
        }

    def get_daminfo_url(self, obj):
        return reverse(
            'api:daminfo-detail',
            kwargs={'dam_id': obj.dam_id},
            request=self.context['request']
        )

    def get_ped_50k(self, obj):
        return reverse(
            'api:calfinfo-pedigree-50k',
            kwargs={'calf_id': obj.calf_id},
            request=self.context['request']
        )

    def get_ped_770k(self, obj):
        return reverse(
            'api:calfinfo-pedigree-770k',
            kwargs={'calf_id': obj.calf_id},
            request=self.context['request']
        )

    def get_field_names(self, declared_fields, info):
        fields = super().get_default_field_names(declared_fields, info)
        hex_colours = (
            'body_colours_hex',
            'head_colours_hex',
            'ear_colours_hex',
            'tail_colours_hex',
            'hoof_colours_hex',
            'muzzle_colours_hex'
        )
        number_colours = CalfinfoTable.Meta.exclude[1:]
        fields.extend(hex_colours)
        for field in number_colours:
            fields.remove(field)
        return fields


class ClinicalinfoSerializer(serializers.HyperlinkedModelSerializer):
    calfinfo_url = serializers.SerializerMethodField()

    class Meta:
        model = Clinicalinfo
        fields = '__all__'
        extra_kwargs = {
            'url': {
                'view_name': 'api:clinicalinfo-detail',
                'lookup_field': 'visitid'
            },
        }

    def get_calfinfo_url(self, obj):
        return reverse(
            'api:calfinfo-detail',
            kwargs={'calf_id': obj.calfid},
            request=self.context['request']
        )


class DaminfoSerializer(serializers.HyperlinkedModelSerializer):
    calfinfo_url = serializers.SerializerMethodField()

    class Meta:
        model = Daminfo
        fields = '__all__'
        extra_kwargs = {
            'url': {
                'view_name': 'api:daminfo-detail',
                'lookup_field': 'dam_id',
            },
        }

    def get_calfinfo_url(self, obj):
        return reverse(
            'api:calfinfo-detail',
            kwargs={'calf_id': obj.calf_id},
            request=self.context['request']
        )

    def get_field_names(self, declared_fields, info):
        fields = super().get_default_field_names(declared_fields, info)
        hex_colours = (
            'body_colours_hex',
            'head_colours_hex',
            'ear_colours_hex',
            'tail_colours_hex',
            'hoof_colours_hex',
            'muzzle_colours_hex'
        )
        number_colours = DaminfoTable.Meta.exclude[1:]
        fields.extend(hex_colours)
        for field in number_colours:
            fields.remove(field)
        return fields


class FarminfoSerializer(serializers.HyperlinkedModelSerializer):
    calfinfo_url = serializers.SerializerMethodField()
    daminfo_url = serializers.SerializerMethodField()

    class Meta:
        model = Farminfo
        fields = '__all__'
        extra_kwargs = {
            'url': {
                'view_name': 'api:farminfo-detail',
                'lookup_field': 'farmer_id',
            },
        }

    def get_calfinfo_url(self, obj):
        return reverse(
            'api:calfinfo-detail',
            kwargs={'calf_id': obj.calf_id},
            request=self.context['request']
        )

    def get_daminfo_url(self, obj):
        return reverse(
            'api:daminfo-detail',
            kwargs={'dam_id': obj.dam_id},
            request=self.context['request']
        )


class FollowupinfoSerializer(serializers.HyperlinkedModelSerializer):
    calfinfo_url = serializers.SerializerMethodField()

    class Meta:
        model = Followupinfo
        fields = '__all__'
        extra_kwargs = {
            'url': {
                'view_name': 'api:followupinfo-detail',
                'lookup_field': 'calf_id',
            },
        }

    def get_calfinfo_url(self, obj):
        return reverse(
            'api:calfinfo-detail',
            kwargs={'calf_id': obj.calf_id},
            request=self.context['request']
        )


class PostmorteminfoSerializer(serializers.HyperlinkedModelSerializer):
    calfinfo_url = serializers.SerializerMethodField()

    class Meta:
        model = Postmorteminfo
        fields = '__all__'
        extra_kwargs = {
            'url': {
                'view_name': 'api:postmorteminfo-detail',
                'lookup_field': 'visitid',
            },
        }

    def get_calfinfo_url(self, obj):
        return reverse(
            'api:calfinfo-detail',
            kwargs={'calf_id': obj.calfid},
            request=self.context['request']
        )


class SampleinfoSerializer(serializers.HyperlinkedModelSerializer):
    calfinfo_url = serializers.SerializerMethodField()
    daminfo_url = serializers.SerializerMethodField()

    class Meta:
        model = Sampleinfo
        fields = '__all__'
        extra_kwargs = {
            'url': {
                'view_name': 'api:sampleinfo-detail',
                'lookup_field': 'visitid',
            },
        }

    def get_calfinfo_url(self, obj):
        return reverse(
            'api:calfinfo-detail',
            kwargs={'calf_id': obj.calfid},
            request=self.context['request']
        )

    def get_daminfo_url(self, obj):
        return reverse(
            'api:daminfo-detail',
            kwargs={'dam_id': obj.damid},
            request=self.context['request']
        )


class TestinfoSerializer(serializers.HyperlinkedModelSerializer):
    calfinfo_url = serializers.SerializerMethodField()
    daminfo_url = serializers.SerializerMethodField()

    class Meta:
        model = Testinfo
        fields = '__all__'
        extra_kwargs = {
            'url': {
                'view_name': 'api:testinfo-detail',
                'lookup_field': 'visit_id'
            },
        }

    def get_calfinfo_url(self, obj):
        return reverse(
            'api:calfinfo-detail',
            kwargs={'calf_id': obj.calf_id},
            request=self.context['request']
        )

    def get_daminfo_url(self, obj):
        return reverse(
            'api:daminfo-detail',
            kwargs={'dam_id': obj.dam_id},
            request=self.context['request']
        )
