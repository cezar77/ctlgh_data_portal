from rest_framework import serializers

from ideal.models import (
    Calfinfo,
    Clinicalinfo,
    Daminfo,
    Farminfo,
    Followupinfo,
    Postmorteminfo,
    Sampleinfo,
    Testinfo,
)


class CalfInfoSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Calfinfo
        fields = '__all__'


class ClinicalInfoSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Clinicalinfo
        fields = '__all__'


class DamInfoSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Daminfo
        fields = '__all__'


class FarmInfoSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Farminfo
        fields = '__all__'


class FollowUpInfoSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Followupinfo
        fields = '__all__'


class PostmortemInfoSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Postmorteminfo
        fields = '__all__'


class SampleInfoSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Sampleinfo
        fields = '__all__'


class TestInfoSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Testinfo
        fields = '__all__'
