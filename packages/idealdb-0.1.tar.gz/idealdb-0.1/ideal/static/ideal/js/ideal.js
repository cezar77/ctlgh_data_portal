(function () {
  var toc = $("#toc").tocify().data("toc-tocify");
  if (toc) {
    toc.setOption("showEffect", "fadeIn");
  }
})();

$(document).ready(function() {
  $('.form-group').each(function() {
    $(this).addClass('col-xs-12 col-sm-6 col-md-4 col-lg-4');
  });
  // activate jQuery UI tooltips
  $(document).tooltip();
  // activate jQuery UI datepicker
  $('.datepicker').datepicker({
    changeMonth: true,
    changeYear: true,
    minDate: new Date(2007, 0, 1)
  });
  // activate tab panels
  $('#tabs > ul.nav > li[role="presentation"] > a').click(function (e) {
    e.preventDefault();
    $(this).tab('show');
  });
  // clone the form for hiding column groups
  $('#columns')
    .clone(true, true)
    .css('display', 'block')
    .attr('id', 'columns_1')
    .prependTo('#column-hiding')
  ;
  // replace the ids in the clone
  $('#columns_1').find('button').each(function() {
    if ($(this).attr('id')) {
      $(this).attr('id', $(this).attr('id') + '_1');
    }
  });
  $('#columns_1').find('li').each(function() {
    var label_for, input_id;
    if ($(this).find('label').attr('for')) {
      label_for = $(this).find('label').attr('for');
      $(this).find('label').attr('for', label_for + '_1');
      input_id = $(this).find('input').attr('id');
      $(this).find('input').attr('id', input_id + '_1');
    }
  });
  // propagate the checkbox values of the clone to the origin
  $('#column-hiding input[type=checkbox]').click(function() {
    var id = $(this).attr('id');
    var prop;
    prop = $(this).is(':checked');
    $('#columns').find('#'+ id.slice(0, -2)).prop('checked', prop);
  });
});
// dynamic form for Testinfo
// populate the select options for result based on the chosen test
$(document).ready(function() {
  var options = $('#id_possiblepathogen option');
  $('#id_test').on('change', function(e) {
    var items, values = [], selectedValues = $(this).val() || [];
    $('#id_possiblepathogen option').remove();
    if (selectedValues.length) {
      $.get('/pathogenlist/?q=' + selectedValues.join(), function(data) {
        items = JSON.parse(data);
        items.forEach(function(element) {
          if (!values.includes(element.fields.pathogen)) {
            values.push(element.fields.pathogen);
          }
        });
        values.forEach(function(element) {
          $('#id_possiblepathogen').append('<option value="' + element + '">' + element + '</option>');
        });
      });
    } else {
      $('#id_possiblepathogen').append(options);
    }
  });
});
// dynamic form for ClinicalInfo
// populate the select options for lesion type based on the chosen lesion category
$(document).ready(function() {
  var options = $('#id_lestype option');
  $('#id_lescat').on('change', function(e) {
    var items, values = [], selectedValues = $(this).val() || [];
    $('#id_lestype option').remove();
    if (selectedValues.length) {
      $.get('/lesiontypelist/?q=' + selectedValues.join(), function(data) {
        items = JSON.parse(data);
        items.forEach(function(element) {
          if (!values.includes(element.fields.lesion_type)) {
            values.push(element.fields.lesion_type)
          }
        });
        values.forEach(function(element) {
          $('#id_lestype').append('<option value="' + element + '">' + element + '</option>');
        });
      });
    } else {
      $('#id_lestype').append(options);
    }
  });
});
