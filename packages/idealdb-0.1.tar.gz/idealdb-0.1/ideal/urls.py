from django.conf.urls import url
from django.views.generic.base import TemplateView

from . import views

urlpatterns = [
    url(r'^$', views.HomepageView.as_view(), name='homepage'),
    url(
        r'^documentation/about/$',
        TemplateView.as_view(template_name='ideal/documentation/about.html'),
        name='documentation-about'
    ),
    url(
        r'^documentation/description/$',
        TemplateView.as_view(template_name='ideal/documentation/description.html'),
        name='documentation-description'
    ),
    url(
        r'^documentation/citation/$',
        TemplateView.as_view(template_name='ideal/documentation/citation.html'),
        name='documentation-citation'
    ),
    url(
        r'^documentation/genetics/$',
        TemplateView.as_view(template_name='ideal/documentation/genetics.html'),
        name='documentation-genetics'
    ),
    #url(
    #    r'^documentation/farminfo/$',
    #    TemplateView.as_view(template_name='ideal/documentation/farminfo.html'),
    #    name='documentation-farminfo'
    #),
    #url(
    #    r'^documentation/daminfo/$',
    #    TemplateView.as_view(template_name='ideal/documentation/daminfo.html'),
    #    name='documentation-daminfo'
    #),
    #url(
    #    r'^documentation/calfinfo/$',
    #    TemplateView.as_view(template_name='ideal/documentation/calfinfo.html'),
    #    name='documentation-calfinfo'
    #),
    #url(
    #    r'^documentation/testinfo/$',
    #    TemplateView.as_view(template_name='ideal/documentation/testinfo.html'),
    #    name='documentation-testinfo'
    #),
    #url(
    #    r'^documentation/clinicalinfo/$',
    #    TemplateView.as_view(template_name='ideal/documentation/clinicalinfo.html'),
    #    name='documentation-clinicalinfo'
    #),
    #url(
    #    r'^documentation/postmorteminfo/$',
    #    TemplateView.as_view(template_name='ideal/documentation/postmorteminfo.html'),
    #    name='documentation-postmorteminfo'
    #),
    #url(
    #    r'^documentation/sampleinfo/$',
    #    TemplateView.as_view(template_name='ideal/documentation/sampleinfo.html'),
    #    name='documentation-sampleinfo'
    #),
    url(r'^documentation/(?P<table>[a-z]+)/$', views.DocumentationView.as_view(), name='documentation'),
    url(r'^farminfo/$', views.FarminfoList.as_view(), name='farminfo-list'),
    url(r'^daminfo/$', views.DaminfoList.as_view(), name='daminfo-list'),
    url(r'^calfinfo/$', views.CalfinfoList.as_view(), name='calfinfo-list'),
    url(r'^testinfo/$', views.TestinfoList.as_view(), name='testinfo-list'),
    url(
        r'^clinicalinfo/$',
        views.ClinicalinfoList.as_view(),
        name='clinicalinfo-list'
    ),
    url(
        r'^postmorteminfo/$',
        views.PostmorteminfoList.as_view(),
        name='postmorteminfo-list'
    ),
    url(
        r'^sampleinfo/$',
        views.SampleinfoList.as_view(),
        name='sampleinfo-list'
    ),
]
