from django.apps import apps
from django.views.generic.base import TemplateView
from django.views.generic.edit import FormView
from django.views.generic.detail import DetailView
from django.views.generic.list import ListView
from django.http import Http404
from django.views.decorators.cache import cache_page
from django.utils.decorators import method_decorator

from django_filters.views import FilterView
from django_tables2.views import SingleTableView
from django_tables2.export.views import ExportMixin

from .models import (
    Farminfo,
    Daminfo,
    Calfinfo,
    Testinfo,
    Clinicalinfo,
    Postmorteminfo,
    Sampleinfo,
)
from .tables import (
    FarminfoTable,
    DaminfoTable,
    CalfinfoTable,
    TestinfoTable,
    ClinicalinfoTable,
    PostmorteminfoTable,
    SampleinfoTable
)
from .filters import (
    FarminfoFilter,
    DaminfoFilter,
    CalfinfoFilter,
    TestinfoFilter,
    ClinicalinfoFilter,
    PostmorteminfoFilter,
    SampleinfoFilter
)
from .forms import (
    FarminfoHideColumnsForm,
    DaminfoHideColumnsForm,
    CalfinfoHideColumnsForm,
    TestinfoHideColumnsForm,
    ClinicalinfoHideColumnsForm,
    PostmorteminfoHideColumnsForm,
    SampleinfoHideColumnsForm
)


class HomepageView(TemplateView):
    template_name = 'ideal/index.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        views = apps.all_models['ideal']
        context['views'] = [(k, v.__name__, v.__doc__) for k, v in views.items()]
        return context


class DocumentationView(TemplateView):
    template_name = 'ideal/documentation.html'
    
    def get_template_names(self):
        table = self.get_table_name()
        template_name = 'ideal/documentation/{}.html'.format(table)
        return [template_name]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        table = self.get_table_name()
        model = apps.get_model('ideal', table)
        table_class = eval('{}Table'.format(model.__name__))
        context['table'] = list(table_class.base_columns.values())
        return context
        
    def get_table_name(self):
        table = self.kwargs['table']
        try:
          model = apps.get_model('ideal', table)
          return table
        except LookupError:
          raise Http404


@method_decorator(cache_page(30 * 24 * 60 * 60), name='dispatch')
class IdealView(ExportMixin, FilterView, SingleTableView, FormView):
    template_name = 'ideal/table.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        form = context['form'] = self.form_class(self.request.GET)
        table = context['table']
        for field in form.fields:
            if self.request.GET.get(field, None):
                columns = table.column_groups.get(field).get('columns')
                table.exclude += columns
                self.exclude_columns += columns
        context['table'] = table
        return context


class FarminfoList(IdealView):
    model = Farminfo
    table_class = FarminfoTable
    filterset_class = FarminfoFilter
    success_url = '.'
    form_class = FarminfoHideColumnsForm
    export_name = 'ideal_farm'
    exclude_columns = ('sublocation_id', 'longitude', 'latitude', 'altitude')


class DaminfoList(IdealView):
    model = Daminfo
    table_class = DaminfoTable
    filterset_class = DaminfoFilter
    success_url = '.'
    form_class = DaminfoHideColumnsForm
    export_name = 'ideal_dam'
    #exclude_columns = (
    #    'body_colours', 'head_colours', 'ear_colours', 'tail_colours',
    #    'hoof_colours', 'muzzle_colours'
    #)

    
class CalfinfoList(IdealView):
    model = Calfinfo
    table_class = CalfinfoTable
    filterset_class = CalfinfoFilter
    success_url = '.'
    form_class = CalfinfoHideColumnsForm
    export_name = 'ideal_calf'
    exclude_columns = ()


class TestinfoList(IdealView):
    model = Testinfo
    table_class = TestinfoTable
    filterset_class = TestinfoFilter
    success_url = '.'
    form_class = TestinfoHideColumnsForm
    export_name = 'ideal'


class ClinicalinfoList(IdealView):
    model = Clinicalinfo
    table_class = ClinicalinfoTable
    filterset_class = ClinicalinfoFilter
    success_url = '.'
    form_class = ClinicalinfoHideColumnsForm
    export_name = 'ideal_clinical'
    exclude_columns = ()


class PostmorteminfoList(IdealView):
    model = Postmorteminfo
    table_class = PostmorteminfoTable
    filterset_class = PostmorteminfoFilter
    success_url = '.'
    form_class = PostmorteminfoHideColumnsForm
    export_name = 'ideal_postmortem'
    exclude_columns = ('pm_report',)

    
class SampleinfoList(IdealView):
    model = Sampleinfo
    table_class = SampleinfoTable
    filterset_class = SampleinfoFilter
    success_url = '.'
    form_class = SampleinfoHideColumnsForm
    export_name = 'ideal_sample'
    exclude_columns = ('rowid',)
