from django.apps import AppConfig


class IdealConfig(AppConfig):
    name = 'ideal'
