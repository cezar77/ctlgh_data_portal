from django.apps import AppConfig


class IdealConfig(AppConfig):
    name = 'ideal'
    label = 'ideal'
    verbose_name = 'IDEAL'
