from collections import OrderedDict

import django_tables2 as tables

from .idealtable import IdealTable
from ..models import Followupinfo


class FollowupinfoTable(IdealTable):
    calf_id = tables.LinkColumn(
        verbose_name='CalfID',
        viewname='calfinfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the calf'
            }
        }
    )
    cadob = tables.Column(
        verbose_name='Calf date of birth',
        orderable=True,
        attrs={
            'th': {
                'title': 'Date of birth of the calf'
            }
        }
    )
    calf_sex = tables.Column(
        verbose_name='Calf sex',
        orderable=True,
        attrs={
            'th': {
                'title': 'Sex of the calf'
            }
        }
    )
    dead_alive_end_ideal = tables.Column(
        verbose_name='Status at end of IDEAL',
        orderable=True,
        attrs={
            'th': {
                'title': 'Status of the calf at 51 weeks of enrolment in the IDEAL study'
            }
        }
    )
    status_1year = tables.Column(
        verbose_name='Status 1 year',
        orderable=True,
        attrs={
            'th': {
                'title': 'Status of the animal at the time of the follow-up questionnaire'
            }
        }
    )
    status_1year_comments = tables.Column(
        verbose_name='Status 1 year comments',
        orderable=True,
        attrs={
            'th': {
                'title': 'Comments on the status of the animal at the time of the follow-up questionnaire'
            }
        }
    )
    year_died = tables.Column(
        verbose_name='Year died',
        orderable=True,
        attrs={
            'th': {
                'title': 'Year the animal died'
            }
        }
    )
    death_comments = tables.Column(
        verbose_name='Death comments',
        orderable=True,
        attrs={
            'th': {
                'title': 'Comments on the cause of death if the calf died after 51 weeks of age'
            }
        }
    )
    offspring_status = tables.Column(
        verbose_name='Offspring status',
        orderable=True,
        attrs={
            'th': {
                'title': 'Whether or not the IDEAL calf had any offspring'
            }
        }
    )
    num_calves = tables.Column(
        verbose_name='Number of calves',
        orderable=True,
        attrs={
            'th': {
                'title': 'Number of calves the IDEAL animal has had'
            }
        }
    )
    num_abortions = tables.Column(
        verbose_name='Number of abortions',
        orderable=True,
        attrs={
            'th': {
                'title': 'Number of abortions the IDEAL animal has experienced'
            }
        }
    )
    age_first_birth = tables.Column(
        verbose_name='Age first gave birth',
        orderable=True,
        attrs={
            'th': {
                'title': 'Age the IDEAL animal first gave birth at'
            }
        }
    )
    age_first_birth_year = tables.Column(
        verbose_name='Year first gave birth',
        orderable=True,
        attrs={
            'th': {
                'title': 'Year in which the IDEAL animal first gave birth'
            }
        }
    )
    age_last_birth = tables.Column(
        verbose_name='Age last gave birth',
        orderable=True,
        attrs={
            'th': {
                'title': 'Age the IDEAL animal last gave birth at'
            }
        }
    )
    age_last_birth_year = tables.Column(
        verbose_name='Year last gave birth',
        orderable=True,
        attrs={
            'th': {
                'title': 'Year in which the IDEAL animal last gave birth'
            }
        }
    )
    column_groups = OrderedDict([
        ('hide_status',  OrderedDict([
            ('columns', ('dead_alive_end_ideal', 'status_1year', 'status_1year_comments', 'year_died',
                'death_comments')),
            ('attrs', {'style': 'background-color:#b3e2cd;'}),
        ])),
        ('hide_offspring', OrderedDict([
            ('columns', ('offspring_status', 'num_calves', 'num_abortions', 'age_first_birth', 'age_first_birth_year', 'age_last_birth', 'age_last_birth_year')),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ]))
    ])

    class Meta:
        model = Followupinfo
        exclude = ('id',)
