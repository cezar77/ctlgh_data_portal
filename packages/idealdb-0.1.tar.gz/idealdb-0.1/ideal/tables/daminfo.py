from collections import OrderedDict

from django.utils.html import format_html

import django_tables2 as tables

from ..models import Daminfo
from .. import constants
from .idealtable import AnimalTable


class DaminfoTable(AnimalTable):
    calf_id = tables.LinkColumn(
        verbose_name='CalfID',
        viewname='farminfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the calf'
            }
        }
    )
    dam_id = tables.LinkColumn(
        verbose_name='DamID',
        viewname='farminfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the dam'
            }
        }
    )
    visitid = tables.Column(
        verbose_name='VisitID',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the visit'
            }
        }
    )
    breed = tables.Column(
        verbose_name='Breed',
        orderable=False,
        attrs={
            'th': {
                'title': 'Common name of breed'
            }
        }
    )
    local_name = tables.Column(
        verbose_name='Local name',
        orderable=False,
        attrs={
            'th': {
                'title': 'Local name of breed'
            }
        }
    )
    pattern = tables.Column(
        verbose_name='Coat pattern',
        orderable=False,
        attrs={
            'th': {
                'title': ('Description of coat pattern (i.e. pied, uniform, '
                          'etc.)')
            }
        }
    )
    hair = tables.Column(
        verbose_name='Coat hair length',
        orderable=False,
        attrs={
            'th': {
                'title': 'Description of coat hair length'
            }
        }
    )   
    dewlap_size = tables.Column(
        verbose_name='Dewlap size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Dewlap size'
            }
        }
    )   
    hump_f = tables.Column(
        verbose_name='Hump size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Hump size (i.e. absent, small, medium, etc.)'
            }
        }
    )
    hump_orn = tables.Column(
        verbose_name='Hump orientation',
        orderable=False,
        attrs={
            'th': {
                'title': 'Hump orientation. Only applicable if hump is present'
            }
        }
    )
    hump_loc = tables.Column(
        verbose_name='Hump location',
        orderable=False,
        attrs={
            'th': {
                'title': 'Hump location. Only applicable if hump is present'
            }
        }
    )
    face = tables.Column(
        verbose_name='Face profile',
        orderable=False,
        attrs={
            'th': {
                'title': 'Profile of face'
            }
        }
    )
    back_pf = tables.Column(
        verbose_name='Back profile',
        orderable=False,
        attrs={
            'th': {
                'title': 'Profile of back'
            }
        }
    )
    rump_pf = tables.Column(
        verbose_name='Rump profile',
        orderable=False,
        attrs={
            'th': {
                'title': 'Profile of rump'
            }
        }
    )
    horn_f = tables.Column(
        verbose_name='Horn presence',
        orderable=False,
        attrs={
            'th': {
                'title': 'Whether horns are present'
            }
        }
    )
    horn_shape = tables.Column(
        verbose_name='Horn shape',
        orderable=False,
        attrs={
            'th': {
                'title': 'Horn shape. Only applicable if horns are present'
            }
        }
    )
    horn_ornt = tables.Column(
        verbose_name='Horns orientation',
        orderable=False,
        attrs={
            'th': {
                'title': ('Horns orientation. Only applicable if horns are '
                          'present')
            }
        }
    )
    spac_hrn = tables.Column(
        verbose_name='Horn spacing',
        orderable=False,
        attrs={
            'th': {
                'title': 'Horns spacing. Only applicable if horns are present'
            }
        }
    )
    lnth_hrn = tables.Column(
        verbose_name='Horns length',
        orderable=False,
        attrs={
            'th': {
                'title': 'Horn length. Only applicable if horns are present'
            }
        }
    )
    nvl_sz = tables.Column(
        verbose_name='Naval flap size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Naval flap size (i.e. absent, small, medium, etc.)'
            }
        }
    )
    ear_sz = tables.Column(
        verbose_name='Ear size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Ear size'
            }
        }
    )
    ear_shp = tables.Column(
        verbose_name='Ear shape',
        orderable=False,
        attrs={
            'th': {
                'title': 'Ear shape'
            }
        }
    )
    ear_ornt = tables.Column(
        verbose_name='Ear orientation',
        orderable=False,
        attrs={
            'th': {
                'title': 'Ears orientation'
            }
        }
    )
    tail_ln = tables.Column(
        verbose_name='Tail length',
        orderable=False,
        attrs={
            'th': {
                'title': 'Tail length'
            }
        }
    )
    tail_th = tables.Column(
        verbose_name='Tail thickness at base',
        orderable=False,
        attrs={
            'th': {
                'title': 'Tail thickness at base'
            }
        }
    )
    udd_sz = tables.Column(
        verbose_name='Udder size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Udder size'
            }
        }
    )
    udd_teat = tables.Column(
        verbose_name='Teats size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Teats size'
            }
        }
    )
    hwd = tables.Column(
        verbose_name='Height at withers',
        orderable=False,
        attrs={
            'th': {
                'title': 'Height at withers (cm)'
            }
        }
    )
    sthd = tables.Column(
        verbose_name='Body length from shoulder joint to hip joint',
        orderable=False,
        attrs={
            'th': {
                'title': 'Body length from shoulder joint to hip joint (cm)'
            }
        }
    )
    bld = tables.Column(
        verbose_name='Total body length',
        orderable=False,
        attrs={
            'th': {
                'title': ('Total body length - from muzzle to tail base - '
                          'while keeping neck in extension (cm)')
            }
        }
    )
    visitdate = tables.Column(
        verbose_name='Visit date',
        orderable=True,
        attrs={
            'th': {
                'title': 'Date of visit'
            }
        }
    )
    visit_type = tables.Column(
        verbose_name='Visit type',
        orderable=False,
        attrs={
            'th': {
                'title': 'Type of visit'
            }
        }
    )
    lossfollow = tables.Column(
        verbose_name='Dam available',
        orderable=False,
        attrs={
            'th': {
                'title': 'Whether the dam is available for visit'
            }
        }
    )
    typeloss = tables.Column(
        verbose_name='Reason why dam is unavailable',
        orderable=False,
        attrs={
            'th': {
                'title': 'Reason why the dam is not available for visit'
            }
        }
    )
    girthdam = tables.Column(
        verbose_name='Girth dam',
        orderable=False,
        attrs={
            'th': {
                'title': 'Girth measurement of dam (cm)'
            }
        }
    )
    subjdam = tables.Column(
        verbose_name='Subjective assessment dam',
        orderable=False,
        attrs={
            'th': {
                'title': 'Subjective assessment of dams health'
            }
        }
    )
    csdam = tables.Column(
        verbose_name='Condition score dam',
        orderable=False,
        attrs={
            'th': {
                'title': 'Condition score for the dam'
            }
        }
    )
    uareadam = tables.Column(
        verbose_name='Udder area disorder',
        orderable=False,
        attrs={
            'th': {
                'title': ('Captures whether the udder area (i.e. ventral '
                          'surface surrounding the udder) appears normal at '
                          'the time of the examination')
            }
        }
    )
    lnudderdam = tables.Column(
        verbose_name='Udder lymph node disorder',
        orderable=False,
        attrs={
            'th': {
                'title': ('Captures whether the lymph nodes of the udder '
                          'appear normal at the time of the examination')
            }
        }
    )
    cmtlfq = tables.Column(
        verbose_name='CMT result left front quarter',
        orderable=False,
        attrs={
            'th': {
                'title': ('California Mastitis Test result for each left '
                          'front quarter of udder')
            }
        }
    )
    cmtrfq = tables.Column(
        verbose_name='CMT result right front quarter',
        orderable=False,
        attrs={
            'th': {
                'title': ('California Mastitis Test result for each right '
                          'front quarter of udder')
            }
        }
    )
    cmtlhq = tables.Column(
        verbose_name='CMT result left hind quarter',
        orderable=False,
        attrs={
            'th': {
                'title': ('California Mastitis Test result for each left hind '
                          'quarter of udder')
            }
        }
    )
    cmtrhq = tables.Column(
        verbose_name='CMT result right hind quarter',
        orderable=False,
        attrs={
            'th': {
                'title': ('California Mastitis Test result for each right hind'
                          ' quarter of udder')
            }
        }
    )
    front_udder_lesion_dam = tables.Column(
        verbose_name='Lesion front udder',
        orderable=False,
        attrs={
            'th': {
                'title': ('Lists all lesions of the udder area (i.e. ventral '
                          'surface surrounding the udder). Only filled in when'
                          ' udder is listed as abnormal')
            }
        }
    )
    back_udder_lesion_dam = tables.Column(
        verbose_name='Lesion back udder',
        orderable=False,
        attrs={
            'th': {
                'title': ('Lists all lesions of the udder area (i.e. ventral '
                          'surface surrounding the udder). Only filled in when'
                          ' udder is listed as abnormal')
            }
        }
    )
    front_teat_lesion_dam = tables.Column(
        verbose_name='Lesion front teat',
        orderable=False,
        attrs={
            'th': {
                'title': ('Lists all lesions of the udder area (i.e. ventral '
                          'surface surrounding the udder). Only filled in when'
                          ' udder is listed as abnormal')
            }
        }
    )
    back_teat_lesion_dam = tables.Column(
        verbose_name='Lesion back teat',
        orderable=False,
        attrs={
            'th': {
                'title': ('Lists all lesions of the udder area (i.e. ventral '
                          'surface surrounding the udder). Only filled in when'
                          ' udder is listed as abnormal')
            }
        }
    )
    front_content_lesion_dam = tables.Column(
        verbose_name='Lesion front content',
        orderable=False,
        attrs={
            'th': {
                'title': ('Lists all lesions of the udder area (i.e. ventral '
                          'surface surrounding the udder). Only filled in when'
                          ' udder is listed as abnormal')
            }
        }
    )
    back_content_lesion_dam = tables.Column(
        verbose_name='Lesion back content',
        orderable=False,
        attrs={
            'th': {
                'title': ('Lists all lesions of the udder area (i.e. ventral '
                          'surface surrounding the udder). Only filled in when'
                          ' udder is listed as abnormal')
            }
        }
    )
    leslndam = tables.Column(
        verbose_name='Lesion udder lymph nodes',
        orderable=False,
        attrs={
            'th': {
                'title': ('Lists all lesions of the udder lymph nodes. Only '
                          'filled in when udder lymph nodes are listed as '
                          'abnormal')
            }
        }
    )
    polelndam = tables.Column(
        verbose_name='Lesion udder lymph nodes position',
        orderable=False,
        attrs={
            'th': {
                'title': ('Lists the position of all lesions affecting the '
                          'udder lymph nodes. Only filled in when udder lymph '
                          'nodes are listed as abnormal')
            }
        }
    )
    lesvadam = tables.Column(
         verbose_name='Lesion affecting the udder area',
         orderable=False,
         attrs={
             'th': {
                 'title': ('Description of type of lesion affecting the udder '
                           'area')
            }
        }
    )
    lastvisitwithdata = tables.Column(
         verbose_name='Last VRD visit with data',
         orderable=False,
         attrs={
             'th': {
                 'title': ('Last VRD visit with data collection: When '
                           'entering the last visit with data, dismisses '
                           'visits where all fields are recorded as "ND" due '
                           'to animal not being available for visit')
            }
        }
    )
    datelastvisitwithdata = tables.Column(
         verbose_name='Date VRD visit with data',
         orderable=False,
         attrs={
            'th': {
                'title': ('Date of last VRD visit with data collection: When '
                          'entering the last visit with data, dismisses '
                          'visits where all fields are recorded as "ND" due '
                          'to animal not being available for visit')
            }
        }
    )
    reasonsloss = tables.Column(
         verbose_name='Reason for loss',
         orderable=False,
         attrs={
            'th': {
                'title': ('Reason why the dam was lost to follow-up before '
                          'conducting the final visit')
            }
        }
    )
    
    column_groups = OrderedDict([
        ('hide_visit', OrderedDict([
            ('columns', ('visitdate', 'visit_type')),
            ('attrs', {'style': 'background-color:#b3e2cd;'}),
        ])),
        ('hide_loss', OrderedDict([
            ('columns', ('lossfollow', 'typeloss')),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ])),
        ('hide_reasonloss', OrderedDict([
            ('columns', ('lastvisitwithdata', 'datelastvisitwithdata',
                'reasonsloss')),
            ('attrs', {'style': 'background-color:#bebada;'}),
        ])),
        ('hide_measurements_condition', OrderedDict([
            ('columns', ('hwd', 'sthd', 'bld', 'girthdam', 'subjdam',
                'csdam')),
            ('attrs', {'style': 'background-color:#cbd5e8;'}),
        ])),
        ('hide_phenotype', OrderedDict([
            ('columns', ('breed', 'local_name','pattern', 'hair',
                'dewlap_size', 'hump_f', 'hump_orn', 'hump_loc', 'face',
                'back_pf', 'rump_pf', 'horn_f', 'horn_shape', 'horn_ornt',
                'spac_hrn', 'lnth_hrn', 'nvl_sz', 'ear_sz', 'ear_shp',
                'ear_ornt', 'tail_ln', 'tail_th', 'udd_sz', 'udd_teat',
                'body_colours', 'head_colours', 'ear_colours',
                'tail_colours', 'hoof_colours', 'muzzle_colours')),
            ('attrs', {'style': 'background-color:#f4cae4;'}),
        ])),
        ('hide_udder', OrderedDict([
            ('columns', ('uareadam', 'lnudderdam', 'cmtlfq', 'cmtrfq',
                'cmtlhq', 'cmtrhq', 'front_udder_lesion_dam',
                'back_udder_lesion_dam', 'front_teat_lesion_dam',
                'back_teat_lesion_dam', 'front_content_lesion_dam',
                'back_content_lesion_dam', 'leslndam', 'polelndam',
                'lesvadam')),
            ('attrs', {'style': 'background-color:#e6f5c9;'}),
        ])),
    ])

    class Meta:
        model = Daminfo
        exclude = ('calf_id',
            'body_colour_predominant', 'body_colour_second',
            'body_colour_third', 'body_colour_fourth', 'body_colour_fifth',
            'head_colour_predominant', 'head_colour_second',
            'head_colour_third', 'head_colour_fourth',
            'ear_colour_predominant', 'ear_colour_second', 'ear_colour_third',
            'tail_colour_predominant', 'tail_colour_second',
            'tail_colour_third', 'hoof_colour_predominant',
            'hoof_colour_second', 'hoof_colour_third',
            'muzzle_colour_predominant', 'muzzle_colour_second'
        )
        sequence = (
            # ids
             'dam_id', 'visitid',
            # visit
            'visitdate', 'visit_type',
            # loss
            'lossfollow', 'typeloss',
            # Reason loss
            'lastvisitwithdata', 'datelastvisitwithdata', 'reasonsloss',
            # condition
            'subjdam', 'csdam',
            # measurements
            'hwd', 'sthd', 'bld', 'girthdam',
            # phenotype
            'breed', 'local_name',
            'pattern', 'body_colours', 'head_colours', 'ear_colours',
            'tail_colours', 'hoof_colours', 'muzzle_colours', 'hair',
            'dewlap_size', 'hump_f', 'hump_orn', 'hump_loc', 'face', 'back_pf',
            'rump_pf', 'horn_f', 'horn_shape', 'horn_ornt', 'spac_hrn',
            'lnth_hrn', 'nvl_sz', 'ear_sz', 'ear_shp', 'ear_ornt', 'tail_ln',
            'tail_th', 'udd_sz', 'udd_teat',
            # udder
            'uareadam', 'lnudderdam', 'cmtlfq', 'cmtrfq', 'cmtlhq', 'cmtrhq',
            'front_udder_lesion_dam', 'back_udder_lesion_dam',
            'front_teat_lesion_dam', 'back_teat_lesion_dam',
            'front_content_lesion_dam', 'back_content_lesion_dam',
            'leslndam', 'polelndam', 'lesvadam',
        )

    def render_dam_id(self, value):
        return self.render_farm_id(value)

    def get_combined_score_for_lesion(self, value):
        entries = value.split(' | ')
        entries = list(set(entries))
        for i, entry in enumerate(entries):
            entries[i] = entry.split('; ')
        for i, entry in enumerate(entries):
            if len(entry) == 2:
                first_digit = constants.LESION_SCORES[
                                'first_digit'
                              ][int(entry[1][0]) - 1]
                try:
                    second_digit = constants.LESION_SCORES[
                                     'second_digit'
                                   ][int(entry[1][1]) - 1]
                except:
                    second_digit = ''
                entries[i][1] = '{} {}'.format(
                                            first_digit, second_digit
                                        ).strip()
        for i, entry in enumerate(entries):
            entries[i] = '; '.join(entry)
        return format_html('<br>'.join(entries))

    def render_front_udder_lesion_dam(self, value):
        return self.get_combined_score_for_lesion(value)

    def render_back_udder_lesion_dam(self, value):
        return self.get_combined_score_for_lesion(value)

    def render_front_teat_lesion_dam(self, value):
        return self.get_combined_score_for_lesion(value)

    def render_back_teat_lesion_dam(self, value):
        return self.get_combined_score_for_lesion(value)

    def render_front_content_lesion_dam(self, value):
        return self.get_combined_score_for_lesion(value)

    def render_back_content_lesion_dam(self, value):
        return self.get_combined_score_for_lesion(value)
