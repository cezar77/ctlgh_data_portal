from collections import OrderedDict

from django.urls import reverse
from django.utils.html import format_html

import django_tables2 as tables

from ..models import Sampleinfo
from .. import constants
from .idealtable import IdealTable


class SampleinfoTable(IdealTable):
    calfid = tables.LinkColumn(
        verbose_name='CalfID',
        viewname='farminfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the calf'
            }
        }
    )
    damid = tables.LinkColumn(
        verbose_name='DamID',
        viewname='farminfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the dam'
            }
        }
    )
    visitid = tables.Column(
        verbose_name='VisitID',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the visit'
            }
        }
    )
    visitdate = tables.Column(
        verbose_name='Visit date',
        orderable=True,
        attrs={
            'th': {
                'title': 'Date of visit'
                }
        }
    )
    sampleid = tables.Column(
        verbose_name='SampleID',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the sample taken at the visit'
            }
        }
    )
    storelabel = tables.Column(
        verbose_name='Store Label',
        orderable=True,
        attrs={
            'th': {
                'title': ('ID of the store label for the sample taken at the '
                          'visit')
            }
        }
    )
    visittype = tables.Column(
        verbose_name='Type of visit',
        orderable=True,
        attrs={
            'th': {
                'title': 'Type of visit'
            }
        }
    )
    sampletype = tables.Column(
        verbose_name='Type of sample taken',
        orderable=True,
        attrs={
            'th': {
                'title': 'Type of sample taken'
            }
        }
    )
    storetype = tables.Column(
        verbose_name='Type of sample stored',
        orderable=True,
        attrs={
            'th': {
                'title': 'Type of sample stored'
            }
        }
    )
    tank = tables.Column(
        verbose_name='Tank',
        attrs={
            'th': {
                'title': 'Tank where the sample is stored.'
            }
        }
    )
    sector = tables.Column(
        verbose_name='Sector',
        attrs={
            'th': {
                'title': 'Sector where the sample is stored.'
            }
        }
    )
    boxnum = tables.Column(
        verbose_name='Box number',
        attrs={
            'th': {
                'title': 'Number of the box where the sample is stored.'
            }
        }
    )
    boxposition = tables.Column(
        verbose_name='Box position',
        attrs={
            'th': {
                'title': 'Position of the box where the sample is stored.'
            }
        }
    )
    samplepos = tables.Column(
        verbose_name='Sample position',
        attrs={
            'th': {
                'title': 'Position of the sample in the box'
            }
        }
    )
    comments = tables.Column(
        verbose_name='Comments',
        attrs={
            'th': {
                'title': 'Further comments on the sample.'
            }
        }
    )
    column_groups = OrderedDict([
        ('hide_sampleid', OrderedDict([
            ('columns', ('sampleid', 'sampletype')),
            ('attrs', {'style': 'background-color:#b3e2cd;'}),
        ])),
        ('hide_storelabel', OrderedDict([
            ('columns', ('storelabel', 'storetype')),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ])),
        ('hide_type', OrderedDict([
            ('columns', ('visittype', 'sampletype', 'storetype')),
            ('attrs', {'style': 'background-color:#cbd5e8;'}),
        ])),
        ('hide_store', OrderedDict([
            ('columns', ('tank', 'sector', 'boxnum', 'boxposition',
                'samplepos', 'comments')),
            ('attrs', {'style': 'background-color:#aacccc;'}),
        ])),
    ])

    class Meta:
        model = Sampleinfo
        exclude = ('id',)
        sequence = (
            'calfid', 'damid', 'visitid', 'visitdate', 'sampleid','storelabel', 'visittype',
            'sampletype', 'storetype', 'tank', 'sector', 'boxnum',
            'boxposition', 'samplepos', 'comments'
        )

    def render_calfid(self, value):
        url = reverse('calfinfo-list')
        return format_html(
            '<a href="{url}?calf_id={id}">{id}</a>', url=url, id=value
        )

    def value_calfid(self, value):
        return value

    def render_damid(self, value):
        url = reverse('daminfo-list')
        return format_html(
            '<a href="{url}?dam_id={id}">{id}</a>', url=url, id=value
        )

    def value_damid(self, value):
        return value
