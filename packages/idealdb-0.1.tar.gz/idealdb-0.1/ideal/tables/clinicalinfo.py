from collections import OrderedDict

from django.urls import reverse
from django.utils.html import format_html

import django_tables2 as tables

from ..models import Clinicalinfo
from .. import constants
from .idealtable import IdealTable


class ClinicalinfoTable(IdealTable):
    calfid = tables.LinkColumn(
        verbose_name='CalfID',
        viewname='calfinfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the calf'
            }
        }
    )
    damid = tables.LinkColumn(
        verbose_name='DamID',
        viewname='daminfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the dam'
            }
        }
    )
    visitid = tables.LinkColumn(
        verbose_name='VisitID',
        viewname='calfinfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the visit'
            }
        }
    )
    bodypart = tables.Column(
        verbose_name='Body part affected by disorder/lesion',
        orderable=True,
        attrs={
            'th': {
                'title': 'Body part affected by disorder/lesion'
            }
        }
    )
    lescat = tables.Column(
        verbose_name='Disorder/lesion category',
        orderable=True,
        attrs={
            'th': {
                'title': 'Disorder category (i.e. gastrointestinal, etc.)'
            }
        }
    )
    lestype = tables.Column(
        verbose_name='Disorder/lesion type',
        orderable=True,
        attrs={
            'th': {
                'title': ('Type of disorder/lesion within disorder category '
                          '(i.e. diarrhoea, constipation, etc.)')
            }
        }
    )
    other = tables.Column(
        verbose_name='Other disorder/lesion type',
        orderable=True,
        attrs={
            'th': {
                'title': ('Other type of disorder/lesion if "Disorder/lesion '
                          'type" = "Other"')
            }
        }
    )
    position = tables.Column(
        verbose_name='Position of lesion',
        orderable=True,
        attrs={
            'th': {
                'title': ('Position of lesion affecting current body part, if'
                          ' applicable')
            }
        }
    )
    extension_pattern_lesion = tables.Column(
        verbose_name='Extension pattern of the lesion',
        orderable=True,
        attrs={
            'th': {
                'title': 'Extension pattern of the lesion affecting current body part, if applicable'
            }
        }
    )
    lesion_location_capsule = tables.Column(
        verbose_name='Lesion located in organ capsule',
        orderable=True,
        attrs={
            'th': {
                'title': 'Whether the lesion is located in the capsule of the organ or not'
            }
        }
    )
    ccs = tables.Column(
        verbose_name='Who observed the disorder/lesion',
        orderable=True,
        attrs={
            'th': {
                'title': ('Whether the disorder/lesion was observed by the AHA'
                          ' / Vet or whether it was reported by the farmer')
            }
        }
    )
    column_groups = OrderedDict([
        ('hide_bodypart', OrderedDict([
            ('columns', ('bodypart',)),
            ('attrs', {'style': 'background-color:#b3e2cd;'}),
        ])),
        ('hide_lescat', OrderedDict([
            ('columns', ('lescat',)),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ])),
        ('hide_lestype', OrderedDict([
            ('columns', ('lestype',)),
            ('attrs', {'style': 'background-color:#cbd5e8;'}),
        ])),
        ('hide_other', OrderedDict([
            ('columns', ('other',)),
            ('attrs', {'style': 'background-color:#f4cae4;'}),
        ])),
        ('hide_position', OrderedDict([
            ('columns', ('position',)),
            ('attrs', {'style': 'background-color:#e6f5c9;'}),
        ])),
        ('hide_extension_pattern_lesion', OrderedDict([
            ('columns', ('extension_pattern_lesion',)),
            ('attrs', {'style': 'background-color:#fff2ae;'}),
        ])),
        ('hide_lesion_location_capsule', OrderedDict([
            ('columns', ('lesion_location_capsule',)),
            ('attrs', {'style': 'background-color:#b3e2cd;'}),
        ])),
        ('hide_ccs', OrderedDict([
            ('columns', ('ccs',)),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ]))
    ])

    class Meta:
        model = Clinicalinfo
        exclude = ('id', 'damid', 
            'body_colours', 'head_colours', 'ear_colours', 'tail_colours',
            'hoof_colours', 'muzzle_colours'
        )
        sequence = (
            # ids
            'calfid', 'visitid',
            # Disorder
            'bodypart', 'lescat', 'lestype', 'other', 'position',
            'extension_pattern_lesion', 'lesion_location_capsule', 'ccs'
        )

    def render_calfid(self, value):
        url = reverse('calfinfo-list')
        return format_html(
            '<a href="{url}?calf_id={id}">{id}</a>', url=url, id=value
        )

    def render_visitid(self, value):
        url = reverse('calfinfo-list')
        return format_html(
            '<a href="{url}?visitid={id}">{id}</a>', url=url, id=value
        )

    def value_visitid(self, value):
        return value

    def value_calfid(self, value):
        return value

    def render_damid(self, value):
        url = reverse('daminfo-list')
        return format_html(
            '<a href="{url}?dam_id={id}">{id}</a>', url=url, id=value
        )

    def value_damid(self, value):
        return value
