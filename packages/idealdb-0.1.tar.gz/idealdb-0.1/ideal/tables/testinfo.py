from collections import OrderedDict

from django.urls import reverse
from django.utils.html import format_html

import django_tables2 as tables

from ..models import Testinfo
from .idealtable import IdealTable


class TestinfoTable(IdealTable):
    calf_id = tables.LinkColumn(
        verbose_name='CalfID',
        viewname='calfinfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the calf'
            }
        }
    )
    visit_id = tables.Column(
        verbose_name='VisitID',
        attrs={
            'th': {
                'title': 'ID of the visit'
            }
        }
    )
    dam_id = tables.Column(
        verbose_name='DamID',
        attrs={
            'th': {
                'title': 'ID of the dam'
            }
        }
    )
    visitdate = tables.Column(
        verbose_name='Visit date',
        orderable=True,
        attrs={
            'th': {
                'title': 'Date of visit'
            }
        }
    )
    result_id = tables.Column(
        verbose_name='ResultID',
        attrs={
            'th': {
                'title': 'ID of the result. It is a concatenation of RSID and the TestID. '
                'The RSID is a concatenation of the replication number of the SampleID and the SampleID'
            }
        }
    )
    samplecode = tables.Column(
        verbose_name='Sample code',
        attrs={
            'th': {
                'title': 'Code for the sample type. First four digits of the '
                'RSID value. The RSID is a concatenation of the replication '
                'number of the SampleID and the SampleID'
            }
        }
    )
    test = tables.Column(
        verbose_name='Test',
        attrs={
            'th': {
                'title': 'Name of the test carried out'
            }
        }
    )
    possiblepathogen = tables.Column(
        verbose_name='Pathological agent',
        attrs={
            'th': {
                'title': 'Pathological agent e.g. the name of the parasite or '
                'pathogen which the test is designed to detect. "Quantitative test '
                'result only" is stated if the test is only designed to give a quantitative result'
            }
        }
    )
    resultstatus = tables.Column(
        verbose_name='Diagnostic test result',
        attrs={
            'th': {
                'title': 'Status of the diagnostic test result i.e. whether or '
                'not the sample was positive or negative for the parasite of '
                'interest. "Quantitative test result only" is stated if the test '
                'is only designed to give a quantitative result'
            }
        }
    )
    resultnum = tables.Column(
        verbose_name='Quantitative result number',
        attrs={
            'th': {
                'title': 'Quantitative result of the test if applicable'
            }
        }
    )
    lifestage = tables.Column(
        verbose_name='Life stage',
        attrs={
            'th': {
                'title': 'Theileria life stage observations recorded'
            }
        }
    )

    column_groups = OrderedDict([
        ('hide_visitdate', OrderedDict([
            ('columns', ('visitdate',)),
            ('attrs', {'style': 'background-color:#b3e2cd;'}),
        ])),
        ('hide_sampleinfo', OrderedDict([
            ('columns', ('result_id', 'samplecode',)),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ])),
        ('hide_testinfo', OrderedDict([
            ('columns', ('test', 'possiblepathogen', 'resultstatus', 'resultnum', 'lifestage')),
            ('attrs', {'style': 'background-color:#bebada;'}),
        ])),
    ])

    class Meta:
        model = Testinfo
        exclude = ('id', 'rsid')
        sequence = (
            'calf_id',  'dam_id', 'visit_id', 'visitdate',
            'result_id', 'samplecode',  'test', 'possiblepathogen',
            'resultstatus', 'resultnum', 'lifestage'
        )

    def render_calf_id(self, value):
        url = reverse('calfinfo-list')
        return format_html(
            '<a href="{url}?calf_id={id}">{id}</a>', url=url, id=value
        )

    def value_calf_id(self, value):
        return value
