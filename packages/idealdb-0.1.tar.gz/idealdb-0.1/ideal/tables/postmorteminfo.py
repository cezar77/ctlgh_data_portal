from collections import OrderedDict

from django.urls import reverse
from django.utils.html import format_html

import django_tables2 as tables

from ..models import Postmorteminfo
from .. import constants
from .idealtable import IdealTable


class PostmorteminfoTable(IdealTable):
    calfid = tables.LinkColumn(
        verbose_name='CalfID',
        viewname='calfinfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the calf'
            }
        }
    )
    damid = tables.LinkColumn(
        verbose_name='DamID',
        viewname='daminfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the dam'
            }
        }
    )
    visitid = tables.LinkColumn(
        verbose_name='VisitID',
        viewname='calfinfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the visit'
            }
        }
    )
    deathdate = tables.Column(
        verbose_name='Date of death',
        orderable=False,
        attrs={
            'th': {
                'title': 'Date of death'
            }
        }
    )
    deathdate = tables.Column(
        verbose_name='Date of death',
        orderable=True,
        attrs={
            'th': {
                'title': 'Date of death'
            }
        }
    )
    euthanised = tables.Column(
        verbose_name='Euthanised',
        orderable=True,
        attrs={
            'th': {
                'title': 'Whether or not the calf was euthanised'
            }
        }
    )
    immediate_cause_pathology = tables.Column(
        verbose_name='Immediate cause pathology',
        orderable=True,
        attrs={
            'th': {
                'title': ('The pathology that was determined to be the '
                          'immediate cause of death')
            }
        }
    )
    definitive_aetiological_cause = tables.Column(
        verbose_name='Definitive aetiological cause',
        orderable=True,
        attrs={
            'th': {
                'title': 'The aetiological cause of death'
            }
        }
    )
    definitive_cause_pathogen = tables.Column(
        verbose_name='Definitive cause pathogen',
        orderable=True,
        attrs={
            'th': {
                'title': ('The pathogen that corresponds to the aetiological '
                          'cause of death (if available)')
            }
        }
    )
    contributing_pathology_1 = tables.Column(
        verbose_name='Contributing pathology 1',
        orderable=True,
        attrs={
            'th': {
                'title': 'A pathology that may have contributed to death'
            }
        }
    )
    contributing_cause_1 = tables.Column(
        verbose_name='Contributing cause 1',
        orderable=True,
        attrs={
            'th': {
                'title': 'A contributing cause of death'
            }
        }
    )
    contributing_cause_pathogen_1 = tables.Column(
        verbose_name='Contributing cause pathogen 1',
        orderable=True,
        attrs={
            'th': {
                'title': ('The pathogen that corresponds to the contributing '
                          'cause of death (if available)')
            }
        }
    )
    contributing_pathology_2 = tables.Column(
        verbose_name='Contributing pathology 2',
        orderable=True,
        attrs={
            'th': {
                'title': ('A second pathology that may have contributed to '
                          'death')
            }
        }
    )
    contributing_cause_2 = tables.Column(
        verbose_name='Contributing cause 2',
        orderable=True,
        attrs={
            'th': {
                'title': 'A second contributing cause of death'
            }
        }
    )
    contributing_cause_pathogen_2 = tables.Column(
        verbose_name='Contributing cause pathogen 2',
        orderable=True,
        attrs={
            'th': {
                'title': ('The pathogen that corresponds to the contributing '
                          'cause of death (if available)')
            }
        }
    )
    pm_comments = tables.Column(
        verbose_name='Post mortem comments',
        orderable=False,
        attrs={
            'th': {
                'title': 'Comments from the post-mortem report'
            }
        }
    )
    histopath_report = tables.Column(
        verbose_name='Histopathology report',
        orderable=False,
        attrs={
            'th': {
                'title': 'The histopathology report'
            }
        }
    )
    histo_aetiological_diagnosis = tables.Column(
        verbose_name='Histopathology aetiological diagnosis',
        orderable=False,
        attrs={
            'th': {
                'title': ('The aetiological diagnosis from the histopathology '
                          'report')
            }
        }
    )
    histo_comments = tables.Column(
        verbose_name='Histopathology comments',
        orderable=False,
        attrs={
            'th': {
                'title': 'Comments from the histopathology report'
            }
        }
    )
    stomach_content = tables.Column(
        verbose_name='Stomach content',
        orderable=False,
        attrs={
            'th': {
                'title': 'Description of the stomach contents if abnormal'
            }
        }
    )
    column_groups = OrderedDict([
        ('hide_immediate_cause', OrderedDict([
            ('columns', ('immediate_cause_pathology',
                'definitive_aetiological_cause', 'definitive_cause_pathogen')),
            ('attrs', {'style': 'background-color:#b3e2cd;'}),
        ])),
        ('hide_contributing_cause_1', OrderedDict([
            ('columns', ('contributing_pathology_1', 'contributing_cause_1',
                'contributing_cause_pathogen_1')),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ])),
        ('hide_contributing_cause_2', OrderedDict([
            ('columns', ('contributing_pathology_2', 'contributing_cause_2',
                'contributing_cause_pathogen_2')),
            ('attrs', {'style': 'background-color:#cbd5e8;'}),
        ])),
        ('hide_postmortem_comments', OrderedDict([
            ('columns', ('pm_comments',)),
            ('attrs', {'style': 'background-color:#f4cae4;'}),
        ])),
        ('hide_histpath', OrderedDict([
            ('columns', ('histopath_report', 'histo_aetiological_diagnosis',
                'histo_comments')),
            ('attrs', {'style': 'background-color:#e6f5c9;'}),
        ])),
       ('hide_stomach_contents', OrderedDict([
            ('columns', ('stomach_content',)),
            ('attrs', {'style': 'background-color:#fff2ae;'}),
        ])),
    ])

    class Meta:
        model = Postmorteminfo
        exclude = ('damid',
            'pm_report', 'body_colours', 'head_colours', 'ear_colours',
            'tail_colours', 'hoof_colours', 'muzzle_colours'
        )
        sequence = (
            # ids
            'calfid',  'visitid',
            # visit and euthanised
            'deathdate', 'euthanised',
            # immediate cause
            'immediate_cause_pathology', 'definitive_aetiological_cause',
            'definitive_cause_pathogen',
            # contributing cause
            'contributing_pathology_1', 'contributing_cause_1',
            'contributing_cause_pathogen_1', 'contributing_pathology_2',
            'contributing_cause_2', 'contributing_cause_pathogen_2',
            # pm comments
            'pm_comments',
            # Hispath report
            'histopath_report', 'histo_aetiological_diagnosis',
            'histo_comments',
            # Stomach contents
            'stomach_content'
        )

    def render_calfid(self, value):
        url = reverse('calfinfo-list')
        return format_html(
            '<a href="{url}?calf_id={id}">{id}</a>', url=url, id=value
        )

    def value_calfid(self, value):
        return value

    def render_damid(self, value):
        url = reverse('daminfo-list')
        return format_html(
            '<a href="{url}?dam_id={id}">{id}</a>', url=url, id=value
        )

    def value_damid(self, value):
        return value

    def render_visitid(self, value):
        url = reverse('calfinfo-list')
        return format_html(
            '<a href="{url}?visitid={id}">{id}</a>', url=url, id=value
        )
