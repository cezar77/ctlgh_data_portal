from collections import OrderedDict

from django.urls import reverse
from django.utils.html import format_html

import django_tables2 as tables

from ..models import Calfinfo
from .. import constants
from .idealtable import AnimalTable


class CalfinfoTable(AnimalTable):
    calf_id = tables.LinkColumn(
        verbose_name='CalfID',
        viewname='farminfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the calf'
                }
            }
        )
    dam_id = tables.LinkColumn(
        verbose_name='DamID',
        viewname='farminfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the dam'
            }
        }
    )
    visitid = tables.LinkColumn(
        verbose_name='VisitID',
        viewname='testinfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the visit'
                }
            }
        )
    visitdate = tables.Column(
        verbose_name='Visit date',
        orderable=True,
        attrs={
            'th': {
                'title': 'Date of visit'
                }
            }
        )
    visit_type = tables.Column(
        verbose_name='Visit type',
        orderable=False,
        attrs={
            'th': {
                'title': 'Type of visit'
            }
        }
    )
    lossfollow = tables.Column(
        verbose_name='Calf available',
        orderable=False,
        attrs={
            'th': {
                'title': 'Whether the calf is available for visit'
            }
        }
    )
    typeloss = tables.Column(
        verbose_name='Reason why calf is unavailable',
        orderable=False,
        attrs={
            'th': {
                'title': 'Reason why the calf is not available for visit'
            }
        }
    )
    breed = tables.Column(
        verbose_name='Breed',
        orderable=False,
        attrs={
            'th': {
                'title': 'Common name of breed'
            }
        }
    )
    local_name = tables.Column(
        verbose_name='Local name',
        orderable=False,
        attrs={
            'th': {
                'title': 'Local name of breed'
            }
        }
    )
    pattern = tables.Column(
        verbose_name='Coat pattern',
        orderable=False,
        attrs={
            'th': {
                'title': ('Description of coat pattern (i.e. pied, uniform, '
                          'etc.)')
            }
        }
    )
    hair = tables.Column(
        verbose_name='Coat hair length',
        orderable=False,
        attrs={
            'th': {
                'title': 'Description of coat hair length'
            }
        }
    )
    dewlap_size = tables.Column(
        verbose_name='Dewlap size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Dewlap size'
            }
        }
    )
    cadob = tables.Column(
        verbose_name='Date of birth',
        orderable=False,
        attrs={
            'th': {
                'title': 'Date calf was born'
            }
        }
    )
    calfsex = tables.Column(
        verbose_name='Calf sex',
        orderable=False,
        attrs={
            'th': {
                'title': 'Sex of the calf'
            }
        }
    )
    ce = tables.Column(
        verbose_name='Clinical episode',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether the calf presents with a clinical episode '
                          'at the time of the current visit')
            }
        }
    )
    girth = tables.Column(
        verbose_name='Girth',
        orderable=False,
        attrs={
            'th': {
                'title': 'Girth measurement of calf (cm)'
            }
        }
    )
    weight = tables.Column(
        verbose_name='Weight',
        orderable=False,
        attrs={
            'th': {
                'title': 'Weight of the calf (kg); at eligible visits only'
            }
        }
    )
    suckling = tables.Column(
        verbose_name='Suckling',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether the calf is still suckling milk from the '
                          'dam at the time of the current visit')
            }
        }
    )
    rt = tables.Column(
        verbose_name='Rectal temperature',
        orderable=False,
        attrs={
            'th': {
                'title': 'Rectal temperature at the time of the current visit'
            }
        }
    )
    famacha_l = tables.Column(
        verbose_name='Famacha score (left)',
        orderable=False,
        attrs={
            'th': {
                'title': ('FAMACHA score: Left conjunctiva at the time of the '
                          'current visit')
            }
        }
    )
    famacha_r = tables.Column(
        verbose_name='Famacha score (right)',
        orderable=False,
        attrs={
            'th': {
                'title': ('FAMACHA score: right conjunctiva at the time of '
                          'the current visit')
            }
        }
    )
    elasticity = tables.Column(
        verbose_name='Elasticity',
        orderable=False,
        attrs={
            'th': {
                'title': ('Degree of skin elasticity at the time of the '
                          'current visit')
            }
        }
    )
    f_consist = tables.Column(
        verbose_name='Consistency of faeces',
        orderable=False,
        attrs={
            'th': {
                'title': ('Consistency of faeces at the time of the current '
                          'visit')
            }
        }
    )
    diaorseverity = tables.Column(
        verbose_name='Severity of diarrhoea',
        orderable=False,
        attrs={
            'th': {
                'title': ('Severity of diarrhoea at the time of the current '
                          'visit. Only applicable if the consistency of the '
                          'faeces is listed as diarrhoea')
            }
        }
    )
    diaorkind = tables.Column(
        verbose_name='Type of diarrhoea',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of diarrhoea at the time of the current '
                          'visit. Only applicable if the consistency of the '
                          'faeces is listed as diarrhoea')
            }
        }
    )
    diaorodour = tables.Column(
        verbose_name='Odour of diarrhoea',
        orderable=False,
        attrs={
            'th': {
                'title': ('Odour of the diarrhoea at the time of the current '
                          'visit. Only applicable if the consistency of the '
                          'faeces is listed as diarrhoea')
            }
        }
    )
    hrsscm = tables.Column(
        verbose_name='Horizontal length of right supra-scapular lymph node',
        orderable=False,
        attrs={
            'th': {
                'title': ('Calliper measurement: Horizontal length (cm) of '
                          'right supra-scapular lymph node')
            }
        }
    )
    hlsscm = tables.Column(
        verbose_name='Horizontal length of left supra-scapular lymph node',
        orderable=False,
        attrs={
            'th': {
                'title': ('Calliper measurement: Horizontal length (cm) of '
                          'left supra-scapular lymph node')
            }
        }
    )
    hrpccm = tables.Column(
        verbose_name='Horizontal length of right precrural lymph node',
        orderable=False,
        attrs={
            'th': {
                'title': ('Calliper measurement: Horizontal length (cm) of '
                          'right precrural lymph node')
            }
        }
    )
    hlpccm = tables.Column(
        verbose_name='Horizontal length of left precrural lymph node',
        orderable=False,
        attrs={
            'th': {
                'title': ('Calliper measurement: Horizontal length (cm) of '
                          'left precrural lymph node')
            }
        }
    )
    rappend = tables.Column(
        verbose_name='Rhipicephalus appendiculatus infestation',
        orderable=False,
        attrs={
            'th': {
                'title': ('Level of infestation: Adult Rhipicephalus'
                          'appendiculatus')
            }
        }
    )
    ammbly = tables.Column(
        verbose_name='Amblyomma spp. infestation',
        orderable=False,
        attrs={
            'th': {
                'title': 'Level of infestation: Adult Amblyomma spp.'
            }
        }
    )
    booph = tables.Column(
        verbose_name='Boophilus spp. infestation',
        orderable=False,
        attrs={
            'th': {
                'title': 'Level of infestation: Adult Boophilus spp.'
            }
        }
    )
    hyalomm = tables.Column(
        verbose_name='Hyalomma spp. infestation',
        orderable=False,
        attrs={
            'th': {
                'title': 'Level of infestation: Adult Hyalomma spp.'
            }
        }
    )
    other_tick_louse = tables.Column(
        verbose_name='Other tick species infestation',
        orderable=False,
        attrs={
            'th': {
                'title': ('Level of infestation: Adult tick stages other than '
                          'R. appendiculatus, Amblyomma spp., Boophilus spp. '
                          'or Hyalomma spp.')
            }
        }
    )
    lice = tables.Column(
        verbose_name='Lice infestation',
        orderable=False,
        attrs={
            'th': {
                'title': 'Level of infestation: Lice'
            }
        }
    ) 
    fleas = tables.Column(
        verbose_name='Fleas infestation',
        orderable=False,
        attrs={
            'th': {
                'title': 'Level of infestation: Fleas'
            }
        }
    )
    vtcalfyn = tables.Column(
        verbose_name='Veterinary intervention (calf)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether the calf has benefited from any sort of '
                          'veterinary intervention since the time of the last '
                          'inter-visit history till present')
            }
        }
    )
    vtdamyn = tables.Column(
        verbose_name='Veterinary intervention (dam)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether the dam has benefited from any sort of '
                          'veterinary intervention since the time of the last '
                          'inter-visit history till present')
            }
        }
    )
    vtherdyn = tables.Column(
        verbose_name='Veterinary intervention (herd)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether other cattle in the herd have benefited '
                          'from any sort of veterinary intervention since the '
                          'time of the last inter-visit history till present')
            }
        }
    )
    grazing = tables.Column(
        verbose_name='Grazing',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether the calf has started to go out grazing '
                          'with adults at the time of the current visit')
            }
        }
    )
    cynb = tables.Column(
        verbose_name='Animal bite (calf)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Captures history of animal bites for the calf from '
                          'the time of the last inter-visit history till '
                          'present')
            }
        }
    )
    dynb = tables.Column(
        verbose_name='Animal bite (dam)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Captures history of animal bites for the dam from '
                          'the time of the last inter-visit history till '
                          'present')
            }
        }
    )
    hynb = tables.Column(
        verbose_name='Animal bite (herd)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Captures history of animal bites for other cattle '
                          'in the herd from the time of the last inter-visit '
                          'history till present')
            }
        }
    )
    currentnumbercattle = tables.Column(
        verbose_name='Current number of cattle in the herd (total)',
        orderable=False,
        attrs={
            'th': {
                'title': ('The current total number of cattle in the herd. '
                          'Captures history of cattle movements and deaths in '
                          'the herd from the time of the last inter-visit '
                          'history till present. The recruited calf and the '
                          'dam must be included in the counts. If the current '
                          'number of cattle in the herd equals 999 then this '
                          'means there are >50 cattle in the herd')
            }
        }
    )
    totalentries = tables.Column(
        verbose_name='Total entries (including births in the household)',
        orderable=False,
        attrs={
            'th': {
                'title': ('The total number of entries (including births) in '
                          'the household. Captures history of cattle '
                          'movements and deaths in the herd from the time of '
                          'the last inter-visit history till present')
            }
        }
    )
    totaldeaths = tables.Column(
        verbose_name='Total deaths',
        orderable=False,
        attrs={
            'th': {
                'title': ('The total number of deaths in the household. '
                          'Captures history of cattle movements and deaths in '
                          'the herd from the time of the last inter-visit '
                          'history till present')
            }
        }
    )
    totalexits = tables.Column(
        verbose_name='Total exits (including deaths)',
        orderable=False,
        attrs={
            'th': {
                'title': ('The total number of exits (including deaths) in '
                          'the household. Captures history of cattle '
                          'movements and deaths in the herd from the time of '
                          'the last inter-visit history till present. Deaths '
                          'must be included in exit counts')
            }
        }
    )
    animalcatdead = tables.Column(
        verbose_name='Description of dead animal (herd)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Animal category (i.e. adult male(s), adult '
                          'female(s), weaning male(s), weaning female(s), '
                          'etc.) which died  from the time of the last '
                          'inter-visit history till present. Only applicable '
                          'if at least one cattle death is recorded in the '
                          'total deaths column')
            }
        }
    )
    numdeadanicat = tables.Column(
        verbose_name='Number of dead animals by category',
        orderable=False,
        attrs={
            'th': {
                'title': ('Number of deaths within current animal category '
                          'attributed to same cause of death as recorded in '
                          'the Cause of death (herd) column from the time of '
                          'the last inter-visit history till present. Only '
                          'applicable if at least one cattle death is '
                          'recorded in the total deaths column')
            }
        }
    )
    whydead = tables.Column(
        verbose_name='Cause of death (herd)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Description of all causes of death from the time '
                          'of the last inter-visit history till present. Only '
                          'applicable if at least one cattle death is '
                          'recorded in the total deaths column')
            }
        }
    )
    vetinter_calf_cattto = tables.Column(
        verbose_name='Category of treatment (calf)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Category of treatment (i.e. antihelminthic, '
                          'antibiotic, etc.) given to the calf from the time '
                          'of the last inter-visit history till present. Only '
                          'applicable when veterinary intervention (calf) is '
                          'yes')
            }
        }
    )
    vetinter_calf_typetto = tables.Column(
        verbose_name='Type of drug (calf)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of drug within treatment category (i.e. '
                          'albendazole, etc.) given to the calf from the time '
                          'of the last inter-visit history till present. Only '
                          'applicable when veterinary intervention (calf) is '
                          'yes')
            }
        }
    )
    vetinter_calf_typeapplic = tables.Column(
        verbose_name='Type of application (calf)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of application of drug given to the calf from '
                          'the time of the last inter-visit history till '
                          'present. Only applicable when veterinary '
                          'intervention (calf) is yes')
            }
        }
    )
    vetinter_dam_cattto = tables.Column(
        verbose_name='Category of treatment (dam)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Category of treatment (i.e. antihelminthic, '
                          'antibiotic, etc.) given to the dam from the time '
                          'of the last inter-visit history till present. Only '
                          'applicable when veterinary intervention (dam) is '
                          'yes')
            }
        }
    )
    vetinter_dam_typetto = tables.Column(
        verbose_name='Type of drug (dam)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of drug within treatment category (i.e. '
                          'albendazole, etc.) given to the dam from the time '
                          'of the last inter-visit history till present. Only '
                          'applicable when veterinary intervention (dam) is '
                          'yes')
            }
        }
    )
    vetinter_dam_typeapplic = tables.Column(
        verbose_name='Type of application (dam)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of application of drug given to the dam from '
                          'the time of the last inter-visit history till '
                          'present. Only applicable when veterinary '
                          'intervention (dam) is yes')
            }
        }
    )
    vetinter_herd_cattto = tables.Column(
        verbose_name='Category of treatment (herd)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Category of treatment (i.e. antihelminthic, '
                          'antibiotic, etc.) given to cattle from the time of '
                          'the last inter-visit history till present. Only '
                          'applicable when veterinary intervention (herd) is '
                          'yes')
            }
        }
    )
    vetinter_herd_typetto = tables.Column(
        verbose_name='Type of drug (herd)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of drug within treatment category (i.e. '
                          'albendazole, etc.) given to cattle from the time '
                          'of the last inter-visit history till present. Only '
                          'applicable when veterinary intervention (herd) is '
                          'yes')
            }
        }
    )
    vetinter_herd_typeapplic = tables.Column(
        verbose_name='Type of application (herd)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of application of drug given to cattle from '
                          'the time of the last inter-visit history till '
                          'present. Only applicable when veterinary '
                          'intervention (herd) is yes')
            }
        }
    )
    vetinter_herd_nherdtto = tables.Column(
        verbose_name='Number of treated cattle (herd)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Number of treated cattle or approximate percentage '
                          'of treated cattle if the exact number is unknown '
                          'from the time of the last inter-visit history till '
                          'present. Only applicable when veterinary '
                          'intervention (herd) is yes')
            }
        }
    )
    hprobcat = tables.Column(
        verbose_name='Herd disorder (category)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Description of all herd health disorders observed '
                          'during the inspection at the category level (i.e. '
                          'gastrointestinal, etc.). Only applicable if the '
                          'herd health is recorded as abnormal')
            }
        }
    )
    hlestype = tables.Column(
        verbose_name='Herd disorder (type)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of disorder within disorder category (i.e. '
                          'diarrhoea, constipation, etc.). Description of all '
                          'herd health disorders observed during the '
                          'inspection. Only applicable if the herd health is '
                          'recorded as abnormal')
            }
        }
    )
    observedby = tables.Column(
        verbose_name='Herd disorder (observed by)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether the disorder in the herd was observed by '
                          'the AHA / Vet or whether it was reported by the '
                          'farmer. Description of all herd health disorders '
                          'observed during the inspection. Only applicable if '
                          'the herd health is recorded as abnormal')
            }
        }
    )
    damaffected = tables.Column(
        verbose_name='Herd disorder (dam affected)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether the disorder in the herd affected the dam. '
                          'Description of all herd health disorders observed '
                          'during the inspection. Only applicable if the herd '
                          'health is recorded as abnormal')
            }
        }
    )
    percentherd = tables.Column(
        verbose_name='Herd disorder (percent affected)',
        orderable=False,
        attrs={
            'th': {
                'title': ('Extent of the problem at the herd level. Indicates '
                          'the percentage of cattle affected by the disorder '
                          '(excluding the dam). Description of all herd '
                          'health disorders observed during the inspection. '
                          'Only applicable if the herd health is recorded as '
                          'abnormal')
            }
        }
    )
    calfdonev = tables.Column(
        verbose_name='Visit when calf phenotyping captured',
        orderable=False,
        attrs={
            'th': {
                'title': ('Visit at which the phenotypic & morphometry traits '
                          'of the calf where captured')
            }
        }
    )
    hair_typ = tables.Column(
        verbose_name='Hair type',
        orderable=False,
        attrs={
            'th': {
                'title': 'Calf hair type'
            }
        }
    )
    hump_size = tables.Column(
        verbose_name='Hump size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Calf hump size'
            }
        }
    )
    hump_orientation = tables.Column(
        verbose_name='Hump orientation',
        orderable=False,
        attrs={
            'th': {
                'title': 'Hump orientation. Only applicable if hump is present'
            }
        }
    )
    hump_location = tables.Column(
        verbose_name='Hump location',
        orderable=False,
        attrs={
            'th': {
                'title': 'Hump location. Only applicable if hump is present'
            }
        }
    )
    face = tables.Column(
        verbose_name='Face profile',
        orderable=False,
        attrs={
            'th': {
                'title': 'Profile of face'
            }
        }
    )
    back_profile = tables.Column(
        verbose_name='Back profile',
        orderable=False,
        attrs={
            'th': {
                'title': 'Profile of back'
            }
        }
    )
    rump_profile = tables.Column(
        verbose_name='Rump profile',
        orderable=False,
        attrs={
            'th': {
                'title': 'Profile of rump'
            }
        }
    )
    horn_presence = tables.Column(
        verbose_name='Horn presence',
        orderable=False,
        attrs={
            'th': {
                'title': 'Whether horns are present'
            }
        }
    )
    horn_shape = tables.Column(
        verbose_name='Horn shape',
        orderable=False,
        attrs={
            'th': {
                'title': 'Horn shape. Only applicable if horns are present'
            }
        }
    )
    horn_orientation = tables.Column(
        verbose_name='Horns orientation',
        orderable=False,
        attrs={
            'th': {
                'title': ('Horns orientation. Only applicable if horns are '
                          'present')
            }
        }
    )
    horn_spacing = tables.Column(
        verbose_name='Horn spacing',
        orderable=False,
        attrs={
            'th': {
                'title': 'Horns spacing. Only applicable if horns are present'
            }
        }
    )
    horn_length = tables.Column(
        verbose_name='Horns length',
        orderable=False,
        attrs={
            'th': {
                'title': 'Horn length. Only applicable if horns are present'
            }
        }
    )
    naval_flap_size = tables.Column(
        verbose_name='Naval flap size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Naval flap size (i.e. absent, small, medium, etc.)'
            }
        }
    )
    ear_size = tables.Column(
        verbose_name='Ear size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Ear size'
            }
        }
    )
    ear_shape = tables.Column(
        verbose_name='Ear shape',
        orderable=False,
        attrs={
            'th': {
                'title': 'Ear shape'
            }
        }
    )
    ear_orientation = tables.Column(
        verbose_name='Ear orientation',
        orderable=False,
        attrs={
            'th': {
                'title': 'Ears orientation'
            }
        }
    )
    tail_length = tables.Column(
        verbose_name='Tail length',
        orderable=False,
        attrs={
            'th': {
                'title': 'Tail length'
            }
        }
    )
    tail_thickness = tables.Column(
        verbose_name='Tail thickness at base',
        orderable=False,
        attrs={
            'th': {
                'title': 'Tail thickness at base'
            }
        }
    )
    udder_size = tables.Column(
        verbose_name='Udder size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Udder size'
            }
        }
    )
    teats_size = tables.Column(
        verbose_name='Teats size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Teats size'
            }
        }
    )
    testis = tables.Column(
        verbose_name='Testis size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Testis size'
            }
        }
    )
    perpuce = tables.Column(
        verbose_name='Preputial sheath size',
        orderable=False,
        attrs={
            'th': {
                'title': 'Preputial sheath size'
            }
        }
    )
    hwc = tables.Column(
        verbose_name='Height at withers',
        orderable=False,
        attrs={
            'th': {
                'title': 'Height at withers (cm)'
            }
        }
    )
    sthc = tables.Column(
        verbose_name='Body length from shoulder joint to hip joint',
        orderable=False,
        attrs={
            'th': {
                'title': 'Body length from shoulder joint to hip joint (cm)'
            }
        }
    )
    blc = tables.Column(
        verbose_name='Total body length',
        orderable=False,
        attrs={
            'th': {
                'title': ('Total body length - from muzzle to tail base - '
                          'while keeping neck in extension (cm)')
            }
        }
    )
    lastvisitwithdata = tables.Column(
        verbose_name='Last visit with data',
        orderable=False,
        attrs={
            'th': {
                'title': ('Last VRC visit with data collection for calves '
                          'which were lost to follow up before VRC51 (i.e. '
                          'all calves with no VRC51 data). Dismisses visits '
                          'where all fields are recorded as "ND" due to '
                          'animal not being available for visit')
            }
        }
    )
    datelastvisitwithdata = tables.Column(
        verbose_name='Date last visit with data',
        orderable=False,
        attrs={
            'th': {
                'title': ('Date of last VRC visit with data collection for '
                          'calves which were lost to follow up before VRC51 '
                          '(i.e. all calves with no VRC51 data). Dismisses '
                          'visits where all fields are recorded as "ND" due '
                          'to animal not being available for visit')
            }
        }
    )
    reasonsloss = tables.Column(
        verbose_name='Reasons for loss',
        orderable=False,
        attrs={
            'th': {
                'title': ('Reason why the calf was lost to follow-up before '
                          'conducting the yearly visit (VRC51)')
            }
        }
    )
    postmortemdone = tables.Column(
        verbose_name='Post-mortem done',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether a post-mortem visit was conducted for '
                          'current calf')
            }
        }
    )
    reasonspmnotdone = tables.Column(
        verbose_name='Reason why post-mortem was not done',
        orderable=False,
        attrs={
            'th': {
                'title': ('Explanation of why a post-mortem visit was not '
                          'conducted for current calf')
            }
        }
    )
    deadalive = tables.Column(
        verbose_name='Dead or alive at end of study',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether or not the calf survived until the end '
                          'of the study period at 51 weeks of age')
            }
        }
    )
    ceever = tables.Column(
        verbose_name='Ever experienced a clinical episode',
        orderable=False,
        attrs={
            'th': {
                'title': ('Did the calf ever experience a clinical episode '
                          'during its enrolment in the study')
            }
        }
    )
    column_groups = OrderedDict([
        ('hide_visit', OrderedDict([
            ('columns', ('visitdate', 'visit_type', 'ce', 'ceever')),
            ('attrs', {'style': 'background-color:#b3e2cd;'}),
        ])),
        ('hide_loss', OrderedDict([
            ('columns', ('deadalive', 'lossfollow', 'typeloss')),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ])),
        ('hide_reasonloss', OrderedDict([
            ('columns', ('lastvisitwithdata', 'datelastvisitwithdata',
                'reasonsloss', 'postmortemdone', 'reasonspmnotdone')),
            ('attrs', {'style': 'background-color:#bebada;'}),
        ])),
        ('hide_calf_key_info', OrderedDict([
            ('columns', ('cadob', 'calfsex')),
            ('attrs', {'style': 'background-color:#cbd5e8;'}),
        ])),
        ('hide_calf_visit_measurements', OrderedDict([
            ('columns', ('girth', 'weight', 'hrsscm', 'hlsscm', 'hrpccm',
                'hlpccm')),
            ('attrs', {'style': 'background-color:#f4cae4;'}),
        ])),
        ('hide_ectoparasites', OrderedDict([
            ('columns', ('rappend', 'ammbly', 'booph', 'hyalomm',
                'other_tick_louse', 'lice', 'fleas')),
            ('attrs', {'style': 'background-color:#e6f5c9;'}),
        ])),
        ('hide_sucking_grazing', OrderedDict([
            ('columns', ('suckling', 'grazing',)),
            ('attrs', {'style': 'background-color:#fff2ae;'}),
        ])),
        ('hide_clinical_information', OrderedDict([
            ('columns', ('rt',  'famacha_l', 'famacha_r', 'elasticity')),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ])),
        ('hide_diarrhoea', OrderedDict([
            ('columns', ('f_consist', 'diaorseverity', 'diaorkind',
                'diaorodour')),
            ('attrs', {'style': 'background-color:#cbd5e8;'}),
        ])),
        ('hide_herd_disorders', OrderedDict([
            ('columns', ('hprobcat', 'hlestype', 'observedby', 'damaffected',
                'percentherd')),
            ('attrs', {'style': 'background-color:#f4cae4;'}),
        ])),
        ('hide_animal_bites', OrderedDict([
            ('columns', ('cynb','dynb', 'hynb')),
            ('attrs', {'style': 'background-color:#e6f5c9;'}),
        ])),
        ('hide_veterinary_interventions', OrderedDict([
            ('columns', ('vtcalfyn', 'vetinter_calf_cattto',
                'vetinter_calf_typetto', 'vetinter_calf_typeapplic', 'vtdamyn',
                'vetinter_dam_cattto', 'vetinter_dam_typetto',
                'vetinter_dam_typeapplic', 'vtherdyn', 'vetinter_herd_cattto',
                'vetinter_herd_typetto', 'vetinter_herd_typeapplic',
                'vetinter_herd_nherdtto')),
            ('attrs', {'style': 'background-color:#fff2ae;'}),
        ])),
        ('hide_cattle_movements', OrderedDict([
            ('columns', ('currentnumbercattle', 'totalentries', 'totaldeaths',
                'totalexits', 'animalcatdead', 'numdeadanicat', 'whydead')),
            ('attrs', {'style': 'background-color:#b3e2cd;'}),
        ])),
        ('hide_phenotype', OrderedDict([
            ('columns', ('calfdonev','breed', 'local_name', 'pattern',
                'body_colours', 'head_colours', 'ear_colours', 'tail_colours',
                'hoof_colours', 'muzzle_colours', 'hair', 'hair_typ',
                'dewlap_size', 'hump_size', 'hump_orientation',
                'hump_location', 'face', 'back_profile', 'rump_profile',
                'horn_presence', 'horn_shape', 'horn_orientation',
                'horn_spacing', 'horn_length', 'naval_flap_size', 'ear_size',
                'ear_shape','ear_orientation', 'tail_length', 'tail_thickness',
                'udder_size', 'teats_size', 'testis', 'perpuce')),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ])),
        ('hide_fixed_measurements', OrderedDict([
            ('columns', ('hwc', 'sthc', 'blc')),
            ('attrs', {'style': 'background-color:#cbd5e8;'}),
        ])),
    ])
    
    class Meta:
        model = Calfinfo
        exclude = ('dam_id', 
            'body_colour_predominant', 'body_colour_second',
            'body_colour_third', 'body_colour_fourth', 'body_colour_fifth',
            'head_colour_predominant', 'head_colour_second',
            'head_colour_third', 'head_colour_fourth', 'head_colour_fifth',
            'ear_colour_predominant', 'ear_colour_second', 'ear_colour_third',
            'tail_colour_predominant', 'tail_colour_second',
            'tail_colour_third', 'hoof_colour_predominant',
            'hoof_colour_second', 'hoof_colour_third',
            'muzzle_colour_predominant', 'muzzle_colour_second',
        #Calf and name numbers as not applicable
            'vetinter_calf_nherdtto', 'vetinter_dam_nherdtto'
        )
        sequence = (
            # ids
            'calf_id', 'visitid',
            # visit
            'visitdate', 'visit_type','ce', 'ceever',
            # loss
            'deadalive','lossfollow', 'typeloss',
            # reasons for loss
            'lastvisitwithdata', 'datelastvisitwithdata', 'reasonsloss',
            'postmortemdone', 'reasonspmnotdone',
            # fixed calf information
            'cadob', 'calfsex',
            # measurements taken at visits
            'girth', 'weight', 'hrsscm', 'hlsscm', 'hrpccm', 'hlpccm',
            # ectoparasites
            'rappend', 'ammbly', 'booph', 'hyalomm', 'other_tick_louse',
            'lice', 'fleas',
            # sucking and grazing at visits
            'suckling', 'grazing',
            # clinical information
            'rt',  'famacha_l', 'famacha_r', 'elasticity',
            # diarrhoea
            'f_consist', 'diaorseverity', 'diaorkind', 'diaorodour',
            # herd disorders
            'hprobcat', 'hlestype', 'observedby', 'damaffected', 'percentherd',
            # animal bites
            'cynb','dynb', 'hynb',
            # veterinary interventions
            'vtcalfyn', 'vetinter_calf_cattto', 'vetinter_calf_typetto',
            'vetinter_calf_typeapplic', 'vtdamyn', 'vetinter_dam_cattto',
            'vetinter_dam_typetto', 'vetinter_dam_typeapplic', 'vtherdyn',
            'vetinter_herd_cattto', 'vetinter_herd_typetto',
            'vetinter_herd_typeapplic', 'vetinter_herd_nherdtto',
            # cattle movements
            'currentnumbercattle', 'totalentries', 'totaldeaths', 'totalexits',
            'animalcatdead', 'numdeadanicat', 'whydead',
            # breed names and phenotype
            'calfdonev','breed', 'local_name', 'pattern', 'body_colours',
            'head_colours', 'ear_colours', 'tail_colours', 'hoof_colours',
            'muzzle_colours', 'hair', 'hair_typ', 'dewlap_size', 'hump_size',
            'hump_orientation', 'hump_location', 'face', 'back_profile',
            'rump_profile', 'horn_presence', 'horn_shape', 'horn_orientation',
            'horn_spacing', 'horn_length', 'naval_flap_size', 'ear_size',
            'ear_shape','ear_orientation', 'tail_length', 'tail_thickness',
            'udder_size', 'teats_size', 'testis', 'perpuce',
            # fixed measurements
            'hwc', 'sthc', 'blc',
        )

    def render_calf_id(self, value):
        return self.render_farm_id(value)

    def render_visitid(self, value):
        visit_code = value[:3]
        if visit_code == 'VRC':
            url = reverse('testinfo-list')
        elif visit_code == 'VCC':
            url = reverse('clinicalinfo-list')
        elif visit_code == 'VPC':
            url = reverse('postmorteminfo-list')
        return format_html(
            '<a href="{url}?visitid={id}">{id}</a>', url=url, id=value
        )

    def value_visitid(self, value):
        return value
