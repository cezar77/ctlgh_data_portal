import math
from collections import OrderedDict

from django.urls import reverse
from django.utils.html import format_html

import django_tables2 as tables

from ..models import Farminfo
from .idealtable import IdealTable


class FarminfoTable(IdealTable):
    true = format_html('<span class="true">✔</span>')
    false = format_html('<span class="false">✘</span>')
    
    calf_id = tables.LinkColumn(
        verbose_name='CalfID',
        viewname='calfinfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the calf'
            }
        }
    )
    farmer_id = tables.Column(
        verbose_name='FarmerID',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the farmer'
            }
        }
    )
    dam_id = tables.LinkColumn(
        verbose_name='DamID',
        viewname='daminfo-list',
        orderable=True,
        attrs={
            'th': {
                'title': 'ID of the dam'
            }
        }
    )
    calf_sex = tables.Column(
        verbose_name='Calf sex',
        orderable=False,
        attrs={
            'th': {
                'title': 'Sex of the calf'
            }
        }
    )
    calf_date_of_birth = tables.Column(
        verbose_name='Calf date of birth',
        orderable=False,
        attrs={
            'th': {
                'title': 'Date of birth of the calf'
            }
        }
    )
    sublocation = tables.Column(
        verbose_name='Sublocation',
        orderable=True,
        attrs={
            'th': {
                'title': 'Sublocation where the household is located'
            }
        }
    )
    farmer_sex = tables.Column(
        verbose_name='Farmer sex',
        orderable=False,
        attrs={
            'th': {
                'title': 'Sex of the farmer'
            }
        }
    )
    farmer_age = tables.Column(
        verbose_name='Farmer age',
        orderable=False,
        attrs={
            'th': {
                'title': 'Age of the farmer (years)'
            }
        }
    )
    longitude = tables.Column(
        verbose_name='Longitude',
        orderable=False,
        attrs={
            'th': {
                'title': 'GPS position of household: Longitude'
            }
        }
    )
    latitude = tables.Column(
        verbose_name='Latitude',
        orderable=False,
        attrs={
            'th': {
                'title': 'GPS position of household: Latitude'
            }
        }
    )
    altitude = tables.Column(
        verbose_name='Altitude',
        orderable=False,
        attrs={
            'th': {
                'title': 'GPS position of household: Elevation (m)'
            }
        }
    )
    education = tables.Column(
        verbose_name='Education',
        orderable=False,
        attrs={
            'th': {
                'title': 'Level of education of the farmer'
            }
        }
    )
    training = tables.Column(
        verbose_name='Training',
        orderable=False,
        attrs={
            'th': {
                'title': 'Whether the farmer has technical training'
            }
        }
    )
    position = tables.Column(
        verbose_name='Position',
        orderable=False,
        attrs={
            'th': {
                'title': 'Position in household of the farmer'
            }
        }
    )
    occupation = tables.Column(
        verbose_name='Occupation',
        orderable=False,
        attrs={
            'th': {
                'title': ('Main occupation of the farmer (either a farmer or '
                          'not)')
            }
        }
    )
    selling_point = tables.Column(
        verbose_name='Selling point',
        orderable=False,
        attrs={
            'th': {
                'title': ('Captures the main source of cattle entries in the '
                          'herd. Type of purchasing point (i.e. market, '
                          'other)')
            }
        }
    )
    market = tables.Column(
        verbose_name='Market',
        orderable=False,
        attrs={
            'th': {
                'title': ('Captures the main source of cattle entries in the '
                          'herd. Name of purchasing market if the selling '
                          'point was a market')
            }
        }
    )
    cattle_kept_w_chicken = tables.Column(
        verbose_name='Cattle kept with chicken',
        orderable=False,
        attrs={
            'th': {
                'title': ('Description of how chicken are kept in relation to '
                          'cattle (i.e. together or separate at different '
                          'times of the day). This question only applies if '
                          'the farmer keeps chicken in the household')
            }
        }
    )
    dam_age = tables.Column(
        verbose_name='Dam age',
        orderable=False,
        attrs={
            'th': {
                'title': 'Age of dam (years) as estimated by farmer'
            }
        }
    )
    dam_calvings = tables.Column(
        verbose_name='Dam calvings',
        orderable=False,
        attrs={
            'th': {
                'title': ('Number of calvings undergone by dam including '
                          'calving of recruited calf')
            }
        }
    )
    dam_born_in_household = tables.BooleanColumn(
        verbose_name='Dam was born in the household',
        orderable=False,
        null=False,
        attrs={
            'th': {
                'title': 'Whether the dam was born in the household'
            }
        }
    )
    dam_time_at_farm = tables.Column(
        verbose_name='Dam time at farm',
        orderable=False,
        attrs={
            'th': {
                'title': ('Number of months the dam has spent in the farm at '
                          'the time of the visit')
            }
        }
    )
    bull_origin = tables.Column(
        verbose_name='Bull origin',
        orderable=False,
        attrs={
            'th': {
                'title': ('Origin of bull that fathered the calf (i.e. owned, '
                          'borrowed, etc.)')
            }
        }
    )
    bull_type = tables.Column(
        verbose_name='Bull type',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of bull that fathered the calf (i.e. '
                          'indigenous, exotic or cross)')
            }
        }
    )
    milked_prior_calving = tables.BooleanColumn(
        verbose_name='Dam was milked prior calving',
        orderable=False,
        null=False,
        attrs={
            'th': {
                'title': ('Whether the dam was milked on the week before '
                          'calving')
            }
        }
    )
    milked_prior_time = tables.Column(
        verbose_name='Dam milked prior calving: time',
        orderable=False,
        attrs={
            'th': {
                'title': ('If the dam was milked on the week before calving, '
                          'then number of hours from last milking to calving')
            }
        }
    )
    milked_prior_frequency = tables.Column(
        verbose_name='Dam milked prior calving: frequency',
        orderable=False,
        attrs={
            'th': {
                'title': ('If the dam was milked on the week before calving, '
                          'then frequency of milking on pre-calving week')
            }
        }
    )
    milked_post_calving = tables.BooleanColumn(
        verbose_name='Dam was milked post calving',
        orderable=False,
        null=False,
        attrs={
            'th': {
                'title': 'Whether the dam was milked on the week after calving'
            }
        }
    )
    milked_post_frequency = tables.Column(
        verbose_name='Dam was milked post calving: frequency',
        orderable=False,
        attrs={
            'th': {
                'title': ('If the dam was milked on the week after calving, '
                          'then frequency of milking on first week '
                          'post-calving')
            }
        }
    )
    milked_prior_colostrum = tables.BooleanColumn(
        orderable=False,
        verbose_name='Dam was milked prior colostrum',
        null=False,
        attrs={
            'th': {
                'title': ('After calving, whether the dam was milked prior to '
                          'the calf suckling colostrum')
            }
        }
    )
    calf_suckled = tables.BooleanColumn(
        verbose_name='Calf suckled',
        orderable=False,
        null=False,
        attrs={
            'th': {
                'title': ('Whether the calf suckled directly from dam within '
                          '24 hours of birth')
            }
        }
    )
    calf_suckled_alternative = tables.Column(
        verbose_name='Calf suckled alternative',
        orderable=False,
        attrs={
            'th': {
                'title': ('If the calf did not suckle directly from dam within'
                          ' 24 hours of birth, this describes the measures '
                          'taken by farmer if any (i.e. feeding of artificial '
                          'colostrum, etc.)')
            }
        }
    )
    navel_desinfected = tables.BooleanColumn(
        verbose_name='Navel was disinfected',
        orderable=False,
        null=False,
        attrs={
            'th': {
                'title': ('Whether the farmer disinfected the umbilicus of the'
                          ' calf after birth')
            }
        }
    )
    
    land_ownership = tables.Column(
        verbose_name='Land ownership',
        orderable=False,
        attrs={
            'th': {
                'title': 'Type of land ownership of the farmer'
            }
        }
    )
    total_acres_used = tables.Column(
        verbose_name='Total acres used',
        orderable=False,
        attrs={
            'th': {
                'title': 'Total number of acres owned / rented for own use'
            }
        }
    )
    total_acres_leased = tables.Column(
        verbose_name='Total acres leased',
        orderable=False,
        attrs={
            'th': {
                'title': 'Total number of acres leased to a third party'
            }
        }
    )
    crops = tables.BooleanColumn(
        verbose_name='Crops',
        orderable=False,
        null=False,
        attrs={
            'th': {
                'title': ('Whether the farmers use land involves cultivation '
                          'of crops')
            }
        }
    )
    diseases = tables.BooleanColumn(
        verbose_name='Diseases',
        orderable=False,
        null=False,
        attrs={
            'th': {
                'title': ('Whether there are any prevalent diseases of cattle '
                          'in the farm')
            }
        }
    )
    housing_dry = tables.Column(
        verbose_name='Housing dry',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of housing provided to cattle during the dry '
                          'season. In general terms, captures the main form '
                          'of housing for the cattle herd. Only one form of '
                          'housing is captured. Housing includes anything '
                          'that is not purely open space (e.g. kraal, '
                          'stall-shed, yard, other)')
            }
        }
    )
    housing_wet = tables.Column(
        verbose_name='Housing wet',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of housing provided to cattle during the wet '
                          'season. In general terms, captures the main form '
                          'of housing for the cattle herd. Only one form of '
                          'housing is captured. Housing includes anything '
                          'that is not purely open space (e.g. kraal, '
                          'stall-shed, yard, other)')
            }
        }
    )
    housing_calves = tables.Column(
        verbose_name='Housing calves',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether calves are housed together with adults. '
                          'This question does not apply if no housing is '
                          'provided in both the wet and dry season')
            }
        }
    )
    roof_dry = tables.Column(
        verbose_name='Roof dry',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether housing includes roof during dry season. '
                          'This question does not apply if no housing is '
                          'provided in the dry season')
            }
        }
    )
    roof_wet = tables.Column(
        verbose_name='Roof wet',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether housing includes roof during wet season. '
                          'This question does not apply if no housing is '
                          'provided in the wet season')
            }
        }
    )
    wall_dry = tables.Column(
        verbose_name='Wall dry',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether housing includes solid wall during dry '
                          'season. This question does not apply if no housing '
                          'is provided in the dry season')
            }
        }
    )
    wall_wet = tables.Column(
        verbose_name='Wall wet',
        orderable=False,
        attrs={
            'th': {
                'title': ('Whether housing includes solid wall during wet '
                          'season. This question does not apply if no housing '
                          'is provided in the wet season')
            }
        }
    )
    floor_dry = tables.Column(
        verbose_name='Floor dry',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of flooring in housing facility during dry '
                          'season. This question does not apply if no housing '
                          'is provided in the dry season')
            }
        }
    )
    floor_wet = tables.Column(
        verbose_name='Floor wet',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of flooring in housing facility during wet '
                          'season. This question does not apply if no housing '
                          'is provided in the wet season')
            }
        }
    )
    nutritional_supplements = tables.BooleanColumn(
        verbose_name='Nutritional supplements',
        orderable=False,
        null=False,
        attrs={
            'th': {
                'title': ('Whether cattle receive any nutritional supplements '
                          'to their diet. Captures whether cattle receive any '
                          'nutritional supplements to their basic (grazing) '
                          'diet (e.g. roughage / crop residue, concentrates, '
                          'napier grass, banana leaves, minerals, vitamins, '
                          'etc.)')
            }
        }
    )
    vaccine = tables.BooleanColumn(
        verbose_name='Vaccine',
        orderable=False,
        null=False,
        attrs={
            'th': {
                'title': ('Whether cattle in the farm get vaccinated. Captures'
                          ' whether there are any vaccines for cattle used in '
                          'the farm')
            }
        }
    )
    veterinary_support = tables.BooleanColumn(
        verbose_name='Veterinary support',
        orderable=False,
        null=False,
        attrs={
            'th': {
                'title': ('Whether the farmer has access to any form of '
                          'veterinary service. Captures whether the farmer has'
                          ' access to some form of veterinary service to '
                          'manage the health of the cattle')
            }
        }
    )
    watered_dry = tables.Column(
        verbose_name='Watered dry',
        orderable=False,
        attrs={
            'th': {
                'title': ('How are cattle watered during the dry season (e.g. '
                          'water is fetched, animals go to water etc.)')
            }
        }
    )
    watered_wet = tables.Column(
        verbose_name='Watered wet',
        orderable=False,
        attrs={
            'th': {
                'title': ('How are cattle watered during the wet season (e.g. '
                          'water is fetched, or animals go to water etc.)')
            }
        }
    )
    water_distance_dry = tables.Column(
        verbose_name='Water distance dry',
        orderable=False,
        attrs={
            'th': {
                'title': 'Distance to furthest watering point (dry season)'
            }
        }
    )
    water_distance_wet = tables.Column(
        verbose_name='Water distance wet',
        orderable=False,
        attrs={
            'th': {
                'title': 'Distance to furthest watering point (wet season)'
            }
        }
    )
    watering_frequency_dry = tables.Column(
        verbose_name='Watering frequency dry',
        orderable=False,
        attrs={
            'th': {
                'title': 'Frequency of watering (dry season)'
            }
        }
    )
    watering_frequency_wet = tables.Column(
        verbose_name='Watering frequency wet',
        orderable=False,
        attrs={
            'th': {
                'title': 'Frequency of watering (wet season)'
            }
        }
    )
    water_quality_dry = tables.Column(
        verbose_name='Water quality dry',
        orderable=False,
        attrs={
            'th': {
                'title': 'Water quality (dry season)'
            }
        }
    )
    water_quality_wet = tables.Column(
        verbose_name='Water quality wet',
        orderable=False,
        attrs={
            'th': {
                'title': 'Water quality (wet season)'
            }
        }
    )
    grazed_with_adults = tables.BooleanColumn(
        verbose_name='Grazed with adults',
        orderable=False,
        null=False,
        attrs={
            'th': {
                'title': ('In general terms, whether calves are grazed / fed '
                          'with adults')
            }
        }
    )
    number_of_cattle = tables.Column(
        verbose_name='Number of cattle',
        orderable=False,
        attrs={
            'th': {
                'title': ('Livestock kept by farmer: the exact number of '
                          'cattle at the time of recruitment is recorded')
            }
        }
    )
    number_of_chicken = tables.Column(
        verbose_name='Number of chickens',
        orderable=False,
        attrs={
            'th': {
                'title': ('Livestock kept by farmer: the exact number of '
                          'chickens at the time of recruitment is recorded')
            }
        }
    )
    number_of_dogs = tables.Column(
        verbose_name='Number of dogs',
        orderable=False,
        attrs={
            'th': {
                'title': ('The exact number of dogs at the time of recruitment'
                          ' is recorded')
            }
        }
    )
    number_of_sheep = tables.Column(
        verbose_name='Number of sheep',
        orderable=False,
        attrs={
            'th': {
                'title': ('Livestock kept by farmer: the exact number of sheep '
                          'at the time of recruitment is recorded')
            }
        }
    )
    number_of_goats = tables.Column(
        verbose_name='Number of goats',
        orderable=False,
        attrs={
            'th': {
                'title': ('Livestock kept by farmer: the exact number of goats'
                          ' at the time of recruitment is recorded')
            }
        }
    )
    number_of_pigs = tables.Column(
        verbose_name='Number of pigs',
        orderable=False,
        attrs={
            'th': {
                'title': ('Livestock kept by farmer: the exact number of pigs '
                          'at the time of recruitment is recorded')
            }
        }
    )
    disease_cat = tables.Column(
        verbose_name='Category of disorder affecting cattle',
        orderable=False,
        attrs={
            'th': {
                'title': ('All diseases / syndromes / clinical signs that the '
                          'farmer regards as being common amongst cattle in '
                          'the farm. Only applicable when there are some '
                          'prevalent diseases of cattle on the farm '
                          '(‘Diseases’ = ‘Yes’)')
            }
        }
    )
    disease_type = tables.Column(
        verbose_name='Name (type) of disorder / disease affecting cattle',
        orderable=False,
        attrs={
            'th': {
                'title': ('All diseases / syndromes / clinical signs that the '
                          'farmer regards as being common amongst cattle in '
                          'the farm. Only applicable when there are some '
                          'prevalent diseases of cattle on the farm '
                          '(‘Diseases’ = ‘Yes’)')
            }
        }
    )
    treatment_cat = tables.Column(
        verbose_name= ('Category of treatment given to cattle to common '
                       'disorder)'),
        orderable=False,
        attrs={
            'th': {
                'title': ('Category of treatment (e.g. antihelminthic, '
                          'antibiotic, etc.) given to cattle to treat common '
                          'diseases / syndromes / clinical signs amongst '
                          'cattle in the farm. Only applicable when there are '
                          'some prevalent diseases of cattle on the farm '
                          '(‘Diseases’ = ‘Yes’)')
            }
        }
    )
    treatment_type = tables.Column(
        verbose_name= ('Name (type) of treatment given to cattle to common '
                       'disorder)'),
        orderable=False,
        attrs={
            'th': {
                'title': ('Name (type) of treatment (e.g. antihelminthic, '
                          'antibiotic, etc.) given to cattle to treat common '
                          'diseases / syndromes / clinical signs amongst '
                          'cattle in the farm. Only applicable when there are '
                          'some prevalent diseases of cattle on the farm '
                          '(‘Diseases’ = ‘Yes’)')
            }
        }
    )
    ectoparasites_method = tables.Column(
        verbose_name= 'Ectoparasite control - method',
        orderable=False,
        attrs={
            'th': {
                'title': ('All methods of application for ectoparasite control '
                          'treatment. Only applicable when ectoparasite '
                          'control on the farm is true')
            }
        }
    )
    ectoparasites_cat = tables.Column(
        verbose_name= 'Ectoparasite control - drug category',
        orderable=False,
        attrs={
            'th': {
                'title': ('Category of drug / method utilised for ectoparasite '
                          'control treatment. Only applicable when '
                          'ectoparasite control on the farm is true')
            }
        }
    )
    ectoparasites_type = tables.Column(
        verbose_name= 'Ectoparasite control - drug type',
        orderable=False,
        attrs={
            'th': {
                'title': ('Name (type) of drug / method utilised for '
                          'ectoparasite control treatment. Only applicable '
                          'when ectoparasite control on the farm is true')
            }
        }
    )
    ectoparasites_freqdry = tables.Column(
        verbose_name= 'Ectoparasite control - frequency dry',
        orderable=False,
        attrs={
            'th': {
                'title': ('Frequency of ectoparasite control treatment '
                          'application during the dry season. Only applicable '
                          'when ectoparasite control on the farm is true')
            }
        }
    )
    ectoparasites_freqwet = tables.Column(
        verbose_name= 'Ectoparasite control - frequency wet',
        orderable=False,
        attrs={
            'th': {
                'title': ('Frequency of ectoparasite control treatment '
                          'application during the wet season. Only applicable '
                          'when ectoparasite control on the farm is true')
            }
        }
    )
    endoparasites_method = tables.Column(
        verbose_name= 'Intestinal parasites control - method',
        orderable=False,
        attrs={
            'th': {
                'title': ('All methods of application for intestinal parasite '
                          'control treatment. Only applicable when intestinal '
                          'parasite control on the farm is true')
            }
        }
    )
    endoparasites_cat = tables.Column(
        verbose_name= 'Intestinal parasites control - drug category',
        orderable=False,
        attrs={
            'th': {
                'title': ('Category of drug / method utilised for intestinal '
                          'parasite control treatment. Only applicable when '
                          'intestinal parasite control on the farm is true')
            }
        }
    )
    endoparasites_type = tables.Column(
        verbose_name= 'Intestinal parasites control - drug type',
        orderable=False,
        attrs={
            'th': {
                'title': ('Name (type) of drug / method utilised for '
                          'intestinal parasite control treatment. Only '
                          'applicable when intestinal parasite control on the '
                          'farm is true')
            }
        }
    )
    endoparasites_freqdry = tables.Column(
        verbose_name= 'Intestinal parasites control - frequency dry',
        orderable=False,
        attrs={
            'th': {
                'title': ('Frequency of intestinal parasite control treatment '
                          'application during the dry season. Only applicable '
                          'when intestinal parasite control on the farm is '
                          'true')
            }
        }
    )
    endoparasites_freqwet = tables.Column(
        verbose_name= 'Intestinal parasites control - frequency wet',
        orderable=False,
        attrs={
            'th': {
                'title': ('Frequency of intestinal parasite control treatment '
                          'application during the wet season. Only applicable '
                          'when intestinal parasite control on the farm is '
                          'true')
            }
        }
    )
    trypanosoma_method = tables.Column(
        verbose_name= 'Trypanosoma control - method',
        orderable=False,
        attrs={
            'th': {
                'title': ('All methods of application for Trypanosoma control '
                          'treatment. Only applicable when Trypanosoma control '
                          'on the farm is true')
            }
        }
    )
    trypanosoma_cat = tables.Column(
        verbose_name= 'Trypanosoma control - drug category',
        orderable=False,
        attrs={
            'th': {
                'title': ('Category of drug / method utilised for Trypanosoma '
                          'control treatment. Only applicable when Trypanosoma '
                          'control on the farm is true')
            }
        }
    )
    trypanosoma_type = tables.Column(
        verbose_name= 'Trypanosoma control - drug type',
        orderable=False,
        attrs={
            'th': {
                'title': ('Name (type) of drug / method utilised for '
                          'Trypanosoma control treatment. Only applicable when '
                          'Trypanosoma control on the farm is true')
            }
        }
    )
    trypanosoma_freqdry = tables.Column(
        verbose_name= 'Trypanosoma control - frequency dry',
        orderable=False,
        attrs={
            'th': {
                'title': ('Frequency of Trypanosoma control treatment '
                          'application during the dry season. Only applicable '
                          'when Trypanosoma control on the farm is true')
            }
        }
    )
    trypanosoma_freqwet = tables.Column(
        verbose_name= 'Trypanosoma control - frequency wet',
        orderable=False,
        attrs={
            'th': {
                'title': ('Frequency of Trypanosoma control treatment '
                          'application during the wet season. Only applicable '
                          'when Trypanosoma control on the farm is true')
            }
        }
    )
    vaccine_type = tables.Column(
        verbose_name= 'Vaccine type',
        orderable=False,
        attrs={
            'th': {
                'title': ('Name (type) of vaccine used on the farm. Only '
                          'applicable when the farmer states that they use '
                          'vaccines on the farm (‘Vaccine’ = ‘Yes’)')
            }
        }
    )
    vaccine_freq = tables.Column(
        verbose_name= 'Vaccine frequency',
        orderable=False,
        attrs={
            'th': {
                'title': ('Vaccination frequency. Only applicable when the '
                          'farmer states that they use vaccines on the farm '
                          '(‘Vaccine’ = ‘Yes’)')
            }
        }
    )
    vet_assit = tables.Column(
        verbose_name= 'Veterinary assistance',
        orderable=False,
        attrs={
            'th': {
                'title': ('Type of veterinary service accessed by farmer to '
                          'manage cattle health. Only applicable when the '
                          'farmer has access to some form of veterinary '
                          'service (‘Veterinary Support’ = ‘Yes’)')
            }
        }
    )
    column_groups =  OrderedDict([
        #('hide_farmer',  OrderedDict([
        #    ('columns', ('farmer_sex', 'farmer_age', 'education', 'training',
        #        'position', 'occupation')),
        #    ('attrs', {'style': 'background-color:#b3e2cd;'}),
        #])),
        #('hide_market', OrderedDict([
        #    ('columns', ('selling_point', 'market')),
        #    ('attrs', {'style': 'background-color:#fdcdac;'}),
        #])),
        ('hide_farm_and_husbandry', OrderedDict([
        #    ('columns', ('land_ownership', 'total_acres_used',
        #        'total_acres_leased', 'crops',
            ('columns', ('grazed_with_adults', 'nutritional_supplements',
                'diseases', 'vaccine', 'veterinary_support', 'vet_assit')),
            ('attrs', {'style': 'background-color:#cbd5e8;'}),
        ])),
        ('hide_common_diseases', OrderedDict([
            ('columns', ('disease_cat', 'disease_type', 'treatment_cat',
                'treatment_type')),
            ('attrs', {'style': 'background-color:#f4cae4;'}),
        ])),
        ('hide_ectoparasites', OrderedDict([
            ('columns', ('ectoparasites_method', 'ectoparasites_cat',
                'ectoparasites_type', 'ectoparasites_freqdry',
                'ectoparasites_freqwet')),
            ('attrs', {'style': 'background-color:#e6f5c9;'}),
        ])),
        ('hide_endoparasites', OrderedDict([
            ('columns', ('endoparasites_method', 'endoparasites_cat',
                'endoparasites_type', 'endoparasites_freqdry',
                'endoparasites_freqwet')),
            ('attrs', {'style': 'background-color:#fff2ae;'}),
        ])),
        ('hide_tryps', OrderedDict([
            ('columns', ('trypanosoma_method', 'trypanosoma_cat',
                'trypanosoma_type', 'trypanosoma_freqdry',
                'trypanosoma_freqwet')),
            ('attrs', {'style': 'background-color:#b3e2cd;'}),
        ])),
        ('hide_vaccine', OrderedDict([
            ('columns', ('vaccine_type', 'vaccine_freq')),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ])),
        ('hide_housing', OrderedDict([
            ('columns', ( 'housing_dry', 'housing_wet', 'housing_calves',
                'roof_dry', 'roof_wet', 'wall_dry', 'wall_wet', 'floor_dry',
                'floor_wet')),
            ('attrs', {'style': 'background-color:#cbd5e8;'}),
        ])),
        ('hide_watering', OrderedDict([
            ('columns', ('watered_dry', 'watered_wet', 'water_distance_dry',
                'water_distance_wet', 'watering_frequency_dry',
                'watering_frequency_wet', 'water_quality_dry',
                'water_quality_wet')),
            ('attrs', {'style': 'background-color:#f4cae4;'}),
        ])),
        ('hide_livestock', OrderedDict([
            ('columns', ('cattle_kept_w_chicken', 'number_of_cattle',
                'number_of_chicken', 'number_of_dogs', 'number_of_sheep',
                'number_of_goats', 'number_of_pigs')),
            ('attrs', {'style': 'background-color:#e6f5c9;'}),
        ])),
        ('hide_dam', OrderedDict([
            ('columns', ( 'dam_age', 'dam_calvings', 'dam_born_in_household',
                'dam_time_at_farm')),
            ('attrs', {'style': 'background-color:#fff2ae;'}),
        ])),
        ('hide_milking', OrderedDict([
            ('columns', ( 'milked_prior_calving', 'milked_prior_time',
                'milked_prior_frequency', 'milked_post_calving',
                'milked_post_frequency')),
            ('attrs', {'style': 'background-color:#b3e2cd;'}),
        ])),
        ('hide_suckling', OrderedDict([
            ('columns', ('milked_prior_colostrum', 'calf_suckled',
                'calf_suckled_alternative', 'navel_desinfected')),
            ('attrs', {'style': 'background-color:#fdcdac;'}),
        ])),
        ('hide_bull', OrderedDict([
            ('columns', ('bull_origin', 'bull_type')),
            ('attrs', {'style': 'background-color:#cbd5e8;'}),
        ]))
    ])

    class Meta:
        model = Farminfo
        exclude = (
            'id', 'sublocation_id', 'longitude', 'latitude', 'altitude',
            'farmer_sex', 'farmer_age', 'education', 'training', 'position',
            'occupation', 'selling_point', 'market', 'land_ownership',
            'total_acres_used', 'total_acres_leased', 'crops'
        )
        sequence = (
            # identification
            'calf_id', 'farmer_id', 'dam_id', 
            'sublocation','calf_date_of_birth', 'calf_sex',
            # farmer
            # 'farmer_sex', 'farmer_age', 'education', 'training', 'position',
            # 'occupation',
            # market
            # 'selling_point', 'market',
            # farm and husbandry
            # 'land_ownership', 'total_acres_used', 'total_acres_leased', 'crops',
            'grazed_with_adults','nutritional_supplements', 'diseases',
            'vaccine', 'veterinary_support', 'vet_assit',
            # Common diseases
            'disease_cat', 'disease_type', 'treatment_cat', 'treatment_type',
            #Disease control
            'ectoparasites_method', 'ectoparasites_cat', 'ectoparasites_type',
            'ectoparasites_freqdry', 'ectoparasites_freqwet',
            'endoparasites_method', 'endoparasites_cat', 'endoparasites_type',
            'endoparasites_freqdry', 'endoparasites_freqwet',
            'trypanosoma_method', 'trypanosoma_cat', 'trypanosoma_type',
            'trypanosoma_freqdry', 'trypanosoma_freqwet',
            # Vaccines
            'vaccine_type', 'vaccine_freq',
            # housing
            'housing_dry', 'housing_wet', 'housing_calves', 'roof_dry',
            'roof_wet', 'wall_dry', 'wall_wet', 'floor_dry', 'floor_wet',
            # watering
            'watered_dry', 'watered_wet',
            'water_distance_dry', 'water_distance_wet',
            'watering_frequency_dry', 'watering_frequency_wet',
            'water_quality_dry', 'water_quality_wet',
            # livestock at farm
            'cattle_kept_w_chicken', 'number_of_cattle', 'number_of_chicken',
            'number_of_dogs', 'number_of_sheep', 'number_of_goats',
            'number_of_pigs',
            # dam
            'dam_age', 'dam_calvings', 'dam_born_in_household',
            'dam_time_at_farm',
            # milking
            'milked_prior_calving', 'milked_prior_time',
            'milked_prior_frequency', 'milked_post_calving',
            'milked_post_frequency',
            # suckling
            'milked_prior_colostrum', 'calf_suckled',
            'calf_suckled_alternative', 'navel_desinfected',
            # bull
            'bull_origin', 'bull_type',
        )
    
    def get_sex_icon(self, value):
        html = '<i class="fa{fa}"></i>'
        if value == 'F':
            fa_class = ' fa-venus'
        elif value == 'M':
            fa_class = ' fa-mars'
        else:
            fa_class = 'ND'
        return format_html(html, fa=fa_class)

    def render_calf_sex(self, value):
        return self.get_sex_icon(value)

    def value_calf_sex(self, value):
        return value

    def render_sublocation(self, value, record):
        return '{} ({})'.format(value, record.sublocation_id)

    def render_farmer_sex(self, value):
        return self.get_sex_icon(value)

    def value_farmer_sex(self, value):
        return value

    def render_farmer_age(self, value):
        if value == -888:
            return 'ND'
        return value

    def render_training(self, value):
        if value == 'Yes':
            return self.true
        elif value == 'No':
            return self.false
        else:
            return value

    def value_training(self, value):
        return value 

    def render_dam_calvings(self, value):
        if value is not None and not float(value).is_integer():
            return '{} to {}'.format(math.floor(value), math.ceil(value))
        return int(value)

    def render_dam_time_at_farm(self, value):
        if value < 0:
            return 'NA'
        return value

    def render_milked_prior_time(self, value):
        if value == -999:
            return 'NA'
        elif value == -888:
            return 'ND'
        return value

    def render_total_acres_used(self, value):
        if value == -999:
            return 'NA'
        elif value == -888:
            return 'ND'
        return round(value, 2)

    def render_total_acres_leased(self, value):
        if value == -999:
            return 'NA'
        elif value == -888:
            return 'ND'
        return round(value, 2)

    def get_expanded_boolean(self, value):
        if value == -999:
            return 'NA'
        elif value == -888:
            return 'ND'
        elif value == 0:
            return self.false
        elif value == 1:
            return self.true
        else:
            return value

    def get_expanded_boolean_value(self, value):
        if value == -999:
            return 'NA'
        elif value == -888:
            return 'ND'
        elif value == 0:
            return 'False'
        elif value == 1:
            return 'True'
        else:
            return value

    def render_housing_calves(self, value):
        return self.get_expanded_boolean(value)

    def value_housing_calves(self, value):
        return self.get_expanded_boolean_value(value)

    def render_roof_dry(self, value):
        return self.get_expanded_boolean(value)

    def value_roof_dry(self, value):
        return self.get_expanded_boolean_value(value)

    def render_roof_wet(self, value):
        return self.get_expanded_boolean(value)

    def value_roof_wet(self, value):
        return self.get_expanded_boolean_value(value)

    def render_wall_dry(self, value):
        return self.get_expanded_boolean(value)

    def value_wall_dry(self, value):
        return self.get_expanded_boolean_value(value)

    def render_wall_wet(self, value):
        return self.get_expanded_boolean(value)

    def value_wall_wet(self, value):
        return self.get_expanded_boolean_value(value)
