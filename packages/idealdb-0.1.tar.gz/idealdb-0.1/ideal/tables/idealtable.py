import re

from django.urls import reverse
from django.utils.html import format_html

import django_tables2 as tables


class IdealTable(tables.Table):
    export_formats = ['tsv', 'csv']

    def __init__(self, *args, **kwargs):
        for item in self.column_groups.items():
            for col in item[1]['columns']:
                self.base_columns[col].attrs['th'].update(item[1]['attrs'])
        self.model_name = self._meta.model.__name__
        self.name = self.model_name[0:-4] + ' Information'
        self.name = self.name.replace('Postmortem', 'Post-mortem')
        super(IdealTable, self).__init__(*args, **kwargs)

    def as_values(self, exclude_columns=None):
        """
        Overload the as_values method.

        Replace None with 'NA' in the files for download.
        In the downloaded files (TSV, CSV) all empty values (cells)
        should be replaced with the string 'NA'.
        """
        table = super(IdealTable, self).as_values(exclude_columns)
        for row in table:
            yield [
                'NA' if cell is None else cell
                for cell in row
            ]

    def render_calf_id(self, value):
        url = reverse('calfinfo-list')
        return format_html(
            '<a href="{url}?calf_ids={id}">{id}</a>', url=url, id=value
        )

    def value_calf_id(self, value):
        return value
    
    def render_dam_id(self, value):
        url = reverse('daminfo-list')
        return format_html(
            '<a href="{url}?dam_ids={id}">{id}</a>', url=url, id=value
        )

    def value_dam_id(self, value):
        return value


class AnimalTable(IdealTable):
    body_colours = tables.Column(
        verbose_name='Body colours',
        accessor='body_colours',
        orderable=False,
        attrs={
            'th': {
                'title': ('Describes the body colour of the dam. The '
                          'predominant body colour is listed first, the second '
                          'colour second etc. Additional body colours may not be '
                          'applicable.')
            }
        }
    )
    head_colours = tables.Column(
        verbose_name='Head colours',
        accessor='head_colours',
        orderable=False,
        attrs={
            'th': {
                'title': ('Describes the colour of head of the dam. The '
                          'predominant head colour is listed first, the second '
                          'colour second etc. Additional head colours may not be '
                          'applicable.')
            }
        }
    )
    ear_colours = tables.Column(
        verbose_name='Ear colours',
        accessor='ear_colours',
        orderable=False,
        attrs={
            'th': {
                'title': ('Describes the colour of ears of the dam. The '
                          'predominant ear colour is listed first, the second '
                          'colour second etc. Additional ear colours may not be '
                          'applicable.')
            }
        }
    )
    tail_colours = tables.Column(
        verbose_name='Tail colours',
        accessor='tail_colours',
        orderable=False,
        attrs={
            'th': {
                'title': ('Describes the colour of tail of the dam. The '
                          'predominant tail colour is listed first, the second '
                          'colour second etc. Additional tail colours may not be '
                          'applicable.')
            }
        }
    )
    hoof_colours = tables.Column(
        verbose_name='Hoof colours',
        accessor='hoof_colours',
        orderable=False,
        attrs={
            'th': {
                'title': ('Describes the colour of hoofs of the dam. The '
                          'predominant hoof colour is listed first, the second '
                          'colour second etc. Additional hoof colours may not be '
                          'applicable.')
            }
        }
    )
    muzzle_colours = tables.Column(
        verbose_name='Muzzle colours',
        accessor='muzzle_colours',
        orderable=False,
        attrs={
            'th': {
                'title': ('Describes the colour of muzzle of the dam. The '
                          'predominant muzzle colour is listed first, the '
                          'second colour second etc. Additional muzzle colours may '
                          'not be applicable.')
            }
        }
    )
    
    def render_farm_id(self, value):
        url = reverse('farminfo-list')
        match = re.search(
            'ideal.tables.(?P<view>[a-z]+)info',
            str(self.Meta())
        )
        view = match.groupdict()['view']
        return format_html(
            '<a href="{url}?{view}_ids={id}">{id}</a>',
            url=url, view=view, id=value
        )

    def value_farm_id(self, value):
        return value

    def value_body_colours(self, record):
        return record.body_colours_hex

    def value_head_colours(self, record):
        return record.head_colours_hex

    def value_ear_colours(self, record):
        return record.ear_colours_hex

    def value_tail_colours(self, record):
        return record.tail_colours_hex

    def value_hoof_colours(self, record):
        return record.hoof_colours_hex

    def value_muzzle_colours(self, record):
        return record.muzzle_colours_hex
