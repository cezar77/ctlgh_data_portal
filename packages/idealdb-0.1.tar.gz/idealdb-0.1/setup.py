import os
from setuptools import find_packages, setup

with open(os.path.join(os.path.dirname(__file__), 'README.rst')) as readme:
    README = readme.read()

setup(
    name='idealdb',
    version='0.1',
    packages=find_packages(),
    include_package_data=True,
    description='IDEAL DB application',
    long_description=README,
    url='http://data.ctlgh.org',
    author='Cezar Pendarovski',
    author_email='cezar.pendarovski@roslin.ed.ac.uk',
    classifiers=[
        'Environment :: Web Environment',
        'Framework :: Django',
        'Framework :: Django :: 1.11',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3.5',
    ],
)
