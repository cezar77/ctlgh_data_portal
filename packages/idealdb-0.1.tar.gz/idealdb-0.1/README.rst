========
IDEAL DB
========

Infectious Diseases of East-African Livestock

IDEAL
-----

Application for the IDEAL database
